var fs = require('fs');
var _ = require('lodash');

function getConfig(file) {
  var filepath = getDummyFolderPath() + file;
  return readJsonFileSync(filepath);
}

function getDummyFolderPath() {
  return __dirname.replace('server_apply/shared', 'server_apply/public/dummy/');
}

function readJsonFileSync(filepath, encoding) {

  if (typeof (encoding) == 'undefined') {
    encoding = 'utf8';
  }
  var file = fs.readFileSync(filepath, encoding);
  return JSON.parse(file);
}

module.exports = {
  loadEntities: function (fileName) {
    var path = getDummyFolderPath() + fileName;
    return readJsonFileSync(path);
  },

  checkApplyExisted: function (fileName) {
    var path = getDummyFolderPath() + fileName;
    return fs.existsSync(path);
  },

  deleteFileSync: function (fileName, callback) {
    var path = getDummyFolderPath() + fileName;
    fs.unlink(path, callback);
  },

  writeJsonFileSync: function (fileName, body, callback) {
    var path = getDummyFolderPath() + fileName;
    fs.writeFile(path, body, callback)
  },

  getDummyFolderPath: function() {
    return getDummyFolderPath();
  }


}
