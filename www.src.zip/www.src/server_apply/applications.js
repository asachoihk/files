var express = require('express');
var fs = require('fs');
var _ = require('lodash');
var common = require('./shared/common');
var router = express.Router();
var applicationListFile = 'applicationList.json';

/* GET home page. */
router.get('/', function (req, res, next) {
  let applications = common.loadEntities(applicationListFile) || [];
  var proposalId = req.query.proposalId;

  if (proposalId && proposalId.length > 0) {
    const filteredApplication = _.filter(applications, c => c.proposalId == proposalId);

    res.json(filteredApplication);
  } else {
    res.json(applications);
  }
});

function createOrSaveData(req, res) {
  var applyData = req.body;
  var applyId = applyData.applicationId;

  let applications = common.loadEntities(applicationListFile) || [];

  if (req.method.toLowerCase() == 'post') {
    applyData.SoupEntryId = Math.floor(Math.random() * 100000000 + 1);
    applications.push(applyData);
  } else {
    let index = _.findIndex(applications, app => {
      return app.applicationId === applyId;
    });
    if (index > -1) {
      applications[index] = applyData;
    }
  }

  return updateApplications(applications, res);
}

function updateApplications(applications, res) {
  common.deleteFileSync(applicationListFile, function (err) {
    if (err) {
      res.status(404).send('Deletion failed');
      return;
    }
    let content = JSON.stringify(applications);
    common.writeJsonFileSync(applicationListFile, content, function (err1) {
      if (err1) {
        res.status(404).send('Apply not saved');
        return;
      }
      res.json(applications);
    });
  });
}

function deleteData(req, res) {
  var applyDatas = req.body;
  console.log(applyDatas);
  let applications = common.loadEntities(applicationListFile) || [];
  applications = _.filter(applications, (app) => applyDatas.indexOf(app.applicationId)===-1);

  return updateApplications(applications, res);
}

router.put('/deleteApplication', function (req, res, next) {
  return deleteData(req, res);
});

router.put('/', function (req, res, next) {
  return createOrSaveData(req, res);
});

router.post('/', function (req, res, next) {
  return createOrSaveData(req, res);
});

router.get('/attachment', function (req, res, next) {
  let filepath = common.getDummyFolderPath();

  var options = {
    root: filepath,
    dotfiles: 'deny',
    headers: {
      'x-timestamp': Date.now(),
      'x-sent': true
    }
  };
  var fileType = req.query ? req.query.fileType : 'pdf';
  let file = 'about-manulife.jpg';
  if (fileType === 'pdf' || fileType === 'application/pdf') {
    file = 'test.pdf';
  }
  if (req.query && req.query.applicationAttachmentId) {
    file = req.query.applicationAttachmentId;
  }

  console.log(req.query.reportType);
  if (req.query && req.query.reportType) {

    if (req.query.reportType === "ApplicationInsured") {
      file = 'application_form.pdf';
    }
    if (req.query.reportType === "proposal") {
      file = 'new_cie.pdf';
    }
    if (req.query.reportType === "agentSignature") {
      file = 'agentSignature.png';
    }
    if (req.query.reportType === "insuredSignature") {
      file = 'agentSignature.png';
    }
    if (req.query.reportType === "ownerSignature") {
      file = 'agentSignature.png';
    }
    if (req.query.reportType === "dependentSignature") {
      file = 'agentSignature.png';
    }
  }
  return res.sendFile(file, options, function (err) {
    if (err) {
      // next(err);
      file = 'about-manulife.jpg';
      if (fileType === 'pdf' || fileType === 'application/pdf') {
        file = 'test.pdf';
      }
      return res.sendFile(file, options, function (err1) {
        next(err1);
      });
    } else {
      console.log('Sent:', file);
    }
  });
});

router.post('/attachment', function (req, res, next) {
  let filepath = common.getDummyFolderPath();

  var data = req.body;
  if (data && Array.isArray(data)) {
    data.forEach(document => {
      let now = new Date();
      var fs = require('fs');
      let array = document.base64File.split(',');
      document.base64File = array[1];
      let typeData = array[0];
      let type = typeData.slice(typeData.indexOf('/') + 1, typeData.indexOf(';'));
      var bitmap = new Buffer(document.base64File, 'base64');
      fs.writeFileSync(filepath + now.getTime() + '.' + type, bitmap);
      document.serverId = now.getTime();
    });
    res.json(
      data.map(item => {
        return { id: item.id, serverId: item.serverId };
      })
    );
  } else {
    next({ error: 100 });
  }
});


router.post('/generateApplicationPdfWithSignatures', function (req, res, next) {
  const random = Math.floor((Math.random() * 10000000) + 1);

  setTimeout(function () {
    res.json(
      { serverId: random }
    );
  }, 1000);
});

router.get('/getDocuments', function (req, res, next) {
  const random = Math.floor((Math.random() * 10000000) + 1);
  let fileName = '';
  if (req.query && req.query.params) {
    fileName = req.query.params;
  }

  setTimeout(function () {
    res.json(
      [
        {
          fileName: fileName,
          serverId: random
        }
      ]
    );
  }, 1000);
});
router.post('/addSignatureToReport', function (req, res, next) {
  const random = Math.floor((Math.random() * 10000000) + 1);

  setTimeout(function () {
    res.json(
      { serverId: random }
    );
  }, 1000);
});

module.exports = router;
