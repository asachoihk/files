import { Component, OnInit, OnDestroy } from '@angular/core';
import { TranslationService, LocaleService } from 'angular-l10n';
import { Router } from '@angular/router';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import 'rxjs/add/operator/filter';
import { DateAdapter } from '@angular/material/core';
import * as moment from 'moment';

import { CacheKeys } from '@app/app-constants';
import {
  AppConfigService,
  ProxyService,
  CacheService,
  AgentService,
  AuthenticationService
} from '@providers';
import { Subscription } from 'rxjs/Subscription';
import { environment } from '@env/environment';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {

  private routerEventsSub: Subscription;
  private networkConnectSub: Subscription;
  private networkDisconnectSub: Subscription;

  constructor(
    private config: AppConfigService,
    private locale: LocaleService,
    private translator: TranslationService,
    private router: Router,
    private proxy: ProxyService,
    private idle: Idle,
    private cache: CacheService,
    public dateAdapter: DateAdapter<any>,
    private agentService: AgentService,
    private authenticationService: AuthenticationService,
    private titleService: Title
  ) {
    this.initIdle();
  }

  ngOnInit() {
    this.initLanguage();

    if (environment.production) {
      this.authenticationService.isAuthorized().subscribe(result => {
        if (result !== true) {
          this.authenticationService.authorize();
        } else {
          this.checkSoftwareDisclaimer();
        }
      });
    } else {
      this.checkSoftwareDisclaimer();
    }

    this.checkSyncWarning();

    this.addDeviceReadyEvent();
  }

  ngOnDestroy(): void {
    if (this.routerEventsSub) { this.routerEventsSub.unsubscribe(); }
    if (this.networkConnectSub) { this.networkConnectSub.unsubscribe(); }
    if (this.networkDisconnectSub) { this.networkDisconnectSub.unsubscribe(); }

    if (this.idle) {
      if (this.idle.onIdleStart) { this.idle.onIdleStart.unsubscribe(); }
      if (this.idle.onIdleEnd) { this.idle.onIdleEnd.unsubscribe(); }
      if (this.idle.onTimeout) { this.idle.onTimeout.unsubscribe(); }
      if (this.idle.onTimeoutWarning) { this.idle.onTimeoutWarning.unsubscribe(); }
    }
  }

  private initIdle() {
    this.idle.setIdle(this.config.inactivityDuration);
    this.idle.setTimeout(0);
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleStart.subscribe();
    this.idle.onIdleEnd.subscribe(() => {
      this.proxy.get<any>(this.config.checkAuth).subscribe(result => {
        if (result && result.status !== 'success') {
          this.proxy.get(this.config.appExit).subscribe();
        }
      });
    });
    this.idle.onTimeout.subscribe();
    this.idle.onTimeoutWarning.subscribe();

    this.idle.watch();
  }

  private setTitle() {
    const title = this.translator.translate('eposTitle');
    this.titleService.setTitle(title);
  }

  private initLanguage() {
    // detect set language for app
    let lang = this.cache.getString(CacheKeys.EPOS_LANGUAGE);
    if (lang) {
      // Fix language when upgrade app from angularjs to angular5
      if (lang === 'vi_VN') { lang = 'vi'; this.cache.set(CacheKeys.EPOS_LANGUAGE, lang); }
      if (lang === 'en_US') { lang = 'en'; this.cache.set(CacheKeys.EPOS_LANGUAGE, lang); }
      // Fix end

      this.locale.setCurrentLanguage(lang);
    } else {
      lang = this.config.language;
      this.cache.set(CacheKeys.EPOS_LANGUAGE, lang);
    }
    this.dateAdapter.setLocale(lang);
    moment.locale(lang);
    this.translator.init();
    this.setTitle();
  }

  private checkSoftwareDisclaimer() {
    const currentAgent = this.agentService.getCurrent();
    // If clicked Start button of Software Disclaimer -> navigate to Homepage
    const softwareDisclaimerAccepted = environment.production ? currentAgent.agentData.isDisclaimer : this.cache.getBoolean(CacheKeys.SOFTWARE_DISCLAIMER_ACCEPTED);
    if (softwareDisclaimerAccepted) {
      this.router.navigate([this.config.homePage]);
    } else {
      this.router.navigate(['newSoftwareDisclaimer']);
    }
  }

  private checkSyncWarning() {
    // show warning synching for first time
    if (this.cache.get(CacheKeys.SHOW_SYNC_WARNING) === null) {
      this.cache.set(CacheKeys.SHOW_SYNC_WARNING, true);
    }
  }

  private addDeviceReadyEvent() {
    document.addEventListener('deviceready', () => {
      // fix issue when run async
      setTimeout(() => {
        const ref = window.location.href;
        if (ref.lastIndexOf('about:blank') !== -1 || ref.lastIndexOf('undefined') !== -1) {
          window.open('cdvfile://localhost/bundle/www/index.html');
        }
      }, 200);

      this.addTouchEvents();
    }, false);
  }

  private addTouchEvents() {
    let timer;
    window.addEventListener('touchstart', () => {
      if (timer) { clearTimeout(timer); }
    });

    window.addEventListener('touchend', () => {
      timer = setTimeout(() => {
        this.proxy.get(this.config.updateLastUsageTime).subscribe();
      }, 5000);
    });
  }
}
