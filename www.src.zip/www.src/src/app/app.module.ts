import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgIdleModule } from '@ng-idle/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS, MAT_LABEL_GLOBAL_OPTIONS } from '@angular/material';
import { CURRENCY_MASK_CONFIG } from 'ngx-currency-mask/src/currency-mask.config';

import { AppComponent } from '@app/app.component';
import { AppRoutingModule } from '@app/app-routing.module';
import { SharedModule } from '@shared/shared.module';
import { FrameworkModule } from '@framework/framework.module';

import { DATE_FORMATS, CUSTOM_CURRENCY_MASK_CONFIG, l10nConfig } from 'country/country.config';
import { ProvidersModule, HttpInterceptorService, AppConfigService, AgentService, LocatorService } from '@providers';
import { ProposeModule } from '@propose/propose.module';
import { L10nLoader, TranslationModule } from 'angular-l10n';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MeetRefineModule } from '@meet-refine/meet-refine.module';
// Apply
import { ApplyModule } from '@apply/apply.module';
import { RouteReuseStrategy, RouterModule } from '@angular/router';
import { ApplyRouteReuseStrategy } from '@framework/route-strategy/route.strategy';
import { CountryModule } from 'country/country.module';
import { RegionalModule } from 'regional/regional.module';
import { AppInitializerFactory } from './app-initializer';


const initL10n = (l10nLoader: L10nLoader): Function => {
  return () => l10nLoader.load();
};
export default initL10n;

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    RouterModule,
    FrameworkModule,
    SharedModule,
    ProvidersModule,
    ApplyModule,
    MeetRefineModule,
    ProposeModule,
    AppRoutingModule,
    TranslationModule.forRoot(l10nConfig),
    NgIdleModule.forRoot(),
    RegionalModule.forRoot(),
    CountryModule
  ],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: DATE_FORMATS },
    { provide: CURRENCY_MASK_CONFIG, useValue: CUSTOM_CURRENCY_MASK_CONFIG },
    { provide: MAT_LABEL_GLOBAL_OPTIONS, useValue: { float: 'always' } },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpInterceptorService,
      multi: true
    },
    {
      provide: APP_INITIALIZER,
      useFactory: initL10n,
      deps: [L10nLoader],
      multi: true
    },
    {
      provide: APP_INITIALIZER,
      useFactory: AppInitializerFactory,
      deps: [
        AppConfigService,
        AgentService,
        LocatorService
      ],
      multi: true
    },
    {
      provide: RouteReuseStrategy,
      useClass: ApplyRouteReuseStrategy
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
