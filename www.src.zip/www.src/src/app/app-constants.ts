export class CacheKeys {
  public static readonly EPOS_LANGUAGE = 'epos_language';
  public static readonly SOFTWARE_DISCLAIMER_ACCEPTED = 'epos_software_disclaimer_accepted';
  public static readonly SHOW_SYNC_WARNING = 'epos_show_sync_warning';
  public static readonly LAST_ACCESSED_PAGES = 'epos_last_accessed_pages';
  public static readonly SERVER_TIMEZONE = 'server_timezone';
}
