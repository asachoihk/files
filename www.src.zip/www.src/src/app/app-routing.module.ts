import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EndUserAgreementComponent } from '@framework/pages';

const routes: Routes = [
  {
    path: 'softwareDisclaimer',
    component: EndUserAgreementComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: true
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
