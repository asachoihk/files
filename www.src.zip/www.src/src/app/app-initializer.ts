import { AppConfigService, AgentService, LocatorService } from '@providers';
import { Observable } from 'rxjs';


export const AppInitializerFactory =
  (
    appConfigService: AppConfigService,
    agentService: AgentService,
    locatorService: LocatorService
  ) =>
    () => Observable.forkJoin(
      [
        appConfigService.init().flatMap(() => agentService.init()),
        locatorService.init()
      ]
    ).toPromise();
