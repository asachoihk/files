import { LocatorService, JsonConfigService, FormBuilderService, BaseAction, JsonConfigItem, FormField } from '@providers';
import { Observable } from 'rxjs';
import * as _ from 'lodash';

export class GetCountries extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Observable<JsonConfigItem[]> {
    return new Observable<JsonConfigItem[]>(subscriber => {
      if (this.formFieldConfig.type === 'list' || this.formFieldConfig.type === 'dropdown') {
        const countries = this.ls.getService<JsonConfigService>('jsonConfigService').getCountries();
        subscriber.next(_.cloneDeepWith(countries));
      } else {
        const parentFFC = this.parentFormFieldConfig as FormField;
        const childFFC = this.formFieldConfig as FormField;
        const ffc = parentFFC.type === 'dependency' ? childFFC : (parentFFC || childFFC);
        let defaultValues = ffc.default as string;
        if (!defaultValues) {
          subscriber.next([]);
        } else {
          const countries = this.ls.getService<JsonConfigService>('jsonConfigService').getCountries();
          const dataBinding = ffc.dataBinding;
          if (dataBinding) {
            const selected = this.ls.getService<FormBuilderService>('formBuilderService').getBindingData(this.viewModel, dataBinding.path);
            if (selected) {
              defaultValues = defaultValues + ',' + selected.toString();
            }
          }
          subscriber.next(_.cloneDeepWith(countries.filter(c => defaultValues.includes(c.id))));
        }
      }
    });
  }
}
