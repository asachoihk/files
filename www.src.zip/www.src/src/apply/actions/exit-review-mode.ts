import { BaseAction, LocatorService, SystemEventService, ViewModeChanged, ViewMode, ToolbarActionsChanged } from '@providers';

export class ExitReviewMode extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute() {
        this.ls.getService<SystemEventService>('systemEventService').publish(new ViewModeChanged(ViewMode.normal));
        this.ls.getService<SystemEventService>('systemEventService').publish(new ToolbarActionsChanged());
    }
}
