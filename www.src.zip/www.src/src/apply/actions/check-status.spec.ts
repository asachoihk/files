import { LocatorService } from '@providers';
import { CheckStatus } from './check-status';
import { TestBed } from '@angular/core/testing';

class Action extends CheckStatus {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
}

describe('CheckStatus', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
        spyOn(action.ls, 'getService').and.callThrough();
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});