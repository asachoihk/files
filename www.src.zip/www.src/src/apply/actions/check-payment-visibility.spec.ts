import { LocatorService, FormBuilderService } from '@providers';
import { CheckPaymentVisibility } from './check-payment-visibility';
import { TestBed } from '@angular/core/testing';
import { ApplyModel } from '@apply/models';

class Action extends CheckPaymentVisibility {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }
    }
}

class MockFormBuilderService {
    constructor() { }

    getComponentByFormFieldConfigId() {
        return {
            loadDataSource() {
                return null;
            },
            selectedItem: 'abc',
            visibility: 'visible'
        };
    }
    setBindingData() {
        return null;
    }

    getComponentByFormFieldConfig() {
        return {
            visibility: 'disabled'
        };
    }
}

describe('CheckPaymentVisibility', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Execute', () => {
        it('Application status - SUBMISSION_AGENT_QUESTION', () => {
            const model = {
                status: 'SUBMISSION_AGENT_QUESTION'
            };
            const formFieldConfig = {
                id: 'saveAndNextPayment',
                type: 'button'
            };
            action.viewModel = model as ApplyModel;
            action.formFieldConfig = formFieldConfig;
            spyOn(action.ls, 'getService').and.returnValue({
                getComponentByFormFieldConfigId() {
                    return {
                        visibility: 'hidden'
                    };
                },

                getComponentByFormFieldConfig() {
                    return {
                        visibility: 'disabled'
                    };
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('Application status - PAYMENT_PENDING', () => {
            const model = {
                status: 'PAYMENT_PENDING'
            };
            const formFieldConfig = {
                id: 'saveAndNextPayment',
                type: 'button'
            };
            action.viewModel = model as ApplyModel;
            action.formFieldConfig = formFieldConfig;
            spyOn(action.ls, 'getService').and.returnValue({
                getComponentByFormFieldConfigId() {
                    return {
                        visibility: 'visible'
                    };
                },

                getComponentByFormFieldConfig() {
                    return {
                        visibility: 'disabled'
                    };
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('Application status - PAYMENT_PENDING - visibility hidden', () => {
            const model = {
                status: 'PAYMENT_PENDING',
                payment: {
                    documents: []
                }
            };
            const formFieldConfig = {
                id: 'saveAndNextPayment',
                type: 'button'
            };
            action.viewModel = model as ApplyModel;
            action.formFieldConfig = formFieldConfig;
            spyOn(action.ls, 'getService').and.returnValue({
                getComponentByFormFieldConfigId() {
                    return {
                        visibility: 'hidden'
                    };
                },

                getComponentByFormFieldConfig() {
                    return {
                        visibility: 'disabled'
                    };
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });

    it('Application status - PAYMENT_PENDING - default', () => {
        const model = {
            status: 'PAYMENT_PENDING',
        };
        const formFieldConfig = {
            id: 'saveAndNextPayment',
            type: 'button'
        };
        action.viewModel = model as ApplyModel;
        action.formFieldConfig = formFieldConfig;
        spyOn(action.ls, 'getService').and.returnValue({
            getComponentByFormFieldConfigId() {
                return {
                    visibility: undefined
                };
            },

            getComponentByFormFieldConfig() {
                return {
                    visibility: 'disabled'
                };
            }
        });
        action.execute();
        expect(action.ls.getService).toHaveBeenCalled();
    });
});
