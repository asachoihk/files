import { BaseAction, LocatorService, FormBuilderService, AgreementAnswerMetadata, Visibility } from '@providers';
import { ButtonComponent } from '@shared/ui-elements';
import { BeneficialOwnerListComponent } from '@apply/components';

export class CheckBeneficialOwner extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const button = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as ButtonComponent;

    const beneficialOwnerListComponentId = this.formFieldConfig.relationships[0];

    const beneficialOwnerListComponent = this.ls.getService<FormBuilderService>('formBuilderService')
      .getComponentByFormFieldConfigId(beneficialOwnerListComponentId) as BeneficialOwnerListComponent;

    const metadata = beneficialOwnerListComponent.formFieldConfig.metadata as AgreementAnswerMetadata;

    if (metadata.max) {
      button.visibility = beneficialOwnerListComponent.dataSource.length >= metadata.max ? Visibility.hidden : Visibility.visible;
    }
  }
}
