import { SubmitAis } from './submit-ais';
import { LocatorService } from 'providers/services/locator/locator.service';
import { TestBed } from '@angular/core/testing';
import { GlobalNavigationService, ActionService } from '@providers';
import { ApplyModel, DeclarationAnswerModel, PaymentModel } from '@apply/models';
import { PaymentMethod } from '@apply/enums';
import { ApplicationService } from '@apply/services/application/application.service';
import { Observable } from 'rxjs';
import { TranslationService } from 'angular-l10n';


class Action extends SubmitAis {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

}

class MockGlobalNavigationService {
  getPreviousPageData() {
    return false;
  }

  navigateTo(url?: any, queryParams?: any) {

  }
}

class MockTranslationService {
  snapshot = {
    queryParams: {
      customerId: '123'
    }
  };

  translate() {
    return 'Testing';
  }
}
class MockLocatorService {
  get(): MockTranslationService {
    return new MockTranslationService();
  }

  getService(serviceName: string): any {
    if (serviceName === 'globalNavigationService') {
      return new MockGlobalNavigationService();
    } else if (serviceName === 'actionService') {
      return new MockActionService();
    } else if (serviceName === 'applicationService') {
      return new MockApplicationService();
    }
  }
}

class MockActionService {
  executeAction(actionName: string, context: any, params: any, handleActionResult: (actionResult: any) => void) {

  }
}

class MockApplicationService {
  saveApplyData(customerId: string, applyModels: ApplyModel[], isAddNew?: boolean): Observable<any[]> {
    return new Observable(subscriber => {
      return subscriber.next([{}]);
    });
  }
}

describe('Update bank info', () => {
  let action: Action;
  let ls;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: GlobalNavigationService, useClass: MockGlobalNavigationService },
        { provide: ActionService, useClass: MockActionService },
        { provide: ApplicationService, useClass: MockApplicationService },
        { provide: TranslationService, useClass: MockTranslationService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {

    it('should be run', () => {
      const viewModel = new ApplyModel();
      viewModel.declaration_answer = new DeclarationAnswerModel();
      viewModel.declaration_answer.agent_answer = 'MSGA042A';
      viewModel.declaration_answer.agent_question = 'Y';
      viewModel.payment = new PaymentModel();
      viewModel.payment.method = PaymentMethod.CASH;

      action.viewModel = viewModel;
      action.execute().subscribe(data =>
        expect(data).toBeFalsy()
      );
    });
  });

  describe('ValidateForm true', () => {

    it('should be run', () => {
      const viewModel = new ApplyModel();
      viewModel.declaration_answer = new DeclarationAnswerModel();
      viewModel.declaration_answer.agent_answer = 'MSGA042A';
      viewModel.declaration_answer.agent_question = 'N';

      action.viewModel = viewModel;
      expect(action.validateForm('1234', 'action')).toBeTruthy();
    });
  });

  describe('ValidateForm false', () => {

    it('should be run', () => {
      const viewModel = new ApplyModel();
      viewModel.declaration_answer = new DeclarationAnswerModel();
      viewModel.declaration_answer.agent_answer = 'MSGA042A';
      viewModel.declaration_answer.agent_question = 'Y';
      action.viewModel = viewModel;
      spyOn(action, 'validateForm').and.returnValue(false);
      expect(action.validateForm('1234', 'action')).toBeFalsy();
    });
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      const viewModel = new ApplyModel();
      viewModel.declaration_answer = new DeclarationAnswerModel();
      viewModel.declaration_answer.agent_answer = '';
      viewModel.declaration_answer.agent_question = 'Y';
      viewModel.payment = new PaymentModel();
      viewModel.payment.method = PaymentMethod.CASH;
      action.viewModel = viewModel;
      action.execute().subscribe(data =>
        expect(data).toBeDefined()
      );
    });
  });
});
