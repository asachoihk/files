import { Injectable } from '@angular/core';
import { LocatorService, DialogData } from '@providers';
import { OpenSearchListDialog } from '@shared/actions/search-list/open-search-list-dialog';
import { TranslationService } from 'angular-l10n';

@Injectable()
export class LoadIssuePlaceDialog extends OpenSearchListDialog {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  getDialogData(): DialogData {
    const headerCountry = this.ls.get(TranslationService).translate('searchcountry');
    return {
      viewModel: this.viewModel,
      formFieldConfig: this.parentFormFieldConfig,
      params: {
        componentParams: {
          header: headerCountry,
          dataSource: {
            actionName: 'getCountries'
          },
          dataSourceMetadata: this.formFieldConfig.dataSourceMetadata
        },
        header: this.formFieldConfig.label
      }
    };
  }
}
