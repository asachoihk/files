import { BaseAction, LocatorService, InsuredType, Visibility } from '@providers';
import { InsuredModel } from '@apply/models';

export class CheckOwnerType extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Visibility {

    const insured = this.viewModel as InsuredModel;
    if (insured && insured.type && insured.type !== InsuredType.io && insured.type !== InsuredType.o) {
      return Visibility.hidden;
    }
    return Visibility.unset;
  }
}
