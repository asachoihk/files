import { TestBed, async } from '@angular/core/testing';
import { LocatorService, JsonConfigService, FormBuilderService } from '@providers';
import { GetAgentApplications } from './get-agent-applications';
import { ApplicationService } from '@apply/services';
import { isObservable, Observable } from 'rxjs';


class Action extends GetAgentApplications {
    constructor(public ls: LocatorService) {
      super(ls);
    }
  }

  class MockLocatorService {
    getService(serviceName: string) {
        switch (serviceName) {
          case 'applicationService':
            return new MockApplicationService();
          case 'formBuilderService':
            return new MockFormBuilderService();
          default:
            break;
        }
      }
  }

  class MockApplicationService {
    constructor() {
    }
    getAgentApplicationsHeader(params){
      return new Observable(sub => {
        sub.next([{
          applicationId: '9e101e2c-ca71-5789-bd34-60cde6d59540',
          customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdea',
          protectionAmountApply: '',
          status: 'APPLICATION_INPROGRESS'
        }]);
      }); 
    }
  }

  class MockFormBuilderService {
    constructor() {
    }
    notifyDependentFieldChanged() {
      return null;
    }

  }

describe('GetAgentApplications', () => {
    let action: Action;
    let ls: LocatorService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ApplicationService, useClass: MockApplicationService },
                { provide: FormBuilderService, useClass: MockFormBuilderService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
      });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
          const params = {
            keywords: 'keywords',
            data: 'data'
          };
            action.formFieldConfig = {
              id: 'id',
              type:'type',
              dataSource : {
                actionName: 'actionName',
                params : {
                  filerByColumns : 'filerByColumns'
                }
              }
            };
            expect(action.execute(params));
        });

        it('should be isAscending : false ',async( () => {
          const params = {
            keywords: undefined,
            data: [{
              applicationId: '9e101e2c-ca71-5789-bd34-60cde6d59540',
              customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdea',
              protectionAmountApply: '',
              status: 'APPLICATION_INPROGRESS'
            }]
          };
          action.formFieldConfig = {
            id: 'id',
            type:'type',
            dataSource : {
              actionName: 'actionName',
              params : {
                filerByColumns : 'filerByColumns',
                columnSortDefault : {
                  isAscending : false
                }
              }
            }
          };
          const res = action.execute(params);
          if(isObservable(res)){
            res.subscribe(data =>{
              expect(data).toEqual([{
                applicationId: '9e101e2c-ca71-5789-bd34-60cde6d59540',
                customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdea',
                protectionAmountApply: '',
                status: 'APPLICATION_INPROGRESS'
              }]);
            });
          }
        }));

        it('should be isAscending : true ',async( () => {
          const params = {
            keywords: undefined,
            data: [{
              applicationId: '9e101e2c-ca71-5789-bd34-60cde6d59540',
              customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdea',
              protectionAmountApply: '',
              status: 'APPLICATION_INPROGRESS'
            }]
          };
          action.formFieldConfig = {
            id: 'id',
            type:'type',
            dataSource : {
              actionName: 'actionName',
              params : {
                filerByColumns : 'filerByColumns',
                columnSortDefault : {
                  isAscending : true
                }
              }
            }
          };
          const res = action.execute(params);
          if(isObservable(res)){
            res.subscribe(data =>{
              expect(data).toEqual([{
                applicationId: '9e101e2c-ca71-5789-bd34-60cde6d59540',
                customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdea',
                protectionAmountApply: '',
                status: 'APPLICATION_INPROGRESS'
              }]);
            });
          }
        }));
    });
});
