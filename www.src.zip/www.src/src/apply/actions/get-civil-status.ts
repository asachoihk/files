import { LocatorService, BaseAction } from '@providers';

export class GetCivilStatus extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
      return [
        {
          label: 'Single',
          value: 'Single'
        },
        {
          label: 'Married',
          value: 'Married'
        },
        {
          label: 'Divorced',
          value: 'Divorced'
        },
        {
          label: 'Separated',
          value: 'Separated'
        },
        {
          label: 'Widowed',
          value: 'Widowed'
        }
      ];
  }
}
