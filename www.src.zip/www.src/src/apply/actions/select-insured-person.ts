import { LocatorService, DialogService, FormBuilderService, InsuredType, BaseAction, AppContextService } from '@providers';
import { DialogShellComponent } from '@shared/shells';
import { TaskCardListComponent } from '@shared/components';
import { PersonalInfoComponent } from '@apply/pages';

export class SelectInsuredPerson extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params: any): void {
        let data: any;
        data = {
            viewModel: this.viewModel
        };
        this.ls.getService<DialogService>('dialogService').showFormBuilderDialog(PersonalInfoComponent, DialogShellComponent, data, _result => {
            // if (result) {
            const currentFormBuilder = this.ls.getService<AppContextService>('appContextService').currentFormBuilder;
            currentFormBuilder.refreshData(() => {
                const taskCardList = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as TaskCardListComponent;
                if (taskCardList) {
                    taskCardList.loadDataSource();
                }

                if (data.viewModel && data.viewModel.type === InsuredType.o && params && params.beneficiaryId) {
                    const taskCardListBeneficiary = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(params.beneficiaryId) as TaskCardListComponent;
                    if (taskCardListBeneficiary) {
                        taskCardListBeneficiary.loadDataSource();
                    }
                }
            });
            // }
        });
    }
}
