import { LocatorService, FormBuilderService, SystemEventService, BaseAction, AgreementAnswerMetadata, VisibilityRefreshed, Visibility } from '@providers';
import { ButtonComponent } from '@shared/ui-elements';
import { AgreementInsuranceListComponent } from '@apply/components';
import { InsuranceModel } from '@apply/models';

export class AddOtherAgreementInsurace extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any): any {
    if (params && params.agreementInsurancesFieldId) {
      const agreementInsuranceList = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(params.agreementInsurancesFieldId) as AgreementInsuranceListComponent;
      const metadata = agreementInsuranceList.formFieldConfig.metadata as AgreementAnswerMetadata;
      if (!agreementInsuranceList || metadata && metadata.max && agreementInsuranceList.dataSource.length >= metadata.max) {
        return;
      } else {
        agreementInsuranceList.dataSource = agreementInsuranceList.dataSource ? agreementInsuranceList.dataSource : [];
        const insurance = new InsuranceModel();
        agreementInsuranceList.dataSource.push(insurance);
        this.ls.getService<FormBuilderService>('formBuilderService').setBindingData(this.viewModel, agreementInsuranceList.formFieldConfig.dataBinding.path, agreementInsuranceList.dataSource);
        const button = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as ButtonComponent;
        if (button) {
          button.visibility = metadata && metadata.max && agreementInsuranceList.dataSource.length >= metadata.max ? Visibility.hidden : Visibility.visible;
          button.formControl.markAsDirty();
        }
        this.ls.getService<SystemEventService>('systemEventService').publish(new VisibilityRefreshed());
      }
    }
  }
}
