import { LocatorService, BaseAction, AppContextService } from '@providers';
import { FormBuilderDialog } from '@shared/ui-elements';
import { TranslationService } from 'angular-l10n';

export class GetBeneficiaryTitle extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(): string {

        const currentDialog = this.ls.getService<AppContextService>('appContextService').currentFormBuilder as FormBuilderDialog;
        if (!currentDialog || !currentDialog.data || !currentDialog.data.params || !currentDialog.data.params.header) { return ''; }

        return this.ls.get(TranslationService).translate(currentDialog.data.params.header);
    }
}
