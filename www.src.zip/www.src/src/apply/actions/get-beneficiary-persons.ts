
import { LocatorService, JsonConfigService, BaseAction, Visibility } from '@providers';
import { TranslationService } from 'angular-l10n';
import { FormBuilderService } from '@providers';
import { TaskCardListComponent } from '@shared/components';
import { ApplyModel, PersonModel, BeneficiaryRelationshipModel } from '@apply/models';

export class GetBeneficiaryPersons extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(_params?: any): any[] {
    const applyData = this.viewModel as ApplyModel;
    const beneficiaries = applyData.beneficiaries;
    if (beneficiaries) {
      beneficiaries.forEach(item => {
        if (!item.person) {
          item.person = new PersonModel();
        }
        if (item.person.basicInfo.gender) {
          const gender = item.person.basicInfo.gender.toLowerCase();
          item.person.basicInfo.gender = this.ls.get(TranslationService).translate(gender.startsWith('f') ? 'CPOS0166_Female' : 'CPOS0166_Male');
        }

        if (!item.insuredRelationship) {
          item.insuredRelationship = new BeneficiaryRelationshipModel();
        }

        item['type'] = 'Beneficiary';
      });
    }
    const addNewTask = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as TaskCardListComponent;

    const numberBeneficiary = _params && _params.maxBeneficiaryAllowed ? _params.maxBeneficiaryAllowed : null;

    addNewTask.taskCardSelectionVisibility =
      beneficiaries.some(b => b.guid === applyData.owner.id)
        || beneficiaries.length === numberBeneficiary || applyData.owner.id === applyData.insured.id ? Visibility.hidden : Visibility.visible;

    return beneficiaries;
  }

  convertRelationCode(id: any) {
    const relationCode = this.ls.getService<JsonConfigService>('jsonConfigService').getRelationCode();
    for (let i = 0; i < relationCode.length; i++) {
      if (relationCode[i].id === id) {
        return this.ls.get(TranslationService).translate(relationCode[i].value);
      }
    }
  }
}
