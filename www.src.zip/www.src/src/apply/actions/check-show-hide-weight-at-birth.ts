import { BaseAction, LocatorService, InsuredType, FormBuilderService, Visibility } from '@providers';
import { InsuredModel, UnderwritingModel } from '@apply/models';
import { BaseComponent } from '@shared/ui-elements';

export class CheckShowHideWeightAtBirth extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Visibility {

    const viewMode = this.viewModel as InsuredModel;
    const uwDetails = viewMode.uwDetails as UnderwritingModel;
    const answers = uwDetails.answers;

    const formComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(this.formFieldConfig.id) as BaseComponent;

    if (viewMode.person.basicInfo.age < 2 && viewMode.type === InsuredType.i) {
      if (answers && formComponent) {
        answers.forEach(item => {
          if (item.answer) {
            formComponent.visibility = Visibility.disabled;
          }
        });
      } else {
        return formComponent.visibility ? formComponent.visibility : Visibility.visible;
      }
    } else {
      return Visibility.hidden;
    }
  }
}
