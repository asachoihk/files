import { BaseAction, LocatorService, FormBuilderService, Visibility } from '@providers';
import { TextboxComponent } from '@shared/ui-elements';


export class ShowSourceOfFunds extends BaseAction {

  constructor(protected ls: LocatorService) {
    super(ls);
  }
  execute(): any {
    // const a = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig);
    const values = this.ls.getService<FormBuilderService>('formBuilderService').getDisplayValue(this.viewModel, this.formFieldConfig);
    const otherField = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('otherSource') as TextboxComponent;
    const countryField = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('countryOfRemittance') as TextboxComponent;
    const checkOthers = values.filter( item => {
      if (item === 'Others') {
        return item;
      }
    });
    const checkRemittance = values.filter( item => {
      if (item === 'Remittance') {
        return item;
      }
    });
    if (checkOthers && checkOthers.length > 0) {
      otherField.visibility = Visibility.visible;
    }
    if (checkOthers && checkOthers.length === 0) {
      otherField.visibility = Visibility.hidden;
    }
    if (checkRemittance && checkRemittance.length > 0) {
      countryField.visibility = Visibility.visible;
    }
    if (checkRemittance && checkRemittance.length === 0) {
      countryField.visibility = Visibility.hidden;
    }
  }
}
