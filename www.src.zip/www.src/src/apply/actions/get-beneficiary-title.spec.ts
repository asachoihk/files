import { TestBed } from '@angular/core/testing';
import { LocatorService, AppContextService } from '@providers';
import { GetBeneficiaryTitle } from './get-beneficiary-title';
import { TranslationService } from 'angular-l10n';


class Action extends GetBeneficiaryTitle {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'appContextService':
        return new MockAppContextService();
      default:
        break;
    }
  }
  get(serviceName) {
    return new MockTranslationService();
  }
}

class MockTranslationService {
  constructor() {
  }
  translate(keys) {
    return 'translate text';
  }
}

class MockAppContextService {
  constructor() {
  }
  currentFormBuilder = {
    data: {
      params: {
        header: 'Add Beneficiary'
      }
    }
  }
}

describe('GetBeneficiaryTitle', () => {
  let action: Action;
  let ls: LocatorService;
  let tran: TranslationService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: AppContextService, useClass: MockAppContextService },
        { provide: TranslationService, useClass: MockTranslationService }
      ]
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      expect(action.execute()).toEqual('translate text');
    });

    it('should be run', () => {
      spyOn(action.ls, 'getService').and.returnValue({
        translate(keys) {
          return 'translate text';
        },
        currentFormBuilder: {
          data: {
          }
        },
      });
      expect(action.execute()).toEqual('');
    });
  });
});
