import { TestBed } from '@angular/core/testing';
import { AddBeneficialOwner } from './add-beneficial-owner';
import { LocatorService } from 'providers/services/locator/locator.service';
import { FormBuilderService } from 'providers/services/form-builder/form-builder.service';
import { of } from 'rxjs/internal/observable/of';

class Action extends AddBeneficialOwner {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    get(): MockFormBuilderService {
        return new MockFormBuilderService();
    }

    getService(serviceName: string): any {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }
        return new MockSystemEventService();
    }
}

class MockSystemEventService {
    publish() {
        return of({});
    }
}

class MockFormBuilderService {
    constructor() { }
    get() {
        return null;
    }

    getComponentByFormFieldConfigId(configId: string) {
        if (configId === 'beneficialOwnerList') {
            return {
                formFieldConfig: {
                    metadata: { max: 10 },
                    dataBinding: {
                        path: 'agreement.beneficialOwners'
                    }
                },
                dataSource: [{
                    beneficialNumber: 'Beneficial Owner 1',
                    dateOfBirth: undefined,
                    firstName: undefined,
                    guid: 'a03a1196-441f-4fc6-ad82-7219ea02fd11',
                    lastName: undefined,
                    middleName: undefined,
                    percentageOfShare: undefined,
                    valueChanges: null,
                    _guid: 'a03a1196-441f-4fc6-ad82-7219ea02fd11'
                }]
            };
        }
        return {
            loadDataSource() {
                return null;
            }
        };
    }
    setBindingData() {
        return null;
    }

    getComponentByFormFieldConfig() {
        return {
            visibility: 'hidden'
        };
    }
}

describe('AddBeneficialOwner', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton', relationships: ['beneficialOwnerList', 'beneficialOwnerAllocation'] };
            expect(action.execute()).toBeFalsy();
        });
    });
});
