import { BaseAction, LocatorService } from '@providers';

export class LoadBeneficiary extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute() {
        return this.parentViewModel;
    }
}
