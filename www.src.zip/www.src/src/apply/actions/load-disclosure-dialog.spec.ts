import { LoadDisclosureDialog } from './load-disclosure-dialog';
import { LocatorService, FormBuilderService, AppContextService, DialogService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { LocaleService } from 'angular-l10n';
import { ApplyModel, InsuredModel } from '@apply/models';

class Action extends LoadDisclosureDialog {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

        if (serviceName === 'appContextService') {
            return new MockAppContextService();
        }

        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

        if (serviceName === 'dialogService') {
            return new MockDialogService();
        }

    }

    get() {
        return new MockLocaleService();
    }
}

class MockLocaleService {
    getCurrentLanguage() {
        return {};
    }
}

class MockDialogService {
    showFormBuilderDialog(DisclosureDialogComponent, DialogShellComponent, dialogData, callback) {
        return callback({});
    }

    closeSpinnerDialog() {
        return {};
    }
}

class MockAppContextService {
    appContext = {
        currentPage: {
            refreshData(callback) {
                return callback({});
            }
        }
    };
}

class MockFormBuilderService {
    getComponentByFormFieldConfig() {
        return {
            loadDataSource() {
                return {};
            }
        };
    }
}

describe('LoadDisclosureDialog', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService },
                { provide: AppContextService, useClass: MockAppContextService },
                { provide: DialogService, useClass: MockDialogService },
                { provide: LocaleService, useClass: MockLocaleService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
        spyOn(action.ls, 'getService').and.callThrough();
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            const model = {
                uwDetails: {},
                person: {
                    basicInfo: {
                        age: 1,
                        gender: 'male',
                        smokingStatus: 'none',
                        height: {
                            unit: 'm'
                        },
                        weight: {
                            unit: 'kg'
                        }
                    }
                }
            } as InsuredModel;
            const parentViewModel = {} as ApplyModel;
            action.viewModel = model;
            action.parentViewModel = parentViewModel;
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});