import { LocatorService, BaseAction } from '@providers';
import { InsuredModel } from '@apply/models';

export class GetCurrentInsuredPerson extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(_params: any): InsuredModel {
        return this.parentViewModel as InsuredModel;
    }
}
