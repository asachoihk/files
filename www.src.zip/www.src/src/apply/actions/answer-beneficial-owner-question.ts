import { BaseAction, LocatorService, FormBuilderService, ActionService } from '@providers';
import { QuestionairePanelComponent } from '@shared/ui-elements';
import { InsuredModel, AgreementModel, BeneficialOwnerModel } from '@apply/models';

export class AnswerBeneficialOwnerQuestion extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    const answer = this.$event.value;
    const questionairePanel = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as QuestionairePanelComponent;

    if (questionairePanel && answer) {
      const answerConfigured = params.answer;
      const viewModel = this.viewModel as InsuredModel;
      const agreement = viewModel.agreement as AgreementModel;
      if (answerConfigured === answer && questionairePanel) {
        const beneficialOwner = new BeneficialOwnerModel();
        agreement.beneficialOwners = [];
        agreement.documents = [];
        beneficialOwner.beneficialNumber = 'Beneficial Owner 1';
        agreement.beneficialOwners.push(beneficialOwner);
        const actionParams = this.ls.getService<ActionService>('actionService').createActionParams(this);
        questionairePanel.loadAnswerComponent('beneficialOwnerForm', actionParams);
      } else {
        agreement.beneficialOwners = [];
        agreement.documents = [];
        questionairePanel.reset();
        this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfigId('beneficialOwnerForm');
        this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfigId('beneficialOwnerList');
        this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByParentFormFieldConfigId('beneficialOwnerList');
        this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfigId('addBeneficialOwner');
        this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfigId('beneficialOwnerAllocation');
        // this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByParentFormFieldConfigId('beneficialOwnerAllocation');
        this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByParentFormFieldConfigId('questionaireBeneficialOwner');
      }
    }
  }
}

export class LoadAnswerBeneficialOwnerQuestion extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    const questionairePanel = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as QuestionairePanelComponent;
    if (questionairePanel) {
      const answerConfigured = params.answer;
      const viewModel = this.viewModel as InsuredModel;
      const agreement = viewModel.agreement as AgreementModel;
      const answer = agreement.answerBO;
      if (answerConfigured === answer) {
        const actionParams = this.ls.getService<ActionService>('actionService').createActionParams(this);
        questionairePanel.loadAnswerComponent('beneficialOwnerForm', actionParams);
      }
    }
  }
}
