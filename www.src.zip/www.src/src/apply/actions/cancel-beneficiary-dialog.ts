import { LocatorService, DialogService, CustomDialogActionType, CustomDialogResult, CancelAction } from '@providers';
import { TranslationService } from 'angular-l10n';
import { CustomDialogComponent } from '@shared/ui-elements';

export class CancelBeneficiaryDialog extends CancelAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const dialogConfig = {
      data: {
        message: this.ls.get(TranslationService).translate('MSGC005'),
        buttons: [
          { title: 'no', type: 'red-outline', action: CustomDialogActionType.no },
          { title: 'yes', type: 'red', action: CustomDialogActionType.yes }
        ]
      }
    };
    this.ls.getService<DialogService>('dialogService').showCustomDialog(CustomDialogComponent, dialogConfig, (result: CustomDialogResult) => {
      if (result.action === CustomDialogActionType.yes) {
        this.dialogRef.close();
      }
    });
  }
}
