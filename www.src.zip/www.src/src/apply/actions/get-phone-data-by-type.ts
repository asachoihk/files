import { BaseAction, LocatorService, PhoneMetadata, FormBuilderService } from '@providers';
import { PhoneNumberModel } from '@apply/models';

export class GetPhoneDataByType extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): PhoneNumberModel {
    const phoneMetadata = this.formFieldConfig.metadata as PhoneMetadata;
    let phoneModels: PhoneNumberModel[] = this.ls.getService<FormBuilderService>('formBuilderService').getBindingData(this.viewModel, this.formFieldConfig.dataBinding.path);
    if (!phoneModels) {
      phoneModels = [];
      this.ls.getService<FormBuilderService>('formBuilderService').setBindingData(this.viewModel, this.formFieldConfig.dataBinding.path, phoneModels);
    }

    let phoneModel = phoneModels.find(p => p.phoneType === phoneMetadata.type);
    if (!phoneModel) {
      phoneModel = new PhoneNumberModel();
      phoneModel.phoneType = phoneMetadata.type;
      phoneModels.push(phoneModel);
    }

    return phoneModel;
  }
}