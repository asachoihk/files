import { LocatorService } from '@providers';
import { CheckSameAsResidentialAddressVisibility } from './check-same-as-residential-address-visibility';
import { TestBed } from '@angular/core/testing';
import { InsuredModel } from '@apply/models';

class Action extends CheckSameAsResidentialAddressVisibility {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {

}

describe('CheckSameAsResidentialAddressVisibility', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            action.viewModel = {
                type: 'i'
            } as InsuredModel;
            expect(action.execute()).toEqual('hidden');
        });
    });
});