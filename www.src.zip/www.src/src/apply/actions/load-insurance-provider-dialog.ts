import { Injectable } from '@angular/core';
import { LocatorService, DialogData } from '@providers';
import { OpenSearchListDialog } from '@shared/actions/search-list/open-search-list-dialog';

@Injectable()
export class LoadInsuranceProviderDialog extends OpenSearchListDialog {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  getDialogData(): DialogData {
    return {
      viewModel: this.viewModel,
      formFieldConfig: this.parentFormFieldConfig,
      params: {
        componentParams: {
          header: 'Search country',
          dataSource: {
            actionName: 'getInsuranceProvider'
          },
          dataSourceMetadata: this.formFieldConfig.dataSourceMetadata
        }
      }
    };
  }

}
