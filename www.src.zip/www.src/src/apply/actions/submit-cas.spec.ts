
import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { SubmitCas } from './submit-cas';

class Action extends SubmitCas {
    formFieldConfig: any;
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService() {
    }
}

describe('SubmitCas', () => {
    let action: Action;
    let ls: LocatorService;


    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });


    describe('Function - Excute', () => {
        it('should be run', () => {
            expect(action.execute()).toBeFalsy();
        });
    });
});
