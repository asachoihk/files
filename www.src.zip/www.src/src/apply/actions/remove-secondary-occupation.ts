import { BaseAction, LocatorService, FormBuilderService, Visibility } from '@providers';
import { ButtonComponent } from '@shared/ui-elements';


export class RemoveSecondaryOccupation extends BaseAction {

  constructor(protected ls: LocatorService) {
    super(ls);
  }
  execute(): any {
    const remove = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as ButtonComponent;
    const secondaryOccupation = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('secondaryOccupation');
    const addButton = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('addIcon');
    if (remove) {
      remove.visibility = Visibility.hidden;
      secondaryOccupation.visibility = Visibility.hidden;
      addButton.visibility = Visibility.visible;
    }
  }
}
