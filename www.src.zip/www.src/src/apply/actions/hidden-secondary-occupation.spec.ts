import { LocatorService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import { HiddenSecondaryOccupation } from './hidden-secondary-occupation';

class Action extends HiddenSecondaryOccupation {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockFormBuilderService {
  getComponentByFormFieldConfig() { return { visibility: ''}; }
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      default:
        break;
    }
  }
}

describe('HiddenSecondaryOccupation', () => {
  let action: Action;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    beforeEach(() => {
      spyOn(action.ls, 'getService').and.callThrough();
    });

    it('should be run', () => {
      action.execute();
      expect(action.ls.getService).toHaveBeenCalled();
    });
  });
});
