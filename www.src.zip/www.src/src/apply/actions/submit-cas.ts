import { LocatorService, BaseAction } from '@providers';

export class SubmitCas extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute() {

    }
}
