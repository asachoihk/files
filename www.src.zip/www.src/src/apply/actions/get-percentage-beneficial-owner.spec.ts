import { GetPercentageBeneficialOwner } from './get-percentage-beneficial-owner';
import { LocatorService } from '@providers';
import { InsuredModel } from '@apply/models/bean/insured/insured.model';

class Action extends GetPercentageBeneficialOwner {
  constructor(protected ls: LocatorService) {
    super(ls);
  }
}

describe('Get Percentage Beneficial Owner', () => {
  let ls: LocatorService;
  let action: Action;

  beforeEach(() => {
    action = new Action(ls);
  });

  describe('Excute get percentage', () => {
    it('should be fun', () => {
      const viewModel = new InsuredModel();
      viewModel.agreement.beneficialOwners = [];
      action.viewModel = viewModel;
      expect(action.execute()).toEqual([]);
    });
  });
})