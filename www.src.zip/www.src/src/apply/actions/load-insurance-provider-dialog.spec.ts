import { LoadInsuranceProviderDialog } from './load-insurance-provider-dialog';
import { LocatorService } from '@providers';
import { TestBed } from '@angular/core/testing';

class Action extends LoadInsuranceProviderDialog {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {

}

describe('LoadInsuranceProviderDialog', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - getDialogData', () => {
        it('should be run', () => {
            action.viewModel = {} as any;
            action.parentFormFieldConfig = {} as any;
            action.formFieldConfig = {
                dataSourceMetadata: {}
            } as any;
            expect(action.getDialogData()).toEqual({
                viewModel: action.viewModel,
                formFieldConfig: action.parentFormFieldConfig,
                params: {
                    componentParams: {
                        header: 'Search country',
                        dataSource: {
                            actionName: 'getInsuranceProvider'
                        },
                        dataSourceMetadata: action.formFieldConfig.dataSourceMetadata
                    }
                }
            });
        });
    });
});