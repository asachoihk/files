import { BaseAction, LocatorService, FileUploadMetadata, ID_TYPE } from '@providers';
import { InsuredModel } from '@apply/models';

export class GetIdentificationUploadMetadata extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params: any): FileUploadMetadata {
        const metadata = this.formFieldConfig.metadata as FileUploadMetadata;
        const insuredPerson = this.viewModel as InsuredModel;
        const idType = insuredPerson.person.registration && insuredPerson.person.registration.idType ? insuredPerson.person.registration.idType : ID_TYPE.ID;

        switch (idType) {
            case ID_TYPE.ID:
                metadata.min = params.id;
                break;
            case ID_TYPE.Military_Card:
                metadata.min = params.militaryCard;
                break;
            case ID_TYPE.Passport:
                metadata.min = params.passport;
                break;
            case ID_TYPE.Birth_Certificate:
                metadata.min = params.birthCertificate;
                break;
        }

        return metadata;
    }
}