import { BaseAction, LocatorService, InsuredType, FormBuilderService, SystemEventService, Visibility, ControlValueChanged } from '@providers';
import { InsuredModel } from '@apply/models';
import { BaseUiElement, BaseComponent, BaseControlComponent } from '@shared/ui-elements';

export class CheckInsuredType extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    setTimeout(() => {
      const vm = this.viewModel as InsuredModel;

      if (vm.type === InsuredType.r) {
        this.component.visibility = Visibility.hidden;
        this.hideChildren(this.component);
      } else {
        if (params === 'PO') {
          this.component.visibility = Visibility.hidden;
          this.hideChildren(this.component);
        }
      }

      if (this.component.formControl) {
        this.ls.getService<SystemEventService>('systemEventService').publish(new ControlValueChanged(this.component.formControl));
      }
    }, 2000);
    return this.component && this.component.visibility ? this.component.visibility : Visibility.visible;
  }

  private hideChildren(component: BaseUiElement) {
    if (component instanceof BaseComponent) {
      const controls = this.ls.getService<FormBuilderService>('formBuilderService').getChildComponentsByFormFieldConfig(component.formFieldConfig) as BaseUiElement[];
      controls.forEach(c => {
        this.hideChildren(c);
      });

    }
    if (component instanceof BaseControlComponent) {
      component.visibility = Visibility.hidden;
    }
  }
}
