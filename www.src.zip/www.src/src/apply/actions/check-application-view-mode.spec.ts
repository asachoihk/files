import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { CheckApplicationViewMode } from './check-application-view-mode';
import { of } from 'rxjs/internal/observable/of';


class Action extends CheckApplicationViewMode {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() {}

    getService(serviceName: string) {
        return serviceName === 'applicationService' ? new MockApplicationService() : new MockSystemEventService();
    }
}

class MockSystemEventService {
    publish() {
        return of({});
    }
}

class MockApplicationService {
    isApplicationReadOnlyMode() {
        return true;
    }
}

describe('CheckApplicationViewMode', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be created', () => {
            expect(action.execute()).toBeFalsy();
        });
    });
});
