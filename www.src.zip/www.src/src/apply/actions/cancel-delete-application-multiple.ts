import { LocatorService, SystemEventService, BaseAction, FormBuilderService } from '@providers';
import { TableComponent, SearchBarComponent } from '@shared/ui-elements';

export class CancelDeleteApplicationMultiple extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    this.ls.getService<SystemEventService>('systemEventService').tempEventDeleteMultiCustomer.next(false);
    const applicationsFieldId = params && params.applicationsFieldId ? params.applicationsFieldId : this.formFieldConfig.id;
    const tableComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(applicationsFieldId) as TableComponent;
    const searchComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('searchBar') as SearchBarComponent;
    if (tableComponent && searchComponent) {
      tableComponent.loadDataSource(searchComponent.textSearch);
    }
  }
}
