import { LocatorService, BaseAction } from '@providers';
import { ApplicationService } from '@apply/services';

export class GetBasicInfoPageTitle extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(): string {
        const currentApp = this.ls.getService<ApplicationService>('applicationService').getCurrentApplyData();
        return currentApp.basicPlan.name;
    }
}
