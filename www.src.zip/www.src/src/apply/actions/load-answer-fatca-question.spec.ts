import { LocatorService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import { InsuredModel } from '@apply/models';
import { LoadAnswerFatcaQuestion } from './load-answer-fatca-question';

class Action extends LoadAnswerFatcaQuestion {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockFormBuilderService {
  getComponentByFormFieldConfig() {
    return {
      reset: () => { },
      loadAnswerComponent: () => { }
    };
  }
}

class MockActionService {
  createActionParams() { return {}; }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'actionService':
        return new MockActionService();
      default:
        break;
    }
  }
}

describe('LoadAnswerFatcaQuestion', () => {
  let action: Action;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    beforeEach(() => {
      spyOn(action.ls, 'getService').and.callThrough();
      action.viewModel = new InsuredModel();
    });

    it('should be run', () => {
      action.viewModel['agreement']['anwserFatca'] = 'yes';
      action.viewModel['person']['basicInfo']['citizenship'] = 'US';

      const params = { answer: 'yes' };
      action.execute(params);
      expect(action.ls.getService).toHaveBeenCalled();
    });

    it('should be run anwserFatca !== answer', () => {
      action.viewModel['agreement']['anwserFatca'] = 'yes';
      action.viewModel['person']['basicInfo']['citizenship'] = 'US';

      const params = { answer: 'no' };
      action.execute(params);
      expect(action.ls.getService).toHaveBeenCalled();
    });

    it('should be run without anwserFatca ', () => {
      action.viewModel['person']['basicInfo']['citizenship'] = 'US';

      const params = { answer: 'yes' };
      action.execute(params);
      expect(action.ls.getService).toHaveBeenCalled();
    });
  });
});
