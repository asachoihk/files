import { LocatorService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import { GetSourceOfFunds } from './get-source-of-funds';

class Action extends GetSourceOfFunds {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockJsonConfigService {
  getSourceOfFunds(): any { return { }; }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'jsonConfigService':
        return new MockJsonConfigService();
      default:
        break;
    }
  }
}

describe('GetSourceOfFunds', () => {
  let action: Action;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      action.execute().subscribe(result => {
        expect(result).toBeDefined();
      });
    });
  });
});
