import { LocatorService, FormBuilderService, BaseModel } from '@providers';
import { CheckWarning } from './check-warning';
import { TestBed } from '@angular/core/testing';

class Action extends CheckWarning {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {

        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

    }
}

class MockFormBuilderService {
    getDisplayValue() {
        return;
    }

    getComponentByFormFieldConfigId() {
        return;
    }

    setFormFieldValue() {
        return;
    }
}

describe('CheckWarning', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run - getDisplayValue return NaN value', () => {
            const params = {
                type: 'height',
                min: 0,
                max: 10
            };
            spyOn(action.ls, 'getService').and.callThrough();
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be run - getDisplayValue return numberic value - (min <= value && value <= max) === false - type === height ', () => {
            const params = {
                type: 'height',
                min: 0,
                max: 10
            };
            const model = {
                notifyValueChanges() {
                    return;
                }
            };
            action.viewModel = model as BaseModel;
            spyOn(action.ls, 'getService').and.returnValue({
                getDisplayValue() {
                    return 20;
                },
                getComponentByFormFieldConfigId() {
                    return {
                        formFieldConfig: {}
                    };
                },
                setFormFieldValue() {
                    return;
                }
            });
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be run - getDisplayValue return numberic value - (min <= value && value <= max) === true ', () => {
            const params = {
                type: 'weight',
                min: 0,
                max: 10
            };
            const model = {
                notifyValueChanges() {
                    return;
                }
            };
            action.viewModel = model as BaseModel;
            spyOn(action.ls, 'getService').and.returnValue({
                getDisplayValue() {
                    return 5;
                },
                getComponentByFormFieldConfigId() {
                    return {
                        formFieldConfig: {}
                    };
                },
                setFormFieldValue() {
                    return;
                }
            });
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});