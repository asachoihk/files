import { BaseAction, LocatorService, CustomDialogConfig, CustomDialogActionType, DialogService, CustomDialogResult, GlobalNavigationService, ActionService, AppContextService } from '@providers';
import { CustomDialogComponent, FormBuilderPage } from '@shared/ui-elements';
import { TranslationService } from 'angular-l10n';
import { InsuredPersonService } from '@apply/services';
import { ApplyModel } from '@apply/models';
import { ApplySection } from '@apply/const';

export class CheckApplicationChanges extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    const url = params.url;
    const msg = params.confirmMessage || 'MSGA025';
    const autoSave = params.autoSave;
    const currentPage = this.ls.getService<AppContextService>('appContextService').currentFormBuilder;
    if (currentPage && currentPage.hasChanges) {
      if (currentPage.id === ApplySection.SIGNATURE.toString()) {
        const dialogConfig: CustomDialogConfig = {
          disableClose: true,
          data: {
            message: this.ls.get(TranslationService).translate('MSGA034'),
            buttons: [
              { title: 'yes', type: 'red', action: CustomDialogActionType.yes },
              { title: 'no', type: 'red-outline', action: CustomDialogActionType.no }
            ]
          }
        };
        this.ls.getService<DialogService>('dialogService').showCustomDialog(CustomDialogComponent, dialogConfig, (result: CustomDialogResult) => {
          if (result.action === CustomDialogActionType.yes) {
            this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo(url);
          }
        });
      } else {
        if (autoSave) {
          this.saveApplication(currentPage, url);
        } else {
          const dialogConfig: CustomDialogConfig = {
            disableClose: true,
            data: {
              message: this.ls.get(TranslationService).translate(msg),
              buttons: [
                { title: 'save', type: 'red', action: CustomDialogActionType.yes },
                { title: 'dontSave', type: 'red', action: CustomDialogActionType.no },
                { title: 'cancel', type: 'red-outline', action: CustomDialogActionType.cancel }
              ]
            }
          };
          this.ls.getService<DialogService>('dialogService').showCustomDialog(CustomDialogComponent, dialogConfig, (result: CustomDialogResult) => {
            if (result.action === CustomDialogActionType.yes) {
              this.saveApplication(currentPage, url);
            } else if (result.action === CustomDialogActionType.no) {
              this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo(url);
            }
          });
        }
      }
    } else {
      this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo(url);
    }
  }

  private saveApplication(currentPage: FormBuilderPage, url: string) {
    if (currentPage.id === ApplySection.BASIC_INFO.toString()) {
      this.ls.getService<InsuredPersonService>('insuredPersonService').filterBeneficiaries(currentPage.viewModel as ApplyModel);
    }
    this.ls.getService<ActionService>('actionService').executeAction('saveApplicationAndContinue', { viewModel: currentPage.viewModel }, { ignoreGoToNextPage: true }, () => {
      this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo(url);
    });
  }
}
