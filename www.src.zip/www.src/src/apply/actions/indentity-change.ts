import { LocatorService, SystemEventService, BaseAction } from '@providers';
import { DocumentType } from 'providers/enums/document-type.enum';
import { DocumentDeleted } from 'providers/models/system-event/document-deleted';
import { InsuredModel } from '@apply/models';

export class IndentityChange extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const viewModel = this.viewModel as InsuredModel;
    const registration = viewModel.person.registration;
    registration.idNo = null;
    registration.issueDate = null;
    registration.issuePlace = null;
    viewModel.person.registrations = [registration];
    viewModel.documents = (viewModel.documents || []).filter(d => d.type !== DocumentType.IMPORTANT);
    this.ls.getService<SystemEventService>('systemEventService').publish(new DocumentDeleted(viewModel));
  }
}
