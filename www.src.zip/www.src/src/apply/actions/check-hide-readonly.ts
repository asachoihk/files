import { BaseAction, LocatorService, Visibility } from '@providers';
import { ApplicationService } from '@apply/services';


export class CheckHideReadonly extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    return this.ls.getService<ApplicationService>('applicationService').isApplicationReadOnlyMode() ? Visibility.hidden : Visibility.visible;
  }
}
