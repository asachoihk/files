
import { TestBed, async } from '@angular/core/testing';
import { LocatorService, CustomerService, SystemEventService, ValidatorService } from '@providers';
import { SaveBeneficiaryPerson } from './save-beneficiary-person';
import { Observable } from 'rxjs';
import { ApplyModel, BeneficiaryModel } from '@apply/models';
import { ActivatedRoute } from '@angular/router';
import { TranslationService } from 'angular-l10n';
import { ApplicationService } from '@apply/services';

class Action extends SaveBeneficiaryPerson {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}


class MockActivatedRoute {
  constructor() { }

  snapshot = {
    queryParams: {
      applicationId: '18072433-c834-755a-9372-6826ef99f9fb',
      customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab'
    }
  };
}

class MockCustomerService {
  constructor() { }

  getCurrent() {
    return {
      customerId: ''
    };
  }
}

class MockTranslationService {
  constructor() { }

  translate() {
    return 'MSGC021';
  }
}

class MockSystemEventService {
  constructor() { }

  publish() {
  }
}

class MockApplicationService {
  constructor() { }

  saveApplyData(customerId: string, applyModels: ApplyModel[], isAddNew?: boolean): Observable<any[]> {
    return new Observable(subscriber => {
      return subscriber.next([{}]);
    });
  }

  getCurrentApplyData() {
    return {
      beneficiaries: [
        { guid: '123' },
        { guid: '456' }
      ]
    };
  }
}

class MockValidatorService {
  constructor() { }

  validateForm() { }
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'activatedRoute':
        return new MockActivatedRoute();
      case 'customerService':
        return new MockCustomerService();
      case 'translationService':
        return new MockTranslationService();
      case 'systemEventService':
        return new MockSystemEventService();
      case 'applicationService':
        return new MockApplicationService();
      case 'validatorService':
        return new MockValidatorService();
      default:
        break;
    }
  }

  get() {
    return new MockActivatedRoute();
  }
}

describe('SaveBeneficiaryPerson', () => {
  let action: Action;
  let ls: LocatorService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: ActivatedRoute, useClass: MockActivatedRoute },
        { provide: CustomerService, useClass: MockCustomerService },
        { provide: TranslationService, useClass: MockTranslationService },
        { provide: SystemEventService, useClass: MockSystemEventService },
        { provide: ApplicationService, useClass: MockApplicationService },
        { provide: ValidatorService, useClass: MockValidatorService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run', async(
      () => {
        const params = {};
        action.viewModel = new BeneficiaryModel();
        expect(action.execute(params).subscribe()).toBeTruthy();
      })
    );

    it('should be run when isDelete= true',
      () => {
        const params = { params: { isDelete: true } };
        const formId = 'ds';
        action.viewModel = new BeneficiaryModel();
        expect(action.validateForm(formId, params)).toBeFalsy();
      }
    );

    it('should be run for ignoreValidationResult function', () => {
      const params = { params: { isDelete: true } };
      expect(action.ignoreValidationResult(params)).toBeTruthy();
    });

    it('should be run isDelete: false',
      () => {
        const params = { params: { isDelete: false } };
        const formId = 'ds';
        action.viewModel = new BeneficiaryModel();
        expect(action.validateForm(formId, params)).toBeFalsy();
      }
    );
  });
});
