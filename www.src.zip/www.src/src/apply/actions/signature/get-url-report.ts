import { LocatorService, AppConfigService, BaseAction, ReportFormsModel } from '@providers';
import { environment } from '@env/environment';

export class GetUrlReport extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): string {
    const viewModel = this.viewModel as ReportFormsModel;
    let serviceUrl = `${this.ls.getService<AppConfigService>('appConfigService').entity}application/attachment?fileType=application/pdf&reportType=${viewModel.type}`;
    if (environment.isWeb) {
      // call api SF
      serviceUrl = `${this.ls.getService<AppConfigService>('appConfigService').getAttachments}/${viewModel.serverId}?contentType=application/pdf`;
    }
    return serviceUrl;
  }
}
