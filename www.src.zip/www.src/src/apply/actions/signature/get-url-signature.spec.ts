import { LocatorService, AppConfigService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import 'rxjs/add/observable/of';
import { ReportFormsModel } from 'providers/models/bean/report-forms';
import { environment } from '@env/environment';
import { GetUrlSignature } from './get-url-signature';
import { SignatureModel } from '@apply/models';
import { SignatureType } from '@apply/enums';

class Action extends GetUrlSignature {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockAppConfigService {
  entity = 'entity/';
  getAttachments = 'getAttachments';
  constructor() {
  }
}
class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'appConfigService':
        return new MockAppConfigService();
      default:
        break;
    }
  }
}

describe('GetUrlSignature', () => {
  let action: Action;
  const formFieldConfig = { id: 'proceedSignature', type: 'button', label: 'Proceed_Signature' };
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: AppConfigService, useClass: MockAppConfigService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute Local', () => {
    it('should be run', () => {
      action.formFieldConfig = formFieldConfig;
      const viewModel = new SignatureModel();
      viewModel.attachmentID = 'c123';
      viewModel.type = SignatureType.agent;
      action.viewModel = viewModel;
      environment.isWeb = false;
      expect(action.execute()).toEqual('entity/application/attachment?fileType=image/png&reportType=agentSignature');
    });
  });

  describe('Function - Excute PCF', () => {
    it('should be run', () => {
      action.formFieldConfig = formFieldConfig;
      const viewModel = new SignatureModel();
      viewModel.attachmentID = 'c123';
      viewModel.type = SignatureType.agent;
      action.viewModel = viewModel;
      environment.isWeb = true;
      expect(action.execute()).toEqual('getAttachments/c123?contentType=image/png');
    });
  });

  describe('Function - Excute PCF', () => {
    it('should be run', () => {
      action.formFieldConfig = formFieldConfig;
      const viewModel = new SignatureModel();
      viewModel.sign = 'qwerty';
      action.viewModel = viewModel;
      environment.isWeb = true;
      expect(action.execute()).toEqual('qwerty');
    });
  });
});
