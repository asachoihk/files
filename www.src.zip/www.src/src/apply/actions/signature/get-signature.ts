import { LocatorService, FormBuilderService, CustomDialogResult, CustomDialogActionType, BaseAction } from '@providers';
import { SignatureComponent } from '@apply/components';

export class GetSignature extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): void {
    const formFieldConfig = this.formFieldConfig;
    if (formFieldConfig.relationships && formFieldConfig.relationships.length) {
      const signComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(formFieldConfig.relationships[0]) as SignatureComponent;

      const image = signComponent.getImageData();

      if (image) {
        const result: CustomDialogResult = {
          action: CustomDialogActionType.yes,
          data: {
            sign: image,
            hasChanges: signComponent.hasChanges
          }
        };
        this.dialogRef.close(result);
      } else {
        this.dialogRef.close();
      }
    }
  }
}
