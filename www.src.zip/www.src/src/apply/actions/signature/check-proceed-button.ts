import { LocatorService, FormBuilderService, BaseAction, Visibility } from '@providers';
import { ButtonComponent } from '@shared/ui-elements';
import { ApplicationService } from '@apply/services';

export class CheckProceedButton extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const proceedButton = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(this.formFieldConfig.id) as ButtonComponent;
    if (proceedButton) {

      proceedButton.visibility = this.ls.getService<ApplicationService>('applicationService').isApplicationReadOnlyMode() ? Visibility.hidden : Visibility.visible;
      if (proceedButton.visibility === Visibility.hidden) {
        return;
      }
      proceedButton.visibility = Visibility.disabled;
    }
  }
}
