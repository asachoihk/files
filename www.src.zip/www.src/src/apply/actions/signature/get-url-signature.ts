import { LocatorService, AppConfigService, BaseAction } from '@providers';
import { SignatureModel } from '@apply/models/bean/signature/signature.model';
import { environment } from '@env/environment';

export class GetUrlSignature extends BaseAction {

  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const viewModel = this.viewModel as SignatureModel;
    if (viewModel.attachmentID) {
      let serviceUrl = `${this.ls.getService<AppConfigService>('appConfigService').entity}application/attachment?fileType=image/png&reportType=${viewModel.type}`;
      if (environment.isWeb) {
        // call api SF
        serviceUrl = `${this.ls.getService<AppConfigService>('appConfigService').getAttachments}/${viewModel.attachmentID}?contentType=image/png`;
      }
      return serviceUrl;
    }
    return viewModel.sign;
  }
}
