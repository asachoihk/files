import { LocatorService, BaseAction } from '@providers';
import { SignatureModel } from '@apply/models/bean/signature/signature.model';

export class GetCurrentSignature extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): SignatureModel {
    return this.parentViewModel as SignatureModel;
  }
}
