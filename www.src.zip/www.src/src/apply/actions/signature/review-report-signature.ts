import { LocatorService, DialogService, BaseAction, ActionService } from '@providers';
import { DialogShellComponent } from '@shared/shells/dialog-shell/dialog-shell.component';
import { DialogReportComponent } from '@shared/components/dialog-report/dialog-report.component';

export class ReviewReportSignature extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): void {
    const actionData = this.ls.getService<ActionService>('actionService').createActionParams(this);
    this.ls.getService<DialogService>('dialogService').showFormBuilderDialog(DialogReportComponent, DialogShellComponent, actionData, (_result: any) => {
    });
  }
}


