import { LocatorService, AppConfigService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import 'rxjs/add/observable/of';
import { GetUrlReport } from './get-url-report';
import { ReportFormsModel } from 'providers/models/bean/report-forms';
import { environment } from '@env/environment';

class Action extends GetUrlReport {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockAppConfigService {
  entity = 'entity';
  getAttachments = 'getAttachments';
  constructor() {
  }
}
class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'appConfigService':
        return new MockAppConfigService();
      default:
        break;
    }
  }
}

describe('GetUrlReport', () => {
  let action: Action;
  const formFieldConfig = { id: 'proceedSignature', type: 'button', label: 'Proceed_Signature' };
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: AppConfigService, useClass: MockAppConfigService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute Local', () => {
    it('should be run', () => {
      action.formFieldConfig = formFieldConfig;
      const viewModel = new ReportFormsModel();
      viewModel.type = 'pdf';
      viewModel.serverId = 'c123';
      action.viewModel = viewModel;
      environment.isWeb = false;
      expect(action.execute()).toEqual('entityapplication/attachment?fileType=application/pdf&reportType=pdf');
    });
  });

  describe('Function - Excute PCF', () => {
    it('should be run', () => {
      action.formFieldConfig = formFieldConfig;
      const viewModel = new ReportFormsModel();
      viewModel.type = 'pdf';
      viewModel.serverId = 'c123';
      action.viewModel = viewModel;
      environment.isWeb = true;
      expect(action.execute()).toEqual('getAttachments/c123?contentType=application/pdf');
    });
  });
});
