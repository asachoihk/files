import { LocatorService, DialogService, CustomDialogActionType, CustomDialogResult, BaseAction, GlobalNavigationService, APPLICATION_STATUS, CustomerService } from '@providers';
import { TranslationService } from 'angular-l10n';
import { CustomDialogComponent } from '@shared/ui-elements';
import * as _ from 'lodash';
import { ApplyModel } from '@apply/models';
import { ApplicationService, ProgressService } from '@apply/services';
import { DOCUMENT_MODEL } from '@apply/const/apply.const';

export class ProceedToSubmissionDialog extends BaseAction {

  viewModelClone: ApplyModel;
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const viewModel = this.viewModel as ApplyModel;

    if (viewModel.status === APPLICATION_STATUS.INPROGRESS) {
      this.viewModelClone = _.cloneDeepWith(viewModel);
      const reportForms = viewModel.report_forms;
      const dialogConfig = {
        data: {
          message: this.ls.get(TranslationService).translate('MSGA055'),
          buttons: [
            { title: this.ls.get(TranslationService).translate('cancel'), type: 'red-outline', action: CustomDialogActionType.no },
            { title: this.ls.get(TranslationService).translate('confirm'), type: 'red', action: CustomDialogActionType.yes }
          ]
        }
      };
      this.ls.getService<DialogService>('dialogService').showCustomDialog(CustomDialogComponent, dialogConfig, (result: CustomDialogResult) => {
        if (result.action === CustomDialogActionType.yes) {
          this.ls.getService<DialogService>('dialogService').showSpinnerDialog();

          const applyData = this.ls.getService<ApplicationService>('applicationService').getCurrentApplyData();
          applyData.report_forms = reportForms;
          applyData.status = APPLICATION_STATUS.SIGNED;

          this.ls.getService<ProgressService>('progressService').updateSectionProgress(applyData, 100);
          this.ls.getService<ApplicationService>('applicationService').saveApplyData(viewModel.customerId, [applyData]).subscribe(resultSave => {
            this.ls.getService<DialogService>('dialogService').closeSpinnerDialog();
            if (resultSave) {
              // push new serverId RPQ and FNA report to customerData
              const reportsCustomer = this.ls.getService<CustomerService>('customerService').getCurrent().customerData.reports;
              applyData.report_forms.forEach(item => {
                if (item.type === DOCUMENT_MODEL.FINANCIAL) {
                  reportsCustomer.fna.push({ serverId: item.serverId, status: APPLICATION_STATUS.SIGNED });
                } else if (item.type === DOCUMENT_MODEL.RISKPROFILE_QUESTIONAIRE) {
                  reportsCustomer.rpq.push({ serverId: item.serverId, status: APPLICATION_STATUS.SIGNED });
                }
              });
              this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission');
            } else {
              this.handlerError('save application error');
            }
          },
            error => {
              this.handlerError(error);
            });
        }
      });
    } else {
      this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission');
    }
  }

  handlerError(error) {
    console.log(error);
    this.viewModel = this.viewModelClone;
    this.viewModel.notifyValueChanges();
    this.ls.getService<DialogService>('dialogService').closeSpinnerDialog();
  }
}
