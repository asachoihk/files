import { LocatorService, AppContextService, FormBuilderService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import 'rxjs/add/observable/of';
import { CheckProceedButton } from './check-proceed-button';
import { ApplicationService } from '@apply/services';

class Action extends CheckProceedButton {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockFormBuilderService {
  constructor() { }

  getComponentByFormFieldConfigId(configId: string) {
    return {};
  }
}

class MockApplicationService {
  constructor() {
  }

  isApplicationReadOnlyMode() {
    return true;
  }
}
class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'applicationService':
        return new MockApplicationService();
      default:
        break;
    }
  }
}

describe('CheckProceedButton', () => {
  let action: Action;
  const formFieldConfig = { id: 'proceedSignature', type: 'button', label: 'Proceed_Signature' };
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: ApplicationService, useClass: MockApplicationService },
        { provide: FormBuilderService, useClass: MockFormBuilderService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      action.formFieldConfig = formFieldConfig;
      spyOn( action.ls, 'getService' ).and.returnValue({
        getComponentByFormFieldConfigId(configId: string) {
          return {};
        },
        isApplicationReadOnlyMode() {
          return false;
        }
      });
      expect(action.execute());
    });
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      action.formFieldConfig = formFieldConfig;
      spyOn( action.ls, 'getService' ).and.returnValue({
        getComponentByFormFieldConfigId(configId: string) {
          return {};
        },
        isApplicationReadOnlyMode() {
          return true;
        }
      });
      expect(action.execute());
    });
  });
});
