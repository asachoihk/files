import { LocatorService, BaseAction, ReportFormsModel } from '@providers';

export class GetCurrentReport extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): ReportFormsModel {
    return this.parentViewModel as ReportFormsModel;
  }
}
