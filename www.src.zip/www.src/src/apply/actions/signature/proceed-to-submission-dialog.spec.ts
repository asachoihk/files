import { ProceedToSubmissionDialog } from './proceed-to-submission-dialog';
import { LocatorService, DialogService, GlobalNavigationService } from '@providers';
import { TranslationService } from 'angular-l10n';
import { defer } from 'rxjs';
import * as _ from 'lodash';
import { ApplicationService, ProgressService } from '@apply/services';
import { TestBed } from '@angular/core/testing';
import { ApplyModel } from '@apply/models';

class Action extends ProceedToSubmissionDialog {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'translationService') {
            return new MockTranslationService();
        }

        if (serviceName === 'dialogService') {
            return new MockDialogService();
        }

        if (serviceName === 'applicationService') {
            return new MockApplicationService();
        }

        if (serviceName === 'progressService') {
            return new MockProgressService();
        }

        if (serviceName === 'globalNavigationService') {
            return new MockGlobalNavigationService();
        }

    }

}

class MockDialogService {
    showCustomDialog(CustomDialogComponent, dialogConfig, callback) {
        return callback({
            action: 'yes'
        });
    }

    showSpinnerDialog() {
        return;
    }

    closeSpinnerDialog() {
        return;
    }
}

class MockApplicationService {
    getCurrentApplyData() {
        return {
            report_forms: {},
            status: 'SIGNED'
        };
    }

    saveApplyData() {
        return defer(() => Promise.resolve({
            resultSave: 'abc'
        }));
    }
}

class MockTranslationService {
    translate() {
        return 'translated text';
    }
}

class MockProgressService {
    updateSectionProgress() {
        return {};
    }
}

class MockGlobalNavigationService {
    navigateTo() {
        return {};
    }
}

describe('ProceedToSubmissionDialog', () => {
    let action: Action;
    let ls;
    let translationService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ApplicationService, useClass: MockApplicationService },
                { provide: DialogService, useClass: MockDialogService },
                { provide: GlobalNavigationService, useClass: MockGlobalNavigationService },
                { provide: ProgressService, useClass: MockProgressService },
                { provide: TranslationService, useClass: MockTranslationService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run - result.action === CustomDialogActionType.yes - resultSave === true', () => {
            const model = {
                status: 'APPLICATION_INPROGRESS',
                customerId: 'abc',
                report_forms: {},
                notifyValueChanges() {
                    return;
                }
            };
            action.viewModel = model as ApplyModel;
            action.execute();
            spyOn(action.ls, 'getService').and.callThrough();
            expect(action.ls.getService).toBeTruthy();
        });
    });

    describe('Function - Excute', () => {
        it('should be run - result.action === CustomDialogActionType.yes - resultSave === false', () => {
            const model = {
                status: 'APPLICATION_INPROGRESS',
                customerId: 'abc',
                report_forms: {},
                notifyValueChanges() {
                    return;
                }
            };

            spyOn(action.ls, 'getService').and.returnValue({
                saveApplyData() {
                    return defer(() => Promise.resolve());
                },
                translate() {
                    return 'translated text';
                },
                showCustomDialog(CustomDialogComponent, dialogConfig, callback) {
                    return callback({
                        action: 'yes'
                    });
                },
                showSpinnerDialog() {
                    return;
                },
                getCurrentApplyData() {
                    return {
                        report_forms: {},
                        status: 'SIGNED'
                    };
                },
                updateSectionProgress() {
                    return {};
                }
            });
            action.viewModel = model as ApplyModel;
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });

    describe('Function - Excute', () => {
        it('should be run - result.action === CustomDialogActionType.no', () => {
            const model = {
                status: '',
                customerId: 'abc',
                report_forms: {},
                notifyValueChanges() {
                    return;
                }
            };
            action.viewModel = model as ApplyModel;
            action.execute();
            expect(action.ls.getService).toBeTruthy();
        });
    });

    describe('Function - handlerError', () => {
        it('should be run', () => {
            const model = {
                status: 'APPLICATION_INPROGRESS',
                customerId: 'abc',
                report_forms: {},
                notifyValueChanges() {
                    return;
                }
            };
            const error = {} as any;
            action.viewModel = model as any;
            action.viewModelClone = _.cloneDeepWith(action.viewModel) as any;
            action.handlerError(error);
            expect(action.ls.getService).toBeTruthy();
        });
    });
});
