import { LocatorService, DialogService, CustomDialogResult, BaseAction, ActionService, FormBuilderService, Visibility, APPLICATION_STATUS } from '@providers';
import { ButtonComponent, ReportListComponent } from '@shared/ui-elements';
import { DialogShellComponent } from '@shared/shells';
import { TaskCardListComponent } from '@shared/components';
import { SignatureModel, ApplyModel } from '@apply/models';
import { ReportSignatureService } from '@apply/services';
import { SignatureDialogComponent } from '@apply/components';
import { ApplyServiceNames } from '@apply/const';

export class ShowDialogSignature extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): void {
    const actionData = this.ls.getService<ActionService>('actionService').createActionParams(this);
    const applyData = actionData.parentViewModel as ApplyModel;
    let hasSignatured = false;
    if (applyData) {
      hasSignatured = applyData.status !== APPLICATION_STATUS.INPROGRESS;
    }
    if (!hasSignatured) {
      actionData.width = '720px';
      actionData.height = '535px';
      this.ls.getService<DialogService>('dialogService').showFormBuilderDialog(SignatureDialogComponent, DialogShellComponent, actionData, (result: any) => {
        if (result) {
          this.getSignatureResult(result);
          const listSignature = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(this.formFieldConfig.id) as TaskCardListComponent;
          if (result && result.data && result.data.hasChanges) {
            listSignature.hasChanges = true;
          }

          const personNotSigns = listSignature.taskCardViewModels.filter(sign => !sign.sign);
          if (!personNotSigns || personNotSigns.length === 0) {
            const buttonID = this.formFieldConfig.relationships[0];
            const proceedButton = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(buttonID) as ButtonComponent;
            proceedButton.visibility = Visibility.visible;
            proceedButton.disabled = false;
          }

          listSignature.loadDataSource();
          this.ls.getService<DialogService>('dialogService').showSpinnerDialog();
          this.ls.getService<ReportSignatureService>(ApplyServiceNames.reportSignatureService).mergeSignatureToReport(applyData.original_report_forms, applyData.report_forms, applyData.signatures, applyData.applicationId, applyData.customerId).subscribe(
            data => {
              if (data) {
                applyData.report_forms = data.sort((a, b) => (a.header > b.header) ? 1 : -1);
                const reportList = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('reportList') as ReportListComponent;
                if (reportList) {
                  reportList.loadDataSource(data);
                }
              }
              this.ls.getService<DialogService>('dialogService').closeSpinnerDialog();
            },
            error => {
              console.log('can not merge signature', error);
              this.ls.getService<DialogService>('dialogService').closeSpinnerDialog();
            }
          );
        }
      });
    }
  }

  getSignatureResult(result: CustomDialogResult) {
    if (result && result.data && result.data.sign) {
      const viewModel = this.viewModel as SignatureModel;
      viewModel.sign = result.data.sign;
    }
  }
}


