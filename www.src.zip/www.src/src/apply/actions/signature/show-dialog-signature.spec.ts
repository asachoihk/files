import { ShowDialogSignature } from './show-dialog-signature';
import { LocatorService, FormBuilderService, ActionService, DialogService, CustomDialogResult } from '@providers';
import { ApplyModel, SignatureModel } from '@apply/models';
import { TestBed } from '@angular/core/testing';
import { defer } from 'rxjs';

class Action extends ShowDialogSignature {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'actionService') {
            return new MockActionService();
        }

        if (serviceName === 'dialogService') {
            return new MockDialogService();
        }

        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

        if (serviceName === 'dialogService') {
            return new MockDialogService();
        }

    }

    get() {
        return new MockReportSignatureService();
    }

}

class MockReportSignatureService {
    mergeSignatureToReport() {
        return defer(() => Promise.resolve({
            data: 'abc'
        }));
    }
}

class MockActionService {
    createActionParams() {
        return {
            width: '720px',
            height: '535px',
            parentViewModel: {
                status: 'APPLICATION_INPROGRESS'
            } as ApplyModel
        };
    }
}

class MockDialogService {
    showFormBuilderDialog(SignatureDialogComponent, DialogShellComponent, actionData, callback) {
        return callback({
            data: {
                hasChanges: true
            }
        });
    }

    showSpinnerDialog() {
        return {};
    }

    closeSpinnerDialog() {
        return {};
    }
}

class MockFormBuilderService {
    getComponentByFormFieldConfigId() {
        return {
            loadDataSource() {
                return {};
            },
            hasChanges: false,
            taskCardViewModels: [
                {
                    sign: true
                }
            ]
        };
    }
}

describe('ShowDialogSignature', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService },
                { provide: ActionService, useClass: MockActionService },
                { provide: DialogService, useClass: MockDialogService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
        spyOn(action.ls, 'getService').and.callThrough();
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            const result = {
                data: {
                    sign: 'abc'
                } as SignatureModel
            } as CustomDialogResult;

            const formFieldConfig = {
                id: 'abc',
                relationships: ['abc', 'xyz']
            };
            action.viewModel = result.data;
            action.formFieldConfig = formFieldConfig as any;
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });

    describe('Function - getSignatureResult', () => {
        it('should be run', () => {
            const result = {
                data: {
                    sign: 'abc'
                } as SignatureModel
            } as CustomDialogResult;

            const formFieldConfig = {
                id: 'abc'
            };
            action.viewModel = result.data;
            action.formFieldConfig = formFieldConfig as any;
            // action.viewModel.sign = result.data.sign;
            action.getSignatureResult(result);
            expect(action.ls.getService).toBeTruthy();
        });
    });
});