import { LocatorService, AppContextService, FormBuilderService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import 'rxjs/add/observable/of';
import { GetCurrentReport } from './get-current-report';
import { BaseModel } from 'providers/models/form/base-view-model';
import { GetCurrentSignature } from './get-current-signature';

class Action extends GetCurrentSignature {
  parentViewModel: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockLocatorService {
}

describe('GetCurrentSignature', () => {
  let action: Action;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      action.parentViewModel = new BaseModel();
      expect(action.execute());
    });
  });
});
