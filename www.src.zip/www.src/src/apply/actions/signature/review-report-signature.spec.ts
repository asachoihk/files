import { LocatorService, ActionService, DialogService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import 'rxjs/add/observable/of';
import { Observable } from 'rxjs';
import { ReviewReportSignature } from './review-report-signature';

class Action extends ReviewReportSignature {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockActionService {

  createActionParams() {
    return {};
  }
}

class MockDialogService {

  showFormBuilderDialog(component, dialogConfig, actionData, callback) {
    return callback({
      action: 'yes'
    });
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'actionService':
        return new MockActionService();
      case 'dialogService':
        return new MockDialogService();
      default:
        break;
    }
  }
}

describe('ReviewReportSignature', () => {
  let action: Action;
  const formFieldConfig = { id: 'proceedSignature', type: 'button', label: 'Proceed_Signature' };
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: ActionService, useClass: MockActionService },
        { provide: DialogService, useClass: MockDialogService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
    spyOn(action.ls, 'getService').and.callThrough();
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      action.execute();
      expect(action.ls.getService).toHaveBeenCalled();
    });
  });
});
