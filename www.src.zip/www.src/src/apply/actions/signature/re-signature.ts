import { LocatorService, FormBuilderService, BaseAction } from '@providers';
import { SignatureComponent } from '@apply/components';

export class ReSignature extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): void {
    const formFieldConfig = this.formFieldConfig;
    if (formFieldConfig.relationships && formFieldConfig.relationships.length) {
      const signComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(formFieldConfig.relationships[0]) as SignatureComponent;
      signComponent.clear();
    }
  }
}
