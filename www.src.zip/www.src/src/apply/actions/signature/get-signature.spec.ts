import { LocatorService, AppContextService, FormBuilderService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import 'rxjs/add/observable/of';
import { GetSignature } from './get-signature';
import { MatDialogRef } from '@angular/material';

class Action extends GetSignature {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockFormBuilderService {
  constructor() { }

  getComponentByFormFieldConfigId(configId: string) {
    return {
      hasChanges: true,
      getImageData() {
        return 'base64';
      }
    };
  }
}

class MockMatDialogRef {
  close() {
    return true;
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      default:
        break;
    }
  }
}

describe('GetSignature', () => {
  let action: Action;
  const formFieldConfig = { id: 'getSign', type: 'button', label: 'Ok', relationships: ['signaturePerson'] };
  let ls: LocatorService;
  let dialogRef: any;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: MatDialogRef, useClass: MockMatDialogRef },
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService }
      ],
    });
    ls = TestBed.get(LocatorService);
    dialogRef = TestBed.get(MatDialogRef);
  });

  beforeEach(() => {
    action = new Action(ls);
    action.dialogRef = dialogRef;
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run - image !== undefined', () => {
      action.formFieldConfig = formFieldConfig;
      spyOn(action.ls, 'getService').and.callThrough();
      action.execute();
      expect(action.ls.getService).toHaveBeenCalled();
    });

    it('should be run - image === undefined', () => {
      action.formFieldConfig = formFieldConfig;
      spyOn(action.ls, 'getService').and.returnValue({
        getComponentByFormFieldConfigId(configId: string) {
          return {
            hasChanges: true,
            getImageData() {
              return;
            }
          };
        }
      });
      action.execute();
      expect(action.ls.getService).toHaveBeenCalled();
    });
  });
});
