import { LocatorService, AppContextService, FormBuilderService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import 'rxjs/add/observable/of';
import { ReSignature } from './re-signature';

class Action extends ReSignature {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockFormBuilderService {
  constructor() { }

  getComponentByFormFieldConfigId(configId: string) {
    return {
      clear() {

      }
    };
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      default:
        break;
    }
  }
}

describe('ReSignature', () => {
  let action: Action;
  const formFieldConfig = { id: 'proceedSignature', type: 'button', label: 'Proceed_Signature', relationships: ['test'] };
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
    spyOn(action.ls, 'getService').and.callThrough();
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      action.formFieldConfig = formFieldConfig;
      const component = {
        clear() { }
      };
      action.execute();
      expect(action.ls.getService).toHaveBeenCalled();
    });
  });
});
