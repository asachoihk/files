import { LocatorService, BaseAction } from '@providers';

export class TransformApplications extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(_params: any): void {
    // const dataTable = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('applications') as DataSourceComponent;
    // const customerId = this.ls.get(ActivatedRoute).snapshot.queryParams.customerId || this.ls.getService<CustomerService>('customerService').getCurrent().customerId;
    // this.ls.get(ApplicationService).getApplicationsByCustomer(customerId, false, true).subscribe(apps => {
    //   dataTable.dataSource = apps;
    //   const btn = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(this.formFieldConfig.id) as BaseControlComponent;
    //   btn.setDisabledState(true);
    // });
  }
}
