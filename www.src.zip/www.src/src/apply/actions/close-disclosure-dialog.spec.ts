import { LocatorService, DialogService } from '@providers';
import { CloseDisclosureDialog } from './close-disclosure-dialog';
import { Observable } from 'rxjs';
import { TestBed } from '@angular/core/testing';
import { MatDialogRef } from '@angular/material';
import { TranslationService } from 'angular-l10n';
import { UnderwritingModel } from 'disclosure/models/underwriting-model';

class Action extends CloseDisclosureDialog {
    constructor(public ls: LocatorService, protected translationService: TranslationService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'dialogService') {
            return new MockDialogService();
        }

        if (serviceName === 'actionService') {
            return new MockActionService();
        }

    }

    get() {
        return new MockTranslationService();
    }
}

class MockTranslationService {
    translate() {
        return 'translate text';
    }
}

class MockDialogService {
    open() {
        return { afterClosed: () => Observable.of({}) };
    }

    close() {
        return true;
    }


    showCustomDialog(component, dialogConfig, callback) {
        return callback({
            action: 'yes'
        });
    }
}

class MockMatDialogRef {

    open() {
        return { afterClosed: () => Observable.of({}) };
    }

    close() {
        return true;
    }
}

class MockActionService {
    executeAction(actionName: string, context: any, params: any, callback) {
        return callback({
            action: 'yes'
        });
    }
}

describe('CloseDisclosureDialog', () => {
    let action: Action;
    let ls;
    let translationService;
    let dialog;

    beforeEach(() => {

        TestBed.configureTestingModule({

            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: TranslationService, useClass: MockTranslationService },
                { provide: DialogService, useClass: MockDialogService },
                { provide: MatDialogRef, useClass: MockMatDialogRef },
            ],

        });
        ls = TestBed.get(LocatorService);
        dialog = TestBed.get(MatDialogRef);
    });

    beforeEach(() => {
        action = new Action(ls, translationService);
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run - (params && params.ignoreTrackDataChanges) === true', () => {
            const params = {
                ignoreTrackDataChanges: true
            };
            const dialogRef = {
                close() {
                    return {};
                }
            };
            action.dialogRef = dialogRef as any;
            const viewModel = {} as any;
            action.viewModel = viewModel;
            spyOn(action.ls, 'getService').and.callThrough();
            expect(action.execute(params)).toBeUndefined();
        });

        it('should be run - (params && params.ignoreTrackDataChanges) === false', () => {
            const params = {
                ignoreTrackDataChanges: false
            };
            const dialogRef = {
                close() {
                    return {};
                }
            };
            const model = {
                hasChanges: false
            };
            action.dialogRef = dialogRef as any;
            action.viewModel = model as any;
            expect(action.execute(params)).toBeUndefined();
        });

        it('should be run - (params && params.ignoreTrackDataChanges) === false - result.action === CustomDialogActionType.no', () => {
            const params = {
                ignoreTrackDataChanges: false
            };
            const dialogRef = {
                close() {
                    return {};
                }
            };
            const model = {
                hasChanges: false
            };
            action.dialogRef = dialogRef as any;
            action.viewModel = model as any;
            spyOn(action.ls, 'getService').and.returnValue({
                showCustomDialog(component, dialogConfig, callback) {
                    return callback({
                        action: 'no'
                    });
                }
            });
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be run - (params && params.ignoreTrackDataChanges) === false - result.action === CustomDialogActionType.cancel', () => {
            const params = {
                ignoreTrackDataChanges: false
            };
            const dialogRef = {
                close() {
                    return {};
                }
            };
            const model = {
                hasChanges: false
            };
            action.dialogRef = dialogRef as any;
            action.viewModel = model as any;
            spyOn(action.ls, 'getService').and.returnValue({
                showCustomDialog(component, dialogConfig, callback) {
                    return callback({
                        action: 'cancel'
                    });
                }
            });
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });

    });

    describe('Function - detectChanges', () => {
        it('should be run', () => {
            const model = {
                hasChanges: false
            };
            action.viewModel = model as any;
            expect(action.detectChanges()).toEqual(false);
        });
    });

    describe('Function - getDefaultCloseParams', () => {
        it('should be run', () => {
            action.viewModel = {} as any;
            expect(action.getDefaultCloseParams()).toEqual(action.viewModel);
        });
    });
});