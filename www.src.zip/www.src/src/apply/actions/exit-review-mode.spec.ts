import { LocatorService, SystemEventService } from '@providers';
import { ExitReviewMode } from './exit-review-mode';
import { TestBed } from '@angular/core/testing';

class Action extends ExitReviewMode {
    constructor(public ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    getService(serviceName: string) {

        if (serviceName === 'systemEventService') {
            return new MockSystemEventService();
        }

    }

}

class MockSystemEventService {
    publish() {
        return {};
    }
}

describe('EditBeneficaryOwnerDialog', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: SystemEventService, useClass: MockSystemEventService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
        spyOn(action.ls, 'getService').and.callThrough();
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run - (viewModel && viewModel.selected) === true', () => {
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});