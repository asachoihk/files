import { BaseAction } from 'providers/actions/base-action';
import { LocatorService, JsonConfigService } from '@providers';
import { Observable } from 'rxjs';
import { JsonConfigItem } from 'providers/models/config/json-config-item';
import * as _ from 'lodash';

export class GetIdentitiesPH extends BaseAction {
    readonly currentCountry = 'PH';

    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(): Observable<JsonConfigItem[]> {
        return new Observable<JsonConfigItem[]>(subscriber => {
            const defaultValues = (this.parentFormFieldConfig || this.formFieldConfig).default as string;
            if (!defaultValues) {
                subscriber.next([]);
            } else {
                const identityTypes = this.ls.getService<JsonConfigService>('jsonConfigService').getIdentityTypes();

                subscriber.next(_.cloneDeepWith(identityTypes.filter(i => (!i.country || i.country.split(',').includes(this.currentCountry)) && defaultValues.includes(i.id)))

                );
            }
        });
    }
}
