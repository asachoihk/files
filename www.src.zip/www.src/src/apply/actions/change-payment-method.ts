import { LocatorService, BaseAction, SystemEventService, ToolbarActionsChanged } from '@providers';
import { ApplyModel } from '@apply/models';

export class ChangePaymentMethod extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params: any) {
        this.ls.getService<SystemEventService>('systemEventService').publish(new ToolbarActionsChanged());

        const docType = params ? params['documentType'] : '';
        if (docType) {
            const vm = this.viewModel as ApplyModel;
            if (vm.owner.id === vm.insured.id) {
                vm.insured.documents = (vm.insured.documents || []).filter(d => d.type !== docType);
            } else {
                vm.owner.documents = (vm.owner.documents || []).filter(d => d.type !== docType);
            }
        }
    }
}
