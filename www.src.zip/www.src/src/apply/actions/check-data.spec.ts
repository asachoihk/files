import { CheckData } from './check-data';
import { LocatorService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of, Observable } from 'rxjs';
import { ApplicationService } from '@apply/services/application/application.service';

class Action extends CheckData {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }

    get() {
        return new MockActivatedRoute();
    }

    getService(serviceName: string) {
        if (serviceName === 'applicationService') {
            return new MockApplicationService();
        }
        return new MockGlobalNavigationService();
    }
}

class MockApplicationService {
    getApplyData() {
        return {
            status: 'SUBMISSION_CONFIRMED',
            payment: {
                method: 'ONLINE'
            }
        };
    }
}

class MockGlobalNavigationService {
    navigateTo() {
        return '/apply/application-details/submission/agent-question';
    }
}

class MockActivatedRoute {
    snapshot = {
        queryParams: {
            applicationId: '18072433-c834-755a-9372-6826ef99f9fb',
            customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab'
        }
    };
}

describe('CheckData', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ActivatedRoute, useClass: MockActivatedRoute },
                { provide: ApplicationService, useClass: MockApplicationService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            expect(action.execute()).toBeFalsy();
        });

        it('should be return with status = PAYMENT_PENDING', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getApplyData() {
                    return {
                        status: 'PAYMENT_PENDING'
                    };
                },
                navigateTo() {
                    return '/apply/application-details/submission/agent-question';
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be return with status = PAYMENT_PENDING', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getApplyData() {
                    return {
                        status: 'PAYMENT_PENDING'
                    };
                },
                navigateTo() {
                    return '/apply/application-details/submission/payment-online';
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be return with status = SUBMISSION_AGENT_QUESTION && payment method = ONLINE', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getApplyData() {
                    return {
                        status: 'SUBMISSION_AGENT_QUESTION',
                        payment: {
                            method: 'ONLINE'
                        }
                    };
                },
                navigateTo() {
                    return '/apply/application-details/submission/payment-online';
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be return with status = SUBMISSION_AGENT_QUESTION && payment method = ATM', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getApplyData() {
                    return {
                        status: 'SUBMISSION_AGENT_QUESTION',
                        payment: {
                            method: 'ATM'
                        }
                    };
                },
                navigateTo() {
                    return '/apply/application-details/submission/application-result';
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be return with status = PAID', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getApplyData() {
                    return {
                        status: 'PAID'
                    };
                },
                navigateTo() {
                    return '/apply/application-details/submission/application-result';
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be return with status = SUBMITTED', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getApplyData() {
                    return {
                        status: 'SUBMITTED'
                    };
                },
                navigateTo() {
                    return '/apply/application-details/submission/application-result';
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be return with status = EXPIRED', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getApplyData() {
                    return {
                        status: 'EXPIRED'
                    };
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});
