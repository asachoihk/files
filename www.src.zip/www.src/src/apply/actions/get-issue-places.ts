import { LocatorService, JsonConfigService, FormBuilderService, JsonConfigItem, FormField } from '@providers';
import { GetCountries } from './get-countries';
import { Observable } from 'rxjs';
import * as _ from 'lodash';

export class GetIssuePlaces extends GetCountries {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(_params?: any): Observable<JsonConfigItem[]> {
        if (_params.type === 'province') {
            return new Observable<JsonConfigItem[]>(subscriber => {
                const parentFFC = this.parentFormFieldConfig as FormField;
                const childFFC = (_params.formFieldConfig || this.formFieldConfig) as FormField;
                const ffc = parentFFC.type === 'dependency' ? childFFC : (parentFFC || childFFC);
                let defaultValues =  ffc.default as string;
                if (!defaultValues) {
                    subscriber.next([]);
                } else {
                    let provinces = [];
                    provinces = this.ls.getService<JsonConfigService>('jsonConfigService').getProvinces('');
                    const dataBinding = ffc.dataBinding;
                    if (dataBinding) {
                        const selected = this.ls.getService<FormBuilderService>('formBuilderService').getBindingData(this.viewModel, dataBinding.path);
                        if (selected) {
                            defaultValues = defaultValues + ',' + selected.toString();
                        }
                      }
                    subscriber.next(_.cloneDeepWith(provinces.filter(c => defaultValues.includes(c.value))));
                }
            });
        } else {
            return super.execute();
        }

    }
}
