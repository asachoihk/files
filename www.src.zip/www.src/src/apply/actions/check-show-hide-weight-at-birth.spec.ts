import { LocatorService, FormBuilderService } from '@providers';
import { CheckShowHideWeightAtBirth } from './check-show-hide-weight-at-birth';
import { TestBed } from '@angular/core/testing';
import { InsuredModel, UnderwritingModel } from '@apply/models';

class Action extends CheckShowHideWeightAtBirth {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {

        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

    }
}

class MockFormBuilderService {
    constructor() { }

    getComponentByFormFieldConfigId() {

        return {
            visibility: 'disabled'
        };
    }
}

describe('CheckShowHideWeightAtBirth', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run - (answers && formComponent) === true', () => {
            const model = {
                person: {
                    basicInfo: {
                        age: 1
                    }
                },
                type: 'i',
                uwDetails: {
                    answers: [
                        {
                            answer: 'abc'
                        }
                    ]
                }
            };
            const formFieldConfig = {
                id: 'abc',
                type: 'abc'
            };
            action.viewModel = model as InsuredModel;
            action.formFieldConfig = formFieldConfig;
            expect(action.execute()).toBeUndefined();
        });

        it('should be run - (answers && formComponent) === false', () => {
            const model = {
                person: {
                    basicInfo: {
                        age: 1
                    }
                },
                type: 'i',
                uwDetails: {
                    answers: undefined
                }
            };
            const formFieldConfig = {
                id: 'abc',
                type: 'abc'
            };
            action.viewModel = model as InsuredModel;
            action.formFieldConfig = formFieldConfig;
            expect(action.execute()).toEqual('disabled');
        });
    });

    it('should be run - (viewMode.person.basicInfo.age < 2 && viewMode.type === InsuredType.i) === false', () => {
        const model = {
            person: {
                basicInfo: {
                    age: 3
                }
            },
            type: 'j',
            uwDetails: {
                answers: [
                    {
                        answer: 'abc'
                    }
                ]
            }
        };
        const formFieldConfig = {
            id: 'abc',
            type: 'abc'
        };
        action.viewModel = model as InsuredModel;
        action.formFieldConfig = formFieldConfig;
        expect(action.execute()).toEqual('hidden');
    });
});