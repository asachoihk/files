import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { CheckApplicationStatus } from './check-application-status';


class Action extends CheckApplicationStatus {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() {}

    getService() {
        return new MockApplicationService();
    }
}

class MockApplicationService {
    isApplicationReadOnlyMode() {
        return true;
    }
}

describe('CheckApplicationStatus', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be created', () => {
            expect(action.execute()).toBeDefined();
        });
    });
});
