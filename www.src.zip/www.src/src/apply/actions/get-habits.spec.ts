
import { TestBed } from '@angular/core/testing';

import { GetHabits } from './get-habits';
import { LocatorService, JsonConfigService } from '@providers';

class Action extends GetHabits {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}


class MockJsonConfigService {
  constructor() { }

  getDrinking() {
    return [{
      label: 'Never drink',
      value: 'NEVER_DRINK'
    }];
  }

  getSmoking() {
    return [{
      label: 'Never smoke',
      value: 'NEVER_SMOKE'
    }];
  }
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'jsonConfigService':
        return new MockJsonConfigService();
      default:
        break;
    }
  }
}

describe('GetHabits', () => {
  let action: Action;
  let ls: LocatorService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: JsonConfigService, useClass: MockJsonConfigService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run smokingStatus', () => {
      action.formFieldConfig = {
        id: 'smokingStatus'
      };
      expect(JSON.stringify(action.execute())).toEqual(JSON.stringify([{
        label: 'Never smoke',
        value: 'NEVER_SMOKE'
      }]));
    });
    it('should be run with drinkStatus', () => {
      action.formFieldConfig = {
        id: 'drinkStatus'
      };
      expect(JSON.stringify(action.execute())).toEqual(JSON.stringify([{
        label: 'Never drink',
        value: 'NEVER_DRINK'
      }]));
    });
    it('should be run with empty id', () => {
      action.formFieldConfig = {
        id: ''
      };
      expect(action.execute()).toBeNull();
    });
  });
});
