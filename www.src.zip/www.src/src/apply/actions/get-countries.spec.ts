import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { GetCountries } from './get-countries';


class Action extends GetCountries {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }

    getService() {
    }
}

describe('GetCountries', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be return when type = dropdown || list', () => {
            action.formFieldConfig = {
                id: 'id',
                type: 'dropdown'
            };
            spyOn(action.ls, 'getService').and.returnValue({
                getCountries() {
                    return [
                        {
                            id: 'AF',
                            value: 'countryAF'
                        }
                    ];
                }
            });
            action.execute().subscribe(data =>
                expect(data).toBeTruthy()
            );
        });

        it('should be return when type !== dropdown || list', () => {
            action.formFieldConfig = {
                id: 'id',
                type: 'test',
                default: ''
            };
            action.parentFormFieldConfig = {
                id: 'id',
                type: 'dependency'
            };
            action.execute().subscribe(data =>
                expect(data).toBeTruthy()
            );
        });

        it('should be return when type !== dropdown || list && with default value', () => {
            action.formFieldConfig = {
                id: 'id',
                type: 'test',
                default: 'default',
                dataBinding: {
                    path: 'dataBinding'
                }
            };
            action.parentFormFieldConfig = {
                id: 'id',
                type: 'dependency'
            };
            spyOn(action.ls, 'getService').and.returnValue({
                getCountries() {
                    return [
                        {
                            id: 'AF',
                            value: 'countryAF'
                        }
                    ];
                },
                getBindingData() {
                    return null;
                }
            });
            action.execute().subscribe(data =>
                expect(data).toBeTruthy()
            );
        });
    });
});
