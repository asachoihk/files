import { GetIssuePlaces } from './get-issue-places';
import { LocatorService, JsonConfigService, FormBuilderService } from '@providers';
import { async, TestBed } from '@angular/core/testing';

class Action extends GetIssuePlaces {
  formFieldConfig: any;
  parentFormFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockJsonConfigService {
  getProvinces() {
    return [{
      value: '13',
      display: 'Thành phố Cần Thơ'
    }];
  }
}

class MockFormBuilderService {
  getBindingData() {
    return null;
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'jsonConfigService':
        return new MockJsonConfigService();
      case 'formBuilderService':
        return new MockFormBuilderService();
      default:
        break;
    }
  }
}

describe('Get Insurance Provider', () => {
  let action: Action;
  let ls: LocatorService;
  const parentFormFieldConfig = {id: 'dependency', type: 'dependency', group: 'identity'};
  const formFieldConfig = {id: 'id_issuePlace', type: 'chipList'};

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: JsonConfigService, useClass: MockJsonConfigService },
        { provide: FormBuilderService, useClass: MockFormBuilderService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run', async(() => {
      const params = {
        type: 'province'
      };
      action.parentFormFieldConfig = parentFormFieldConfig;
      action.formFieldConfig = formFieldConfig;
      expect(action.execute(params).subscribe());
    }));

    it('should be run', async(() => {
      const params = {
        type: 'province'
      };
      action.parentFormFieldConfig = parentFormFieldConfig;
      action.formFieldConfig = formFieldConfig;
      action.formFieldConfig.default = '0,15,24,29';
      expect(action.execute(params).subscribe());
    }));

    it('should be run', async(() => {
      const params = {
        type: 'province'
      };
      action.parentFormFieldConfig = parentFormFieldConfig;
      action.formFieldConfig = formFieldConfig;
      action.formFieldConfig.default = null;
      expect(action.execute(params).subscribe());
    }));

    it('should be run', async(() => {
      const params = {
        type: 'province'
      };
      action.parentFormFieldConfig = parentFormFieldConfig;
      action.formFieldConfig = formFieldConfig;
      action.formFieldConfig.default = '0,15,24,29';
      action.formFieldConfig.dataBinding = {
        path: 'person.registration.issuePlace'
      };
      expect(action.execute(params).subscribe());
    }));

    it('should be run', async(() => {
      const params = {
        type: 'province'
      };
      action.parentFormFieldConfig = parentFormFieldConfig;
      action.formFieldConfig = formFieldConfig;
      action.formFieldConfig.default = '0,15,24,29';
      action.formFieldConfig.dataBinding = {
        path: 'person.registration.issuePlace'
      };
      spyOn( action.ls, 'getService').and.returnValue({
        getProvinces() {
          return [];
        },
        getBindingData() {
          return 'Abc';
        }
      });
      expect(action.execute(params).subscribe());
    }));

    it('should be run', async(() => {
      const params = {
        type: 'city'
      };
      action.parentFormFieldConfig = parentFormFieldConfig;
      action.formFieldConfig = formFieldConfig;
      action.formFieldConfig.default = null;
      expect(action.execute(params).subscribe());
    }));
  });
});
