import { LocatorService, CustomerService, DialogService, FormBuilderService } from '@providers';
import { DeleteApplication } from './delete-application';
import { TestBed } from '@angular/core/testing';
import { ApplicationService } from '@apply/services';
import { TranslationService } from 'angular-l10n';
import { Observable, defer } from 'rxjs';

class Action extends DeleteApplication {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

        if (serviceName === 'applicationService') {
            return new MockApplicationService();
        }

        if (serviceName === 'customerService') {
            return new MockCustomerService();
        }

        if (serviceName === 'dialogService') {
            return new MockDialogService();
        }

    }

    get() {
        return new MockTranslationService();
    }
}

class MockTranslationService {
    translate() {
        return 'translate text';
    }
}

class MockFormBuilderService {
    constructor() { }
    get() {
        return null;
    }

    getComponentByFormFieldConfigId(configId: string) {
        if (configId === 'searchBar') {
            return {

            };
        }
        return {
            loadDataSource() {
                return null;
            }
        };
    }
    setBindingData() {
        return null;
    }

    getComponentByFormFieldConfig() {
        return {
            loadDataSource() {
                return {};
            }
        };
    }
}

class MockApplicationService {
    deleteApplication() {
        return defer(() => Promise.resolve());
    }
}

class MockCustomerService {
    getCurrent() {
        return {
            customerId: 'abc'
        };
    }
}

class MockDialogService {
    open() {
        return { afterClosed: () => Observable.of({}) };
    }

    close() {
        return true;
    }


    showCustomDialog(component, dialogConfig, callback) {
        return callback({
            action: 'yes'
        });
    }
}

describe('DeleteApplication', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ApplicationService, useClass: MockApplicationService },
                { provide: CustomerService, useClass: MockCustomerService },
                { provide: DialogService, useClass: MockDialogService },
                { provide: FormBuilderService, useClass: MockFormBuilderService },
                { provide: TranslationService, useClass: MockTranslationService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
        spyOn(action.ls, 'getService').and.callThrough();
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            const params = {
                selectedId: 'abc'
            };
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});