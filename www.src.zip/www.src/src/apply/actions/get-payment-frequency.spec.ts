import { GetPaymentFrequency } from './get-payment-frequency';
import { LocatorService } from '@providers';
import { ApplyModel, PaymentModel } from '@apply/models';
import { PaymentMethod } from '@apply/enums';
import { PremiumModel } from 'providers/models/premium.model';

class Action extends GetPaymentFrequency {
  viewModel: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

describe('Get Payment Frequency', () => {
  let ls: LocatorService;
  let action: Action;

  beforeEach(() => {
    action = new Action(ls);
  });

  describe('Excute Get Payment Frequency', () => {
    it('should be run', () => {
      action.viewModel = new ApplyModel();
      action.viewModel.payment = new PaymentModel();
      action.viewModel.payment.method = PaymentMethod.CASH;
      action.viewModel.totalPayment = new PremiumModel();
      const params = {
        excludeMonthlyIf: ''
      };
      expect(action.execute(params));
    });

    it('should be run', () => {
      const params = {
        excludeMonthlyIf: 'UI299'
      };
      action.viewModel = new ApplyModel();
      action.viewModel.payment = new PaymentModel();
      action.viewModel.payment.method = PaymentMethod.CASH;
      action.viewModel.totalPayment = new PremiumModel();
      action.viewModel.basicPlan.code = params.excludeMonthlyIf;
      expect(action.execute(params)).toBeDefined();
    });

    it('should be run', () => {
      action.viewModel = new ApplyModel();
      action.viewModel.payment = null;
      action.viewModel.totalPayment = {
        CASH: 10000
      };
      const params = {
        excludeMonthlyIf: ''
      };
      expect(action.execute(params));
    });
  });
});
