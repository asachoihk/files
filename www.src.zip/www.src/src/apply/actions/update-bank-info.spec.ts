
import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { FormBuilderService } from 'providers/services/form-builder/form-builder.service';
import { UpdateBankInfo } from './update-bank-info';
import { InsuredModel, BankInfoModel } from '@apply/models';


class Action extends UpdateBankInfo {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

}
class MockLocatorService {
  get(): MockFormBuilderService {
    return new MockFormBuilderService();
  }

  getService(serviceName: string): any {
    return new MockFormBuilderService();
  }
}

class MockFormBuilderService {
  constructor() { }
  get() {
    return null;
  }
  setBindingData() {

  }
}

describe('Update bank info', () => {
  let action: Action;
  let ls;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    const params = {

    };
    it('should be run', () => {
      const event = {
        source: {
          triggerValue: '123'
        }
      };
      const viewModel = new InsuredModel();
      viewModel.person.bankInfo = new BankInfoModel();

      action.$event = event;
      action.viewModel = viewModel;
      expect(action.execute(params)).toBeFalsy();
    });
  });
});
