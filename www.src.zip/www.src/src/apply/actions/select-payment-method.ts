import { BaseAction, LocatorService } from '@providers';
import { ApplyModel } from '@apply/models';
import { SubmissionService } from '@apply/services';
export class SelectPaymentMethod extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params?: any) {
    const value = params && params.value ? params.value : null;
    const viewModel = this.viewModel as ApplyModel;
    this.ls.getService<SubmissionService>('submissionService').choosePaymentmethod(viewModel, value);
  }
}
