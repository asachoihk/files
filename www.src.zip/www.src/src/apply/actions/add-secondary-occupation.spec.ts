import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { FormBuilderService } from 'providers/services/form-builder/form-builder.service';
import { AddSecondaryOccupation } from './add-secondary-occupation';

class Action extends AddSecondaryOccupation {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    get(): MockFormBuilderService {
        return new MockFormBuilderService();
    }

    getService(serviceName: string): any {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }
    }
}

class MockFormBuilderService {
    constructor() { }
    get() {
        return null;
    }

    getComponentByFormFieldConfigId() {
        return {
            visibility: 'hidden'
        };
    }

    setBindingData() {
        return null;
    }


    getComponentByFormFieldConfig() {
        return {
            visibility: 'hidden',
        };
    }
}

describe('AddSecondaryOccupation', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            expect(action.execute()).toBeFalsy();
        });
    });
});
