import { BaseAction, LocatorService } from '@providers';

export class GetAddNewBeneficiaryDataSource extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
      return {
        title: 'Add beneficiary',
        type: 'beneficiary'
      };
  }
}
