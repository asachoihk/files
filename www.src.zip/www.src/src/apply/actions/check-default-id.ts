import { BaseAction, LocatorService, FormBuilderService } from '@providers';

export class CheckDefaultId extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    const identityTypeField = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(params.identityTypeField);
    const formFieldConfigOfIdentity = identityTypeField.formFieldConfig;
    if (formFieldConfigOfIdentity && formFieldConfigOfIdentity.dataBinding) {
      const data = this.ls.getService<FormBuilderService>('formBuilderService').getBindingData(this.viewModel, formFieldConfigOfIdentity.dataBinding.path);
      if (!data) {
        const defaultParam = params.default;
        this.ls.getService<FormBuilderService>('formBuilderService').setBindingData(this.viewModel, formFieldConfigOfIdentity.dataBinding.path, defaultParam);
        this.ls.getService<FormBuilderService>('formBuilderService').notifyDependentFieldChanged(formFieldConfigOfIdentity, defaultParam);
      }
    }
  }
}
