import { BaseAction, LocatorService, FormBuilderService, Visibility } from '@providers';
import { DataSourceComponent } from '@shared/ui-elements';

export class CheckRemoveAgreementInsuraceVisibility extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Visibility {
    if (this.parentFormFieldConfig) {
      const agreementInsurances = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.parentFormFieldConfig) as DataSourceComponent;
      if (agreementInsurances && agreementInsurances.dataSource && agreementInsurances.dataSource.length === 1) {
        return Visibility.hidden;
      }
    }
    return Visibility.visible;
  }
}
