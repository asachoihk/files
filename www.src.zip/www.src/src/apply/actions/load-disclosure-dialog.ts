import { BaseAction, LocatorService, DialogService, FormBuilderService, AppContextService } from '@providers';
import { DisclosureDialogComponent } from 'disclosure/ui';
import { DialogShellComponent } from '@shared/shells';
import { TaskCardListComponent } from '@shared/components';
import { InsuredModel, ApplyModel } from '@apply/models';
import { FormBuilderPage } from '@shared/ui-elements';
import { DisclosureParams } from 'disclosure/models/disclosure-params';

export class LoadDisclosureDialog extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute() {
        const insuredModel = this.viewModel as InsuredModel;
        this.normalizeUwDetails(insuredModel);
        const dialogData = { viewModel: insuredModel.uwDetails, params: this.createDisclosureParams(this.parentViewModel as ApplyModel, insuredModel) };

        this.ls.getService<DialogService>('dialogService').showFormBuilderDialog(DisclosureDialogComponent, DialogShellComponent, dialogData, result => {
            if (result) {
                const currentFormBuilder = this.ls.getService<AppContextService>('appContextService').appContext.currentPage as FormBuilderPage;
                currentFormBuilder.refreshData(() => {
                    const taskCardList = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as TaskCardListComponent;
                    taskCardList.loadDataSource();
                    this.ls.getService<DialogService>('dialogService').closeSpinnerDialog();
                });
            }
        });
    }

    createDisclosureParams(applyModel: ApplyModel, insuredModel: InsuredModel): DisclosureParams {
        return {
            insuredPerson: insuredModel,
            applyData: applyModel,
            rulebookId: applyModel.rulebookId,
            rulebookLocale: applyModel.rulebookLang
        };
    }

    normalizeUwDetails(insuredModel: InsuredModel) {
        if (!insuredModel.uwDetails.answers) {
            insuredModel.uwDetails.answers = [];
        }

        if (!insuredModel.uwDetails.reflexiveAnswers) {
            insuredModel.uwDetails.reflexiveAnswers = [];
        }
    }
}
