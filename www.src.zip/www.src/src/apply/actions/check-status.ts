import { LocatorService, BaseAction } from '@providers';

export class CheckStatus extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    // const questionModel = this.viewModel as DeclarationAnswerModel;
    // const btnSubmit = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as ButtonComponent;
    // const question = questionModel.agent_question || '';
    // if (question !== '') {
    //   if ((question === 'Y' && questionModel.agent_answer.trim() !== '') || question === 'N') {
    //     btnSubmit.visibility = Visibility.visible;
    //   }
    // } else {
    //   btnSubmit.visibility = Visibility.disabled;
    // }
  }
}
