import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { ApplyModel } from '@apply/models';
import { CheckPaymentOnlineVisibility } from './check-payment-online-visibility';

class Action extends CheckPaymentOnlineVisibility {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }
}

describe('CheckPaymentOnlineVisibility', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run with paymentMethod = ONLINE', () => {
            action.viewModel = new ApplyModel();
            (action.viewModel as any) = {
                payment: {
                    method: 'ONLINE'
                }
            };
            expect(action.execute()).toBeDefined();
        });

        it('hould be run with paymentMethod != ONLINE', () => {
            action.viewModel = new ApplyModel();
            (action.viewModel as any) = {
                payment: {
                    method: 'POS'
                }
            };
            expect(action.execute()).toBeDefined();
        });
    });
});
