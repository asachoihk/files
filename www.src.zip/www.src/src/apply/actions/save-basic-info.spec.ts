
import { TestBed, async } from '@angular/core/testing';
import { LocatorService, AppContextService, SystemEventService, CustomerService, GlobalNavigationService, FormBuilderService } from '@providers';
import { SaveBasicInfo } from './save-basic-info';
import { InsuredPersonService, ApplicationService, ProgressService } from '@apply/services';
import { ApplyModel, PaymentModel } from '@apply/models';
import { ActivatedRoute } from '@angular/router';
import { Observable, of } from 'rxjs';
import { PaymentMethod } from '@apply/enums';

class Action extends SaveBasicInfo {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}


class MockInsuredPersonService {
  constructor() { }

  filterBeneficiaries(viewModel) {
    return;
  }
}

class MockActivatedRoute {
  constructor() { }

  snapshot = {
    queryParams: {
      applicationId: '18072433-c834-755a-9372-6826ef99f9fb',
      customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab'
    }
  };
}

class MockFormBuilderService {
  constructor() { }

  markFormTouched(formId) {

  }
}

class MockGlobalNavigationService {
  constructor() { }

  getCurrentNavigationPage() {
    return {
      checkChanges: 'checkApplicationChanges',
      id: 'payment',
      isBreadscrumbItem: true,
      isLeftNavigationItem: true,
      label: 'basicInformation',
      labelAction: 'getCurrentApplicationName'
    };
  }

  getLeftNavigationItems() {
    return [
      { id: 'payment' },
      { id: 'disclosure' }
    ];
  }

  navigateTo() {

  }
}

class MockCustomerService {
  constructor() { }

  getCurrent() {
    return {
      customerId: ''
    };
  }
}

class MockSystemEventService {
  constructor() { }

  publish() {
  }
}

class MockProgressService {
  constructor() { }

  publish() {
    return of({});
  }

  updateSectionProgress() {

  }
}

class MockApplicationService {
  constructor() { }

  saveApplyData(customerId: string, applyModels: ApplyModel[], isAddNew?: boolean): Observable<any[]> {
    return new Observable(subscriber => {
      return subscriber.next([{}]);
    });
  }
}

class MockAppContextService {
  constructor() { }

  currentFormBuilder = { id: '' };
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'insuredPersonService':
        return new MockInsuredPersonService();
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'globalNavigationService':
        return new MockGlobalNavigationService();
      case 'customerService':
        return new MockCustomerService();
      case 'systemEventService':
        return new MockSystemEventService();
      case 'progressService':
        return new MockProgressService();
      case 'applicationService':
        return new MockApplicationService();
      case 'appContextService':
        return new MockAppContextService();
      default:
        break;
    }
  }

  get() {
    return new MockActivatedRoute();
  }
}

describe('SaveBasicInfo', () => {
  let action: Action;
  let ls: LocatorService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: InsuredPersonService, useClass: MockInsuredPersonService },
        { provide: ActivatedRoute, useClass: MockActivatedRoute },
        { provide: FormBuilderService, useClass: MockFormBuilderService },
        { provide: GlobalNavigationService, useClass: MockGlobalNavigationService },
        { provide: CustomerService, useClass: MockCustomerService },
        { provide: SystemEventService, useClass: MockSystemEventService },
        { provide: ProgressService, useClass: MockProgressService },
        { provide: ApplicationService, useClass: MockApplicationService },
        { provide: AppContextService, useClass: MockAppContextService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run', async(
      () => {
        const params = { IgnoreGoToNextPage: true };
        // action.viewModel = new ApplyModel();
        const applyModel = new ApplyModel();
        applyModel.payment = new PaymentModel();
        applyModel.payment.method = PaymentMethod.ONLINE;
        applyModel.payment.documents = [];
        action.viewModel = applyModel;
        expect(action.execute(params).subscribe()).toBeTruthy();
      }
    ));
  });
});
