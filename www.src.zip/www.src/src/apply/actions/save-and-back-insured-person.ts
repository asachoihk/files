import { LocatorService, FormBuilderService, CustomerService, GlobalNavigationService, SaveAction, ActionParams, AppContextService, Visibility } from '@providers';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import { InsuredModel, ApplyModel } from '@apply/models';
import { InsuredPersonService, SaveDocumentsService, ApplicationService, ProgressService, AddressService } from '@apply/services';
import { BaseControlComponent } from '@shared/ui-elements';
import { ActivatedRoute } from '@angular/router';
import { ApplySection } from '@apply/const';

export class SaveAndBackInsuredPerson extends SaveAction {
  actionParams: ActionParams;
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Observable<any> {
    return new Observable<any>(subscriber => {
      const insuredPerson = this.viewModel as InsuredModel;
      let clonedInsuredPerson = _.cloneDeep<InsuredModel>(insuredPerson);
      const currentFormBuilder = this.ls.getService<AppContextService>('appContextService').currentFormBuilder;
      const currentSectionName = this.ls.getService<GlobalNavigationService>('globalNavigationService').getCurrentNavigationPage().id;
      const onlySave = this.actionParams.params ? this.actionParams.params.onlySave : false;
      
      this.ls.getService<SaveDocumentsService>('saveDocumentsService').saveDocumentInsured(insuredPerson, currentSectionName).subscribe(response => {
        if (response && response.uploadFileSuccess) {
          // ensure progress recaculated
          this.validateForm(currentFormBuilder.id, this.actionParams);

          if (response.insuredPerson) {
            clonedInsuredPerson = response.insuredPerson;
          }
        } else {
          const validDocs = clonedInsuredPerson.documents.filter(d => d.applicationAttachmentId && d.doc);
          clonedInsuredPerson.documents = validDocs;

          if (currentSectionName === ApplySection.SUPPORTING_DOCS.toString()) {
            subscriber.next(null);
            return;
          }
        }

        const customerId = this.ls.get(ActivatedRoute).snapshot.queryParams.customerId || this.ls.getService<CustomerService>('customerService').getCurrent().customerId;
        const applyData = this.ls.getService<AppContextService>('appContextService').appContext.currentPage.viewModel as ApplyModel; //this.ls.get(ApplicationService).getCurrentApplyData();
        const insuredPersonProgress = this.ls.getService<ProgressService>('progressService').calculateCurrentInsuredPersonProgress();
        this.ls.getService<ProgressService>('progressService').updateInsuredPersonProgress(clonedInsuredPerson, insuredPersonProgress, applyData);

        this.ls.getService<InsuredPersonService>('insuredPersonService').updateInsuredPersonToApplication(clonedInsuredPerson, applyData);
        this.ls.getService<InsuredPersonService>('insuredPersonService').updateBeneficiaryOwner(applyData);
        this.ls.getService<AddressService>('addressService').checkAndCascadeInsuredAddress(clonedInsuredPerson, applyData);
        this.ls.getService<ApplicationService>('applicationService').saveApplyData(customerId, [applyData]).subscribe(result => {
          if (!onlySave) {
            this.dialogRef.close(result);
          }
          subscriber.next(result);
        });
      });
    });
  }

  ignoreValidationResult() {
    return true;
  }

  shouldValidate(control: BaseControlComponent) {
    return control.formControl && control.formControl.status !== 'DISABLED' && (control.visibility !== Visibility.hidden && control.visibility !== Visibility.collapsed);
  }

  validateForm(formId, actionParams: ActionParams) {
    if (!this.actionParams) {
      this.actionParams = actionParams;
    }
    const valid = super.validateForm(formId, this.actionParams);
    const closePopup = !this.actionParams.params.onlySave;

    if (!closePopup) {
      this.ls.getService<FormBuilderService>('formBuilderService').markFormTouched(formId);
    }

    return valid;
  }
}
