import { LocatorService, FormBuilderService, ActionService, AppContextService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { TranslationService } from 'angular-l10n';
import { Observable } from 'rxjs';
import { DeleteBeneficiary } from './delete-beneficiary';
import { SaveBeneficiaryPerson } from './save-beneficiary-person';
import { TaskCardListComponent, ProportionListComponent } from '@shared/components';

class Action extends DeleteBeneficiary {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

        if (serviceName === 'appContextService') {
            return new MockAppContextService();
        }

        if (serviceName === 'actionService') {
            return new MockActionService();
        }

        if (serviceName === 'dialogService') {
            return new MockDialogService();
        }

    }

    get() {
        return new MockTranslationService();
    }

    getAction(actionName: string) {
        if (actionName === 'saveBeneficiaryPerson') {
            return new MockSaveBeneficiaryPerson();
        }
        if (actionName === 'checkAvailable') {
            return new MockCheckAvailable();
        }
    }
}

class MockTranslationService {
    translate() {
        return 'translate text';
    }
}

class MockFormBuilderService {
    constructor() { }
    get() {
        return null;
    }

    getComponentByFormFieldConfigId(configId: string) {
        if (configId === 'searchBar') {
            return {

            };
        }
        return {
            loadDataSource() {
                return {};
            }
        };
    }
    setBindingData() {
        return null;
    }

    getComponentByFormFieldConfig() {
        let ls: LocatorService;
        return new TaskCardListComponent(ls);
    }
}

class MockAppContextService {
    currentFormBuilder = {
        refreshData(callback) {
            return callback({});
        }
    };
}

class MockActionService {
    createActionParams() {
        return {
        };
    }
    retreiveActionResult(resultSave, callback) {
        return callback({
        });
    }
}

class MockDialogService {
    open() {
        return { afterClosed: () => Observable.of({}) };
    }

    close() {
        return true;
    }


    showCustomDialog(component, dialogConfig, callback) {
        return callback({
            action: 'yes'
        });
    }
}

class MockSaveBeneficiaryPerson {
    invoke() {
        return {};
    }
}

class MockCheckAvailable {
    invoke() {
        return {};
    }
}

describe('DeleteApplicationMultiple', () => {
    let action: Action;
    let ls;
    let translationService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ActionService, useClass: MockActionService },
                { provide: AppContextService, useClass: MockAppContextService },
                { provide: SaveBeneficiaryPerson, useClass: MockSaveBeneficiaryPerson },
                { provide: FormBuilderService, useClass: MockFormBuilderService },
                { provide: TranslationService, useClass: MockTranslationService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
        spyOn(action.ls, 'getService').and.callThrough();
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            const $event = {
                preventDefault() {
                    return;
                },
                stopPropagation() {
                    return;
                }
            };
            const params = {
            };
            const parentFormFieldConfig = {
                relationships: ['abc', 'xyz']
            };
            action.$event = $event as any;
            action.parentFormFieldConfig = parentFormFieldConfig as any;
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});
