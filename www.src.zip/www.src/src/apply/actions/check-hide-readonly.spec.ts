import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { CheckHideReadonly } from './check-hide-readonly';


class Action extends CheckHideReadonly {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }

    getService() {
        return new MockApplicationService();
    }
}

class MockApplicationService {
    isApplicationReadOnlyMode() {
        return true;
    }
}

describe('CheckHideReadonly', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {

        it('should be run', () => {
            expect(action.execute()).toBeTruthy();
        });
    });
});
