import { LocatorService, AppContextService } from '@providers';
import { Observable } from 'rxjs';
import { UnderwritingModel } from 'disclosure/models/underwriting-model';
import { DisclosureParams } from 'disclosure/models/disclosure-params';
import { DisclosureValidationService } from 'disclosure/services/disclosure-validation/disclosure-validation.service';
import { SaveApplicationAndContinue } from './save-application-and-continue';
import { InsuredPersonService, ProgressService } from '@apply/services';
import { ApplyModel, InsuredModel } from '@apply/models';
import { FormBuilderDialog } from '@shared/ui-elements';

export class SaveDisclosureDataAndContinue extends SaveApplicationAndContinue {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params: any): Observable<any> {
        return new Observable(subscriber => {
            setTimeout(() => {
                const underwritingModel = this.viewModel as UnderwritingModel;
                delete underwritingModel.hasChanges;

                const disclosureDialog = this.ls.getService<AppContextService>('appContextService').currentFormBuilder as FormBuilderDialog;
                const disclosureParams = disclosureDialog.data.params as DisclosureParams;

                const applyData = disclosureParams.applyData as ApplyModel;
                const insuredModel = disclosureParams.insuredPerson as InsuredModel;
                insuredModel.uwDetails.answers = underwritingModel.answers;
                insuredModel.uwDetails.reflexiveAnswers = underwritingModel.reflexiveAnswers;
                const disclosureProgress = this.ls.getService<ProgressService>('progressService').calculateCurrentInsuredPersonProgress();
                this.ls.getService<ProgressService>('progressService').updateInsuredPersonProgress(insuredModel, disclosureProgress, applyData)

                applyData.rulebookId = underwritingModel.rulebookId;
                applyData.rulebookLang = underwritingModel.rulebookLocale;

                this.ls.getService<InsuredPersonService>('insuredPersonService').updateInsuredPersonToApplication(insuredModel, applyData);

                this.viewModel = applyData;
                super.execute(params).subscribe(result => {
                    if (params.saveAndClose) {
                        this.dialogRef.close(result);
                    }

                    subscriber.next(result);
                });
            }, 700);
        });
    }

    ignoreValidationResult() {
        return true;
    }

    validateForm(_formId, _actionParams) {
        return this.ls.getService<DisclosureValidationService>('disclosureValidationService').validateDisclosureData();
    }
}
