import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { FormBuilderService } from 'providers/services/form-builder/form-builder.service';
import { AnswerAgreementQuestion } from './answer-agreement-question';
import { InsuredModel } from '@apply/models';

class Action extends AnswerAgreementQuestion {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    get(): MockFormBuilderService {
        return new MockFormBuilderService();
    }

    getService(serviceName: string): any {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }
        return new MockActionService();
    }
}

class MockActionService {
    createActionParams() {
        return {};
    }
}

class MockFormBuilderService {
    constructor() { }
    get() {
        return null;
    }

    getComponentByFormFieldConfigId() {
        return {
            formFieldConfig: {
                metadata: {
                    max: 3
                },
                dataBinding: {
                    path: 'agreement.insurance'
                }
            },
            dataSource: [{
                beneficialNumber: 'Beneficial Owner 1',
                dateOfBirth: undefined,
                firstName: undefined,
                guid: 'a03a1196-441f-4fc6-ad82-7219ea02fd11',
                lastName: undefined,
                middleName: undefined,
                percentageOfShare: undefined,
                valueChanges: null,
                _guid: 'a03a1196-441f-4fc6-ad82-7219ea02fd11'
            }]
        };
    }

    setBindingData() {
        return null;
    }


    getComponentByFormFieldConfig() {
        return {
            loadAnswerComponent() {
                return null;
            },
            reset() {
                return null;
            }
        };
    }


    deleteFieldComponentMapItemsByFormFieldConfigId() {
        return null;
    }

    deleteFieldComponentMapItemsByParentFormFieldConfigId() {
        return null;
    }
}

describe('AnswerAgreementQuestion', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        const params = {
            answer: 'Y',
        };
        it('should be run with answer = "Y"', () => {
            action.$event = {
                value: 'Y'
            };
            action.viewModel = new InsuredModel();
            expect(action.execute(params)).toBeFalsy();
        });
        it('should be run with answer = "N"', () => {
            params.answer = 'N';
            action.$event = {
                value: 'Y'
            };
            action.viewModel = new InsuredModel();
            expect(action.execute(params)).toBeFalsy();
        });
    });
});
