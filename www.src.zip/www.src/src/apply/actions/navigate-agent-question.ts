import { Injectable } from '@angular/core';
import { LocatorService, GlobalNavigationService, BaseAction } from '@providers';
@Injectable()
export class NavigateAgentQuestion extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): void {
    this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission/agent-question');
  }
}
