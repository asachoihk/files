import { TestBed } from '@angular/core/testing';
import { LocatorService, BaseModel } from '@providers';
import { ShowSourceOfFunds } from './show-source-of-funds';

class Action extends ShowSourceOfFunds {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }
    getService() { }
}


describe('ShowSourceOfFunds', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be create', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - excute', () => {
        it('should be run', () => {
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton', relationships: ['beneficialOwnerList', 'beneficialOwnerAllocation'], dataBinding: { path: '' } };
            action.viewModel = new BaseModel();
            spyOn(action.ls, 'getService').and.returnValue({
                getDisplayValue() {
                    return ['Others', 'Remittance'];
                },
                getComponentByFormFieldConfigId() {
                    return {
                        visibility: ''
                    };
                },
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be run without Others || Remittance', () => {
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton', relationships: ['beneficialOwnerList', 'beneficialOwnerAllocation'], dataBinding: { path: '' } };
            action.viewModel = new BaseModel();
            spyOn(action.ls, 'getService').and.returnValue({
                getDisplayValue() {
                    return ['abc'];
                },
                getComponentByFormFieldConfigId() {
                    return {
                        visibility: ''
                    };
                },
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });

});
