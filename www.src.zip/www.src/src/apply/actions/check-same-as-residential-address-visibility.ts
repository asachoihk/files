import { BaseAction, LocatorService, Visibility, InsuredType } from '@providers';
import { InsuredModel } from '@apply/models';

export class CheckSameAsResidentialAddressVisibility extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }
  
  execute(): Visibility {
    const insuredPerson = this.viewModel as InsuredModel;
    return insuredPerson.type === InsuredType.i || insuredPerson.type === InsuredType.r ? Visibility.hidden : Visibility.visible;
  }
}