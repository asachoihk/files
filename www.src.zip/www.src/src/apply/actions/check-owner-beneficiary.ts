import { BaseAction, LocatorService, FormBuilderService, AppContextService, Visibility } from '@providers';
import { BeneficiaryModel, ApplyPage } from '@apply/models';
import { BaseComponent } from '@shared/ui-elements';

export class CheckOwnerBeneficiary extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute() {

        const viewModel = this.parentViewModel as BeneficiaryModel;

        const currentPage = this.ls.getService<AppContextService>('appContextService').appContext.currentPage as ApplyPage;
        const ownerId = currentPage.applyData.owner.id;

        if (viewModel && viewModel.guid === ownerId) {
            const componentControl = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(this.formFieldConfig.id) as BaseComponent;
            if (componentControl) {
                componentControl.visibility = Visibility.disabled;
            }
        }
    }
}
