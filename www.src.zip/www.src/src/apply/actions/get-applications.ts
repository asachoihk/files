import { LocatorService, CustomerService, FormBuilderService, BaseAction, APPLICATION_STATUS, SystemEventService } from '@providers';
import { ActivatedRoute } from '@angular/router';
import * as _ from 'lodash';
import { FilterListViewPipe } from '@shared/pipes';
import { ApplicationService } from '@apply/services';
import { map } from 'rxjs/operators';
import { ApplyServiceNames } from '@apply/const';
import { TableComponent } from '@shared/ui-elements';

export class GetApplications extends BaseAction {
	constructor(protected ls: LocatorService) {
		super(ls);
	}

	execute(params: any) {
		let applicationList = [];
		const customerId = this.ls.get(ActivatedRoute).snapshot.queryParams.customerId || this.ls.getService<CustomerService>('customerService').getCurrent().customerId;
		const tableComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('applications') as TableComponent;

		if (params && params.keywords !== undefined) {
      applicationList = _.cloneDeepWith(params.data);
      if (tableComponent.deleteStatus) {
        const status = [APPLICATION_STATUS.INPROGRESS, APPLICATION_STATUS.EXPIRED];
        const deleteData = applicationList.filter(applyModel => status.indexOf(applyModel.status) > -1);
				applicationList = new FilterListViewPipe().transform(deleteData, params.keywords, this.formFieldConfig.dataSource.params.filterByColumns);
				this.ls.getService<FormBuilderService>('formBuilderService').notifyDependentFieldChanged(this.formFieldConfig, { 'number': applicationList.length, 'total': deleteData.length });
      } else {
				applicationList = new FilterListViewPipe().transform(params.data, params.keywords, this.formFieldConfig.dataSource.params.filterByColumns);
				this.ls.getService<FormBuilderService>('formBuilderService').notifyDependentFieldChanged(this.formFieldConfig, { 'number': applicationList.length, 'total': params.data.length });
			}
			return applicationList;
		} else {
			return this.ls.getService<ApplicationService>(ApplyServiceNames.applicationService).getApplicationHeaders(customerId, !!params.keywords).pipe(map(
				data => {
					if (data && Array.isArray(data)) {
						applicationList = [];
						data.forEach(element => {
							applicationList.push(element);
						});
						if (this.formFieldConfig.dataSource.params.columnSortDefault.isAscending) {
							applicationList = _.sortBy(applicationList, this.formFieldConfig.dataSource.params.columnSortDefault.columnName);
						} else {
							applicationList = _.sortBy(applicationList, this.formFieldConfig.dataSource.params.columnSortDefault.columnName).reverse();
						}
						this.ls.getService<FormBuilderService>('formBuilderService').notifyDependentFieldChanged(this.formFieldConfig, { 'number': applicationList.length, 'total': applicationList.length });
						return applicationList;
					}
				}));
		}
	}
}
