
import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { InsuredModel } from '@apply/models';
import { GetIdentificationUploadMetadata } from './get-identification-upload-metadata';

class Action extends GetIdentificationUploadMetadata {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockLocatorService {
  return;
}

describe('GetIdentificationUploadMetadata', () => {
  let action: Action;
  let ls: LocatorService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run when IDType = ID', () => {
      const params = {
        birthCertificate: 1,
        id: 2,
        militaryCard: 2,
        passport: 1
      };

      const metadata = {
        attachmentType: 'IMPORTANT',
        max: 2,
        maxSize: 4,
        metadataAction: 'getIdentificationUploadMetadata',
        min: 1
      };
      const insuredPerson = new InsuredModel();
      insuredPerson.person.registration.idType = 1;
      action.viewModel = insuredPerson;
      action.formFieldConfig = {metadata};
      expect(action.execute(params).min).toEqual(2);
    });
    it('should be run when IDType = Military_Card', () => {
      const params = {
        birthCertificate: 1,
        id: 2,
        militaryCard: 2,
        passport: 1
      };

      const metadata = {
        attachmentType: 'IMPORTANT',
        max: 2,
        maxSize: 4,
        metadataAction: 'getIdentificationUploadMetadata',
        min: 1
      };
      const insuredPerson = new InsuredModel();
      insuredPerson.person.registration.idType = 3;
      action.viewModel = insuredPerson;
      action.formFieldConfig = {metadata};
      expect(action.execute(params).min).toEqual(2);
    });

    it('should be run when IDType = Passport', () => {
      const params = {
        birthCertificate: 1,
        id: 2,
        militaryCard: 2,
        passport: 1
      };

      const metadata = {
        attachmentType: 'IMPORTANT',
        max: 2,
        maxSize: 4,
        metadataAction: 'getIdentificationUploadMetadata',
        min: 1
      };
      const insuredPerson = new InsuredModel();
      insuredPerson.person.registration.idType = 2;
      action.viewModel = insuredPerson;
      action.formFieldConfig = {metadata};
      expect(action.execute(params).min).toEqual(1);
    });

    it('should be run when IDType = Birth_Certificate', () => {
      const params = {
        birthCertificate: 1,
        id: 2,
        militaryCard: 2,
        passport: 1
      };

      const metadata = {
        attachmentType: 'IMPORTANT',
        max: 2,
        maxSize: 4,
        metadataAction: 'getIdentificationUploadMetadata',
        min: 1
      };
      const insuredPerson = new InsuredModel();
      insuredPerson.person.registration.idType = 6;
      action.viewModel = insuredPerson;
      action.formFieldConfig = {metadata};
      expect(action.execute(params).min).toEqual(1);
    });

    it('should be run when IDType = null', () => {
      const params = {
        birthCertificate: 1,
        id: 2,
        militaryCard: 2,
        passport: 1
      };

      const metadata = {
        attachmentType: 'IMPORTANT',
        max: 2,
        maxSize: 4,
        metadataAction: 'getIdentificationUploadMetadata',
        min: 1
      };
      const insuredPerson = new InsuredModel();
      action.viewModel = insuredPerson;
      action.formFieldConfig = {metadata};
      expect(action.execute(params).min).toEqual(2);
    });
  });
});
