import { LocatorService, JsonConfigService, BaseAction } from '@providers';

export class GetSubsequentPaymentMethod extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(_params: any) {
    return this.ls.getService<JsonConfigService>('jsonConfigService').getSubsequentPaymentMethod();

  }
}

