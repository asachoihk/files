import { LocatorService, FormBuilderService, BaseAction } from '@providers';
import { ProportionListComponent } from '@shared/components';
import { BeneficialOwnerListComponent } from '@apply/components';
import { InsuredModel, BeneficialOwnerModel } from '@apply/models';

export class GetBeneficialOwner extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): any[] {
    const applyData = this.viewModel as InsuredModel;
    const temp = applyData.agreement.beneficialOwners as BeneficialOwnerModel[];
    if (temp) {
      return temp;
    } else {
      const beneficialOwner = new BeneficialOwnerModel();

      this.ls.getService<FormBuilderService>('formBuilderService').setBindingData(this.viewModel, this.formFieldConfig.dataBinding.path, beneficialOwner);



      const beneficialOwnerListComponentId = this.formFieldConfig.id;
      const beneficialOwnerListComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(beneficialOwnerListComponentId) as BeneficialOwnerListComponent;
      beneficialOwnerListComponent.dataSource = beneficialOwnerListComponent.dataSource || [];
      beneficialOwnerListComponent.dataSource.push(beneficialOwner);
      this.ls.getService<FormBuilderService>('formBuilderService').setBindingData(this.viewModel, this.formFieldConfig.dataBinding.path, beneficialOwnerListComponent.dataSource);


      const beneficialOwnerAllocationComponentId = this.formFieldConfig.relationships[1];
      const beneficialOwnerAllocationListComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(beneficialOwnerAllocationComponentId) as ProportionListComponent;
      beneficialOwnerAllocationListComponent.dataSource = beneficialOwnerAllocationListComponent.dataSource || [];
      beneficialOwnerAllocationListComponent.dataSource.push(beneficialOwner);
      this.ls.getService<FormBuilderService>('formBuilderService').setBindingData(this.viewModel, this.formFieldConfig.dataBinding.path, beneficialOwnerAllocationListComponent.dataSource);
    }
  }
}
