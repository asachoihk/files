import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { CheckDeleteApplication } from './check-delete-application';

describe('CheckDeleteApplication', () => {
    let service: CheckDeleteApplication;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                CheckDeleteApplication
            ]
        });
        service = TestBed.get(CheckDeleteApplication);
    });

    // beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    describe('Function - Excute', () => {
        const params = 'SIGNED';
        it('should be run', () => {
            expect(service.execute(params)).toBeTruthy();
        });
    });
});
