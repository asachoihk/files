import { LocatorService, InsuredType, BaseAction } from '@providers';
import { BeneficiaryModel, InsuredModel } from '@apply/models';
import { ApplicationService, InsuredPersonService } from '@apply/services';

export class GetOwner extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): BeneficiaryModel[] {

    const applyData = this.ls.getService<ApplicationService>('applicationService').getCurrentApplyData();
    const insuredPeople = this.ls.getService<InsuredPersonService>('insuredPersonService').getInsuredPersons(applyData) as InsuredModel[];

    const owner = insuredPeople.find(p => p.type === InsuredType.o);
    if (owner) {

      const dependent = new BeneficiaryModel();
      dependent.person = owner.person;
      if (owner.person.basicInfo.fullName) {
        dependent.fullNameOwner = owner.person.basicInfo.firstName + ' ' + owner.person.basicInfo.middleName + ' ' + owner.person.basicInfo.lastName;
      } else {
        const firstName = owner.person.basicInfo.firstName ? owner.person.basicInfo.firstName : '';
        const middleName = owner.person.basicInfo.middleName ? owner.person.basicInfo.middleName : '';
        const lastName = owner.person.basicInfo.lastName ? owner.person.basicInfo.lastName : '';
        dependent.fullNameOwner = lastName + ' ' + middleName + ' ' + firstName;
      }
      return [dependent];
    }
    return [];

  }

}
