import { TestBed } from '@angular/core/testing';
import { LocatorService, FormBuilderService } from '@providers';
import { GetBeneficialOwner } from './get-beneficial-owner';
import { TranslationService } from 'angular-l10n';
import { InsuredModel, BeneficialOwnerModel, AgreementModel } from '@apply/models';


class Action extends GetBeneficialOwner {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        switch (serviceName) {
            case 'formBuilderService':
                return new MockFormBuilderService
            default:
                break;
        }
    }
}

class MockFormBuilderService {
    constructor() {

    }
    setBindingData() {
        return null
    }

    getComponentByFormFieldConfigId(app: string) {
        return {
            dataSource : [{
                actionName: 'actionName',
                params : {
                  filerByColumns : 'filerByColumns'
                }
              }
            ],
            relationships: [
                'parent','child'
            ]
        }
    }
}

describe('GetBeneficialOwner', () => {
    let action: Action;
    let ls: LocatorService;
    let tran: TranslationService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService },

            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run have beneficialOwners', () => {
            const viewModel = new InsuredModel();
            viewModel.agreement = new AgreementModel();
            viewModel.agreement.beneficialOwners =  [new BeneficialOwnerModel()];
            viewModel.agreement.beneficialOwners[0].firstName = 'firstName';
            action.viewModel = viewModel;
            expect(action.execute()[0].firstName).toEqual('firstName');
        });

        it('should be run beneficialOwners is null', () => {
            action.viewModel = new InsuredModel();
            (action.viewModel as any) = {
                agreement: {
                    beneficialOwners: null  
                }
            }

            action.formFieldConfig = {
                id: 'id',
                type:'type',
                dataBinding: {
                    path : "www"
                },
                dataSource : {
                  actionName: 'actionName',
                  params : {
                    filerByColumns : 'filerByColumns'
                  }
                },
                relationships: [
                    'parent','child'
                ]
              };
              
            expect(action.execute()).toBeDefined;
        });

    });
});
