import { TestBed, async } from '@angular/core/testing';
import { LocatorService, JsonConfigService, CustomerService, FormBuilderService } from '@providers';
import { GetApplications } from './get-applications';
import { ApplicationService } from '@apply/services';
import { ActivatedRoute } from '@angular/router';
import { isObservable, Observable } from 'rxjs';


class Action extends GetApplications {
    constructor(public ls: LocatorService) {
      super(ls);
    }
  }

  class MockLocatorService {
    getService(serviceName: string) {
        switch (serviceName) {
          case 'applicationService':
            return new MockApplicationService();
          case 'customerService':
            return new MockCustomerService
          case 'formBuilderService':
            return new MockFormBuilderService
          default:
            break;
        }
      }

    get() {
      return new MockActivatedRoute
    }
  }

  class MockFormBuilderService {
    constructor() {

    }
    notifyDependentFieldChanged() {
      return null;
    }

    getComponentByFormFieldConfigId(app : string) {
      return {
      }
    }
  }

  class MockCustomerService {
    constructor() {
    }
    getCurrent() {
      return {
        customerId : 'abc'
      }
    }
  }

  class MockActivatedRoute {
    constructor() {
    }
    snapshot = {
      queryParams: {
        applicationId : '1234'
      }
    }
  }

  class MockApplicationService {
    constructor() {
    }
    getApplyData(appId : string) {
        return {
            
        }
    }

    getApplicationHeaders(params){
      return new Observable(sub => {
        sub.next([{
          applicationId: '9e101e2c-ca71-5789-bd34-60cde6d59540',
          customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdea',
          protectionAmountApply: '',
          status: 'APPLICATION_INPROGRESS'
        }]);
      }); 
    }

  }

describe('GetApplications', () => {
    let action: Action;
    let ls: LocatorService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ApplicationService, useClass: MockApplicationService },
                { provide: ActivatedRoute, useClass: MockActivatedRoute },
                { provide: CustomerService, useClass: MockCustomerService },
                { provide: FormBuilderService, useClass: MockFormBuilderService },

            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
      });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
      it('should be run', () => {
        const params = {
          keywords: 'keywords',
          data: 'data'
        };
          action.formFieldConfig = {
            id: 'id',
            type:'type',
            dataSource : {
              actionName: 'actionName',
              params : {
                filerByColumns : 'filerByColumns'
              }
            }
          };
          expect(action.execute(params));
      });

      it('should be isAscending : true ',async( () => {
        const params = {
          keywords: undefined,
          data: []
        };
        action.formFieldConfig = {
          id: 'id',
          type:'type',
          dataSource : {
            actionName: 'actionName',
            params : {
              filerByColumns : 'filerByColumns',
              columnSortDefault : {
                isAscending : true
              }
            }
          }
        };
        const res = action.execute(params);
        if(isObservable(res)){
          res.subscribe(data =>{
            expect(data).toEqual([{
              applicationId: '9e101e2c-ca71-5789-bd34-60cde6d59540',
              customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdea',
              protectionAmountApply: '',
              status: 'APPLICATION_INPROGRESS'
            }]);
          });
        }
      }));

      it('should be isAscending : false ',async( () => {
        const params = {
          keywords: undefined,
          data: [{
            applicationId: '9e101e2c-ca71-5789-bd34-60cde6d59540',
            customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdea',
            protectionAmountApply: '',
            status: 'APPLICATION_INPROGRESS'
          }]
        };
        action.formFieldConfig = {
          id: 'id',
          type:'type',
          dataSource : {
            actionName: 'actionName',
            params : {
              filerByColumns : 'filerByColumns',
              columnSortDefault : {
                isAscending : false
              }
            }
          }
        };
        const res = action.execute(params);
        if(isObservable(res)){
          res.subscribe(data =>{
            expect(data).toEqual([{
              applicationId: '9e101e2c-ca71-5789-bd34-60cde6d59540',
              customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdea',
              protectionAmountApply: '',
              status: 'APPLICATION_INPROGRESS'
            }]);
          });
        }
      }));

      

      it('should be run isAscending : true', () => {
        const params = {
          keywords: 'acb',
          data: [{
            applicationId: '9e101e2c-ca71-5789-bd34-60cde6d59540',
            customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdea',
            protectionAmountApply: '',
            status: 'APPLICATION_INPROGRESS'
          }]        
        };
        action.formFieldConfig = {
          id: 'id',
          type:'type',
          dataSource : {
            actionName: 'actionName',
            params : {
              filerByColumns : 'filerByColumns',
              columnSortDefault : {
                isAscending : true
              }
            }
          }
        };
        spyOn(action.ls, 'getService').and.returnValue({

          notifyDependentFieldChanged() {
            return null;
          },
          getComponentByFormFieldConfigId(app : string) {
            return {
              deleteStatus : true
            }
          },
          getCurrent() {
            return {
              customerId : 'customerId'
            }
          }
      });
      expect(action.execute(params));
    });

  });
});
