import { LocatorService, FormBuilderService, CustomDialogActionType, DialogService, CustomDialogResult, BaseAction, FieldComponentMapItem, VisibilityRefreshed, Visibility } from '@providers';
import { TranslationService } from 'angular-l10n';
import { CustomDialogComponent, ButtonComponent } from '@shared/ui-elements';
import { SystemEventService } from 'providers/services';
import { AgreementInsuranceListComponent } from '@apply/components';

export class RemoveAgreementInsurace extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(_params: any): any {
    const formBuilderService = this.ls.getService<FormBuilderService>('formBuilderService');
    if (this.parentViewModel && this.parentFormFieldConfig) {
      const agreementInsuranceList = formBuilderService.getComponentByFormFieldConfigId(this.parentFormFieldConfig.id) as AgreementInsuranceListComponent;
      let dataSource = agreementInsuranceList.dataSource;
      if (dataSource && dataSource.length > 1 && agreementInsuranceList) {
        const dialogConfig = {
          disableClose: true,
          data: {
            message: this.ls.get(TranslationService).translate('MSGA051'),
            buttons: [
              { title: 'no', type: 'red-outline', action: CustomDialogActionType.no },
              { title: 'yes', type: 'red', action: CustomDialogActionType.yes }
            ]
          }
        };
        this.ls.getService<DialogService>('dialogService').showCustomDialog(CustomDialogComponent, dialogConfig, (result: CustomDialogResult) => {
          if (result.action === CustomDialogActionType.yes) {
            const itemIndex = dataSource.findIndex(item => item === this.viewModel);
            dataSource = dataSource.filter(item => item !== this.viewModel);
            agreementInsuranceList.dataSource = dataSource;
            formBuilderService.setBindingData(this.parentViewModel, this.parentFormFieldConfig.dataBinding.path, dataSource);
            const button = formBuilderService.getComponentByFormFieldConfigId(_params.addBtnFieldId) as ButtonComponent;
            if (button) {
              button.visibility = Visibility.visible;
              button.formControl.markAsDirty();
            }

            this.ls.getService<SystemEventService>('systemEventService').publish(new VisibilityRefreshed());

            // remove controls from mapComponent
            formBuilderService.deleteFieldComponentMapItemsByFormFieldConfig(this.formFieldConfig);
            const children: FieldComponentMapItem[] = formBuilderService.getChildComponentsByFormFieldConfig(this.parentFormFieldConfig) || [];
            this.formFieldConfig.relationships.forEach(rel => {
              const target = children.filter(c => c.formFieldConfig.id === rel)[itemIndex];
              if (target && target.formFieldConfig) {
                formBuilderService.deleteFieldComponentMapItemsByFormFieldConfig(target.formFieldConfig);
              }
            });
          }
        });
      }
    }
  }
}
