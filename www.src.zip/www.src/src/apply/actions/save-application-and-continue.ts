import { LocatorService, CustomerService, GlobalNavigationService, SystemEventService, FormBuilderService, SaveAction, DataSaved, AppContextService } from '@providers';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { DocumentType } from 'providers/enums/document-type.enum';
import { ApplicationService, ProgressService } from '@apply/services';
import { ApplyModel } from '@apply/models';
import { PaymentMethod } from '@apply/enums';
import { ApplySection } from '@apply/const';
import { DocumentDeleted } from 'providers/models/system-event/document-deleted';

export class SaveApplicationAndContinue extends SaveAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any): Observable<any> {
    const ignoreGoToNextPage = this.ignoreGoToNextPage(params);
    return new Observable<any>(subscriber => {
      const navigationService = this.ls.getService<GlobalNavigationService>('globalNavigationService');
      const customerId =  this.ls.get(ActivatedRoute).snapshot.queryParams.customerId || this.ls.getService<CustomerService>('customerService').getCurrent().customerId;
      const applyData = this.viewModel as ApplyModel;

      // to do fix payment progress bar
      const sectionName = navigationService.getCurrentNavigationPage().id;

      if (sectionName === ApplySection.PAYMENT.toString()) {
        if (applyData.payment && applyData.payment.method && applyData.payment.method === PaymentMethod.ONLINE) {
          applyData.payment.documents = (applyData.payment.documents || []).filter(d => d.type !== DocumentType.RECEIPT);
        }
        else if (applyData.payment && applyData.payment.renewalMethod && applyData.payment.renewalMethod !== 'AUTODEBIT') {
          applyData.payment.documents = (applyData.payment.documents || []).filter(d => d.type !== DocumentType.SUBSEQUENCE);
        }
        this.ls.getService<SystemEventService>('systemEventService').publish(new DocumentDeleted(applyData.payment));

        const paymentProgress = applyData.payment.mode && applyData.payment.method && applyData.payment.renewalMethod ? 100 : applyData.payment.mode || applyData.payment.method ? 50 : 0;
        this.ls.getService<ProgressService>('progressService').updateSectionProgress(applyData, paymentProgress);
      }
      // end
      
      this.ls.getService<ApplicationService>('applicationService').saveApplyData(customerId, [applyData]).subscribe(result => {
        if (!ignoreGoToNextPage) {
          const leftNavItems = navigationService.getLeftNavigationItems();
          const currentUrl = navigationService.getCurrentNavigationPage();
          const position = leftNavItems.findIndex(result => result.id === currentUrl.id);
          navigationService.navigateTo(leftNavItems[position + 1].url);
        }

        const formId = this.ls.getService<AppContextService>('appContextService').currentFormBuilder.id;
        this.ls.getService<FormBuilderService>('formBuilderService').markFormTouched(formId);

        this.ls.getService<SystemEventService>('systemEventService').publish(new DataSaved());

        subscriber.next(result);
      });

    });
  }

  ignoreValidationResult() {
    return true;
  }

  ignoreGoToNextPage(params: any) {
    return params && params.ignoreGoToNextPage;
  }

}
