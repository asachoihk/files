import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { ApplyModel } from '@apply/models';
import { ShowDeleteApplicationMultiple } from './show-delete-application-multiple';
import { of } from 'rxjs/observable/of';

class Action extends ShowDeleteApplicationMultiple {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }
    getService() { }
}


describe('ShowDeleteApplicationMultiple', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be create', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - excute', () => {
        it('should be run', () => {
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton', relationships: ['beneficialOwnerList', 'beneficialOwnerAllocation'], dataBinding: { path: ''} };
            action.viewModel = new ApplyModel();
            (action.viewModel as any) = {
                declaration_answer: {},
                notifyValueChanges() {
                    return;
                }
            };
            spyOn(action.ls, 'getService').and.returnValue({
                tempEventDeleteMultiCustomer: {
                    next() {
                        return of({});
                    }
                },
                getComponentByFormFieldConfigId() {
                    return {
                        dataTable: [
                            {
                                status: 'EXPIRED'
                            }
                        ],
                        loadDataSourceWithData() {
                            return;
                        }
                    };
                }
            });
            action.execute({
                applicationsFieldId: 'applicationsFieldId'
            });
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });

});
