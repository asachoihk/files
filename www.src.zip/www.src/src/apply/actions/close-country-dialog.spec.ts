import { LocatorService } from '@providers';
import { CloseCountryDialog } from './close-country-dialog';
import { TestBed } from '@angular/core/testing';
import { MatDialogRef } from '@angular/material';

class Action extends CloseCountryDialog {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {

}

describe('CloseCountryDialog', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
        spyOn(action.ls, 'getService').and.callThrough();
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            const params = {
            };
            const dialogRef = {
                close() {
                    return;
                }
            };
            action.dialogRef = dialogRef as MatDialogRef<any, any>;
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});