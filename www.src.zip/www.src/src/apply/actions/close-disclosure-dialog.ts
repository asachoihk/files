import { CancelAction, LocatorService, CustomDialogConfig, CustomDialogActionType, CustomDialogResult, DialogService, ActionService } from '@providers';
import { TranslationService } from 'angular-l10n';
import { CustomDialogComponent } from '@shared/ui-elements';
import { UnderwritingModel } from 'disclosure/models/underwriting-model';

export class CloseDisclosureDialog extends CancelAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params?: any) {
        if (params && params.ignoreTrackDataChanges) {
            const underwritingModel = this.viewModel as UnderwritingModel;
            delete underwritingModel.hasChanges;
            this.dialogRef.close(underwritingModel);
            return;
        }

        const dialogConfig: CustomDialogConfig = {
            disableClose: true,
            data: {
                message: this.ls.get(TranslationService).translate('MSGSaveAgreement'),
                buttons: [
                    { title: 'save', type: 'red', action: CustomDialogActionType.yes },
                    { title: 'dontSave', type: 'red', action: CustomDialogActionType.no },
                    { title: 'cancel', type: 'red-outline', action: CustomDialogActionType.cancel }
                ]
            }
        };

        this.ls.getService<DialogService>('dialogService').showCustomDialog(CustomDialogComponent, dialogConfig, (result: CustomDialogResult) => {
            if (result.action === CustomDialogActionType.yes) {
                this.ls.getService<ActionService>('actionService').executeAction('saveDisclosureDataAndContinue', this, { ignoreGoToNextPage: true }, saveResult => {
                    this.dialogRef.close(saveResult);
                });
            } else if (result.action === CustomDialogActionType.no) {
                this.dialogRef.close(result);
            } else if (result.action === CustomDialogActionType.cancel) {

            }
        });
    }

    detectChanges(): boolean {
        return (this.viewModel as UnderwritingModel).hasChanges;
    }

    getDefaultCloseParams() {
        return this.viewModel;
    }
}
