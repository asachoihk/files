import { BaseAction, LocatorService, FormBuilderService, Visibility } from '@providers';


export class HiddenSecondaryOccupation extends BaseAction {

  constructor(protected ls: LocatorService) {
    super(ls);
  }
  execute() {
    const a = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig);
    if (a) {
      a.visibility = Visibility.hidden;
    }
  }
}
