import { LocatorService, BaseAction, GlobalNavigationService, AppContextService, GlobalNavigationPage } from '@providers';
import { InsuredModel } from '@apply/models';
import { FormBuilderDialog } from '@shared/ui-elements';
import { TranslationService } from 'angular-l10n';

export class GetDialogTitle extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(): string {
        const currentPage = this.ls.getService<GlobalNavigationService>('globalNavigationService').getCurrentNavigationPage();
        if (this.viewModel instanceof InsuredModel) {
            const insuredPerson = this.viewModel as InsuredModel;
            return this.getDialogTitle(insuredPerson, currentPage);
        } else {
            const disclosureDialog = this.ls.getService<AppContextService>('appContextService').currentFormBuilder as FormBuilderDialog;
            if (disclosureDialog.data && disclosureDialog.data.params && (disclosureDialog.data.params.insuredPerson instanceof InsuredModel)) {
                return this.getDialogTitle(disclosureDialog.data.params.insuredPerson as InsuredModel, currentPage);
            }
        }

        return currentPage.label;
    }

    private getDialogTitle(insuredPerson: InsuredModel, currentPage: GlobalNavigationPage): string {
        return this.ls.get(TranslationService).translate(currentPage.label) + ' - ' + insuredPerson.person.basicInfo.firstName + ' ' + insuredPerson.person.basicInfo.lastName;
    }
}
