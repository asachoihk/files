import { BaseAction, LocatorService, DialogService, FormBuilderService, InsuredType, AppContextService } from '@providers';
import { DialogShellComponent } from '@shared/shells';
import { InsuredModel } from '@apply/models';
import { TaskCardListComponent } from '@shared/components';
import { AgreementsDialogComponent } from '@apply/pages';

export class LoadAgreementsDialog extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute() {
        let jsonName = 'agreements-owner-dialog';
        const viewModel = this.viewModel as InsuredModel;
        const type = viewModel.type;

        switch (type) {
            case InsuredType.io:
            case InsuredType.o:
                jsonName = 'agreements-owner-dialog';
                break;
            case InsuredType.i:
                jsonName = 'agreements-insured-dialog';
                break;
            case InsuredType.r:
                jsonName = 'agreements-dependent-dialog';
                break;
        }
        if (jsonName) {
            const data = {
                viewModel: this.viewModel,
                jsonName: jsonName
            };
            this.ls.getService<DialogService>('dialogService').showFormBuilderDialog(AgreementsDialogComponent, DialogShellComponent, data, _result => {
                // if (result) {
                const currentFormBuilder = this.ls.getService<AppContextService>('appContextService').currentFormBuilder;
                currentFormBuilder.refreshData(() => {

                    const taskCardList = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as TaskCardListComponent;
                    if (taskCardList) {
                        taskCardList.loadDataSource();
                    }
                });
                // }
            });
        }
    }
}
