import { EditBeneficaryOwnerDialog } from './edit-beneficiary-owner-dialog';
import { LocatorService, AppContextService, DialogService, SystemEventService, FormBuilderService, ActionService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { ChangeDetectorRef } from '@angular/core';
import { ButtonComponent } from '@shared/ui-elements';

class Action extends EditBeneficaryOwnerDialog {
    constructor(public ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

        if (serviceName === 'appContextService') {
            return new MockAppContextService();
        }

        if (serviceName === 'actionService') {
            return new MockActionService();
        }

        if (serviceName === 'systemEventService') {
            return new MockSystemEventService();
        }

        if (serviceName === 'dialogService') {
            return new MockDialogService();
        }
    }

    getAction() {
        return new MockCheckAvailable();
    }
}

class MockAppContextService {
    appContext = {
        currentPage: {
            applyData: {
                owner: {
                    id: 'abc'
                }
            }
        }
    };
    currentFormBuilder = {
        refreshData(callback) {
            return callback({});
        }
    };
}

class MockCheckAvailable {
    invoke() {
        return {};
    }
}

class MockFormBuilderService {
    constructor() { }
    get() {
        return null;
    }

    getComponentByFormFieldConfigId(configId: string) {
        if (configId === 'btn-add') {
            let ls: LocatorService;
            let cdr: ChangeDetectorRef;
            return new ButtonComponent(ls, cdr);
        }
        return {
            loadDataSource() {
                return null;
            }
        };
    }
    setBindingData() {
        return null;
    }

    getComponentByFormFieldConfig() {
        return {
            loadDataSource() {
                return {};
            }
        };
    }
}

class MockActionService {
    createActionParams() {
        return {};
    }
}

class MockSystemEventService {
    publish() {
        return {};
    }
}

class MockDialogService {
    showFormBuilderDialog(BeneficiaryDialogComponent, DialogShellComponent, dialogData, callback) {
        return callback({
            result: 'abc'
        });
    }
}

describe('EditBeneficaryOwnerDialog', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: DialogService, useClass: MockDialogService },
                { provide: SystemEventService, useClass: MockSystemEventService },
                { provide: FormBuilderService, useClass: MockFormBuilderService },
                { provide: AppContextService, useClass: MockAppContextService },
                { provide: ActionService, useClass: MockActionService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
        spyOn(action.ls, 'getService').and.callThrough();
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run - (viewModel && viewModel.selected) === true', () => {
            const params = {
                guid: '',
            };
            const formFieldConfig = {
                relationships: ['abc', 'xyz']
            };
            const parentFormFieldConfig = {};
            action.parentFormFieldConfig = parentFormFieldConfig as any;
            action.formFieldConfig = formFieldConfig as any;
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});