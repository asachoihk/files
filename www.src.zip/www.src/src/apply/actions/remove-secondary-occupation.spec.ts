import { RemoveSecondaryOccupation } from './remove-secondary-occupation';
import { LocatorService, FormBuilderService } from '@providers';
import { TestBed } from '@angular/core/testing';

class Action extends RemoveSecondaryOccupation {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

    }
}

class MockFormBuilderService {
    getComponentByFormFieldConfigId() {
        return {
            visibility: 'hidden'
        };
    }

    getComponentByFormFieldConfig() {
        return {};
    }
}

describe('RemoveSecondaryOccupation', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            spyOn(action.ls, 'getService').and.callThrough();
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});