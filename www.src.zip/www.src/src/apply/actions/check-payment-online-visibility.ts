import { LocatorService, BaseAction, Visibility } from '@providers';
import { ApplyModel } from '@apply/models';
import { PaymentMethod } from '@apply/enums';

export class CheckPaymentOnlineVisibility extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute() {
        const applyData = this.viewModel as ApplyModel;
        switch (applyData.payment.method) {
            case PaymentMethod.ONLINE:
                return Visibility.visible;
            default:
                return Visibility.hidden;
        }
    }
}

