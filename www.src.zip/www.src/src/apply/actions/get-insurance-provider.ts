import { LocatorService, JsonConfigService, BaseAction, JsonConfigItem } from '@providers';
import { Observable } from 'rxjs';
import * as _ from 'lodash';

export class GetInsuranceProvider extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Observable<JsonConfigItem[]> {
    return new Observable<JsonConfigItem[]>(subscriber => {
      const insuranceProviders = this.ls.getService<JsonConfigService>('jsonConfigService').getInsuranceProvider();
      if (this.formFieldConfig.type === 'list') {
        subscriber.next(_.cloneDeepWith(insuranceProviders));
      } else {
        const defaultValues = this.formFieldConfig.default as string;
        if (!defaultValues) {
          subscriber.next(_.cloneDeepWith(insuranceProviders));
        } else {
          subscriber.next(_.cloneDeepWith(insuranceProviders.filter(c => defaultValues.includes(c.id))));
        }
      }
    });
  }
}
