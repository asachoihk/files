import { LocatorService, JsonConfigService, BaseAction, JsonConfigItem } from '@providers';


export class GetHabits extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): JsonConfigItem[] {
    const typeHabit = this.formFieldConfig.id;
    if (typeHabit === 'drinkStatus') {
      return this.ls.getService<JsonConfigService>('jsonConfigService').getDrinking();
    } else if (typeHabit === 'smokingStatus') {
      return this.ls.getService<JsonConfigService>('jsonConfigService').getSmoking();
    }
    return null;

  }
}
