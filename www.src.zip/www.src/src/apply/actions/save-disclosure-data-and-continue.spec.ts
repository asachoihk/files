import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { SaveDisclosureDataAndContinue } from './save-disclosure-data-and-continue';
import { UnderwritingModel, ApplyModel, InsuredModel } from '@apply/models';
import { MatDialogRef } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs/internal/observable/of';

class Action extends SaveDisclosureDataAndContinue {
    constructor(public ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    get(service) {
        if (service instanceof ActivatedRoute) {
            return new MockActivatedRoute();
        }
        return new MockDisclosureValidationService();
    }

    getService(serviceName: string): any {
        if (serviceName === 'appContextService') {
            return new MockAppContextService();
        } else if (serviceName === 'progressService') {
            return new MockProgressService();
        }
        return new MockInsuredPersonService();
    }
}

class MockActivatedRoute {
    snapshot = {
        queryParams: {
            applicationId: '18072433-c834-755a-9372-6826ef99f9fb',
            customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab'
        }
    };
}

class MockDisclosureValidationService {
    validateDisclosureData() {
        return true;
    }
}

class MockInsuredPersonService {
    updateInsuredPersonToApplication() {
       return;
    }
}

class MockProgressService {
    calculateCurrentInsuredPersonProgress() {
        return 0;
    }

    updateInsuredPersonProgress() {
        return 0;
    }
}

class MockAppContextService {
    currentFormBuilder = {
        data: {
            params: {
                applyData: new ApplyModel(),
                insuredPerson: new InsuredModel()
            }
        }
    };
}

class MockMatDialogRef {
    close() {
      return true;
    }
}

describe('SaveDisclosureDataAndContinue', () => {
    let action: Action;
    let ls;
    let dialogRef: any;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: MatDialogRef, useClass: MockMatDialogRef },
            ],
        });
        ls = TestBed.get(LocatorService);
        dialogRef = TestBed.get(MatDialogRef);
    });
    beforeEach(() => {
        action = new Action(ls);
        action.dialogRef = dialogRef;
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', (done) => {
            const params = {
                saveAndClose: true
            };
            action.viewModel = new UnderwritingModel();
            (action.viewModel as any) = {
                hasChanges: true,
                answers: [{
                    id: '1',
                    answer: 'Y',
                }],
                reflexiveAnswers: [
                    {
                        baseQuestionId: '1',
                        reflexive: [{
                            ruleId: '1',
                            decisionPath: {
                                id: '1',
                                decision: 'test',
                                localeDecision: 'test',
                                question: 'test',
                                isNonInteractionRQ: false
                            }
                        }]
                    }
                ],
                rulebookId: 'rulebookId',
                rulebookLocale: 'rulebookLocale'
            };
            spyOn(action.ls, 'get').and.returnValue({
                snapshot: {
                    queryParams: {
                        applicationId: '18072433-c834-755a-9372-6826ef99f9fb',
                        customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab'
                    }
                },
            });
            spyOn(action.ls, 'getService').and.returnValue({
                getCurrentNavigationPage() {
                    return {
                        id: '1'
                    };
                },
                getLeftNavigationItems() {
                    return [
                        {
                            id: '1',
                            url: ''
                        },
                        {
                            id: '2',
                            url: ''
                        }
                    ];
                },
                currentFormBuilder: {
                    data: {
                        params: {
                            applyData: new ApplyModel(),
                            insuredPerson: new InsuredModel()
                        }
                    }
                },
                calculateCurrentInsuredPersonProgress() {
                    return 0;
                },
                updateInsuredPersonProgress() {
                    return 0;
                },
                updateInsuredPersonToApplication() {
                    return;
                },
                saveApplyData() {
                    return of({id: '1'});
                },
                navigateTo() {
                    return '';
                },
                publish() {
                    return of({});
                },
                markFormTouched() {
                    return;
                }
            });
            action.execute(params).subscribe(value => {
                expect(value).toBeTruthy();
                done();
            });
        });
    });

    describe('Function - ignoreValidationResult', () => {
        it('should be run', () => {
            expect(action.ignoreValidationResult()).toBe(true);
        });
    });

    describe('Function - ignoreValidationResult', () => {
        it('should be run', () => {
            expect(action.validateForm('_formId', {})).toBe(true);
        });
    });
});
