import { LocatorService, FormBuilderService, DialogData } from '@providers';
import { TranslationService } from 'angular-l10n';
import { OpenSearchListDialog } from '@shared/actions/search-list/open-search-list-dialog';

export class LoadNatureDialogJobIncome extends OpenSearchListDialog {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  getDialogData(): DialogData {
    return {
      viewModel: this.viewModel,
      formFieldConfig: this.parentFormFieldConfig,
      params: {
        componentParams: {
          header: 'Nature of Business',
          dataSource: {
            actionName: 'getNatureOfBusiness'
          },
          dataSourceMetadata: this.formFieldConfig.dataSourceMetadata
        }
      }
    };
  }

  handleSearchListDialogClosed(result: any) {
    const value = this.ls.get(TranslationService).translate(result.transId);
    this.ls.getService<FormBuilderService>('formBuilderService').setFormFieldValue(this.viewModel, this.formFieldConfig, value);
    this.viewModel.notifyValueChanges(this.formFieldConfig);
  }
}
