import { LocatorService, BaseAction } from '@providers';
import { InsuredModel } from '@apply/models';

export class GetPercentageBeneficialOwner extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const applyData = this.viewModel as InsuredModel;
    if (applyData && applyData.agreement && applyData.agreement.beneficialOwners) {
      const temp = applyData.agreement.beneficialOwners;
      return temp;
    }
  }
}
