import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { GetCreditCards } from './get-credit-cards';

class Action extends GetCreditCards {
    constructor(public ls: LocatorService) {
      super(ls);
    }
  }

  class MockLocatorService {
    constructor() {
    }
  }

describe('GetCreditCards', () => {
    let action: Action;
    let ls: LocatorService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
      });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
      const params =
      {
        action: 'abc',
        cards: [          
          {
            action: '123',
          },
          {
            action: '123',
          }
        ]
      }
        it('should be run', () => {
            expect(action.execute(params));
        });
    });
});
