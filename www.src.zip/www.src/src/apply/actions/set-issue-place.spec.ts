import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { SetIssuePlace } from './set-issue-place';

class Action extends SetIssuePlace {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }
    getService() { }
}


describe('SetIssuePlace', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be create', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - excute', () => {
        it('should be run', () => {
            expect(action.execute({ value: 'Y' })).toBeFalsy();
        });
    });

});
