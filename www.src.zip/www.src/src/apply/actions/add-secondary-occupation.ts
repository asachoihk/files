import { BaseAction, LocatorService, FormBuilderService, Visibility } from '@providers';
import { ButtonComponent } from '@shared/ui-elements';


export class AddSecondaryOccupation extends BaseAction {

  constructor(protected ls: LocatorService) {
    super(ls);
  }
  execute(): any {
    const add = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as ButtonComponent;
    const secondaryOccupation = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('secondaryOccupation');
    const removeButton = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('removeIcon');
    if (add) {
      add.visibility = Visibility.hidden;
      secondaryOccupation.visibility = Visibility.visible;
      removeButton.visibility = Visibility.visible;
    }
  }
}
