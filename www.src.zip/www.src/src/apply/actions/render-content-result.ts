import { BaseAction, LocatorService } from '@providers';
import { ApplyModel } from '@apply/models';

export class RenderContentResult extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const clean =
      '<p>Congratulations! <b>Your application is conditionally approved</b> subject to internal record checking. <b>Your payment is successfully completed</b>. You will be notified through your insurance advisor and trough you provided email address if there are further requirement(s).</p>';
    const nonClean =
      '<p>Thank you for your insurance application. <b>Your payment is successfully completed</b>. Your application is referred to our Underwriting Department for further assessment.</p>';
    const applyData = this.viewModel as ApplyModel;
    const token = (applyData.declaration_answer.agent_question === 'Y' ? applyData.declaration_answer.agent_answer : 'Clean').toUpperCase();

    return token === 'NONCLEAN' ? nonClean : clean;
  }
}
