
import { LocatorService, JsonConfigService, BaseAction, JsonBankBranchConfigItem } from '@providers';
import { Observable } from 'rxjs';
import * as _ from 'lodash';

export class GetBankBranchs extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Observable<JsonBankBranchConfigItem[]> {

    return new Observable<JsonBankBranchConfigItem[]>(subscriber => {
      const bankBranchs = this.ls.getService<JsonConfigService>('jsonConfigService').getBankBranches();
      subscriber.next(_.cloneDeepWith(bankBranchs));
    });
  }
}
