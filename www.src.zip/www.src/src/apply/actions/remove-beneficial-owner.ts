import { LocatorService, FormBuilderService, CustomDialogActionType, CustomDialogResult, DialogService, SystemEventService, BaseAction, Visibility, AgreementAnswerMetadata, FieldComponentMapItem, VisibilityRefreshed } from '@providers';
import { CustomDialogComponent, ButtonComponent } from '@shared/ui-elements';
import { ProportionListComponent } from '@shared/components';
import { TranslationService } from 'angular-l10n';
import { BeneficialOwnerListComponent } from '@apply/components';
import { BeneficialOwnerModel } from '@apply/models';

export class RemoveBeneficialOwner extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const formBuilderService = this.ls.getService<FormBuilderService>('formBuilderService');
    if (this.parentViewModel && this.parentFormFieldConfig) {
      const beneficialOwnerList = formBuilderService.getComponentByFormFieldConfigId(this.parentFormFieldConfig.id) as BeneficialOwnerListComponent;

      let dataSource = beneficialOwnerList.dataSource;
      if (dataSource && dataSource.length > 1 && beneficialOwnerList) {
        const dialogConfig = {
          disableClose: true,
          data: {
            message: this.ls.get(TranslationService).translate('MSGA049'),
            buttons: [
              { title: 'no', type: 'red-outline', action: CustomDialogActionType.no },
              { title: 'yes', type: 'red', action: CustomDialogActionType.yes }
            ]
          }
        };
        this.ls.getService<DialogService>('dialogService').showCustomDialog(CustomDialogComponent, dialogConfig, (result: CustomDialogResult) => {
          if (result.action === CustomDialogActionType.yes) {
            const itemIndex = dataSource.findIndex(item => item === this.viewModel);
            dataSource = dataSource.filter(item => item !== this.viewModel);
            beneficialOwnerList.dataSource = dataSource;
            const len = beneficialOwnerList.dataSource.length;
            for (let i = 0; i < len; i++) {
              beneficialOwnerList.dataSource[i].beneficialNumber = 'Beneficial Owner ' + (i + 1);
            }
            // formBuilderService.setBindingData(this.parentViewModel, this.parentFormFieldConfig.dataBinding.path, dataSource);

            const beneficialOwner = this.viewModel as BeneficialOwnerModel;

            const beneficialOwnerAllocationComponentId = this.parentFormFieldConfig.relationships[1];
            const beneficialOwnerAllocationListComponent = formBuilderService.getComponentByFormFieldConfigId(
              beneficialOwnerAllocationComponentId
            ) as ProportionListComponent;
            beneficialOwnerAllocationListComponent.dataSource.splice(
              beneficialOwnerAllocationListComponent.dataSource.findIndex((a: BeneficialOwnerModel) => a === beneficialOwner),
              1
            );

            beneficialOwnerAllocationListComponent.getTotal();

            const addBaneficialOwnerButtonComponentId = this.parentFormFieldConfig.relationships[0];

            const addButton = formBuilderService.getComponentByFormFieldConfigId(addBaneficialOwnerButtonComponentId) as ButtonComponent;

            const metadata = beneficialOwnerList.formFieldConfig.metadata as AgreementAnswerMetadata;

            if (metadata.max) {
              addButton.visibility = beneficialOwnerList.dataSource.length < metadata.max ? Visibility.visible : Visibility.hidden;
              addButton.formControl.markAsDirty();
            }

            this.ls.getService<SystemEventService>('systemEventService').publish(new VisibilityRefreshed());
            // remove controls from mapComponent
            this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfig(this.formFieldConfig, true);
            const children: FieldComponentMapItem[] = formBuilderService.getChildComponentsByFormFieldConfig(this.parentFormFieldConfig) || [];
            this.formFieldConfig.relationships.forEach(rel => {
              const target = children.filter(c => c.formFieldConfig.id === rel)[itemIndex];
              formBuilderService.deleteFieldComponentMapItemsByFormFieldConfig(target.formFieldConfig);
            });
          }
        });
      }
    }
  }
}
