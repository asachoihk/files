import { BaseAction, LocatorService, FormBuilderService, Visibility } from '@providers';
import { ButtonComponent } from '@shared/ui-elements';
import { TaskCardListComponent } from '@shared/components';

export class CheckAvailable extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any): void {
    if (params && params.maxBeneficiaryAllowed) {
      const maxBeneficiaryAllowed = params.maxBeneficiaryAllowed;
      let beneficiaryPersonsFieldId = '';
      if (this.formFieldConfig.relationships) {
        beneficiaryPersonsFieldId = this.formFieldConfig.relationships[0];
      } else if (this.parentFormFieldConfig) {
        beneficiaryPersonsFieldId = this.parentFormFieldConfig.id;
      } else {
        beneficiaryPersonsFieldId = this.formFieldConfig.id;
      }

      const beneficiaryPersons = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(beneficiaryPersonsFieldId) as TaskCardListComponent;
      const addNewMemberButtonFieldId = params.addNewMemberButtonFieldId || this.formFieldConfig.id;
      const btn = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(addNewMemberButtonFieldId) as ButtonComponent;

      const taskCardLength = (beneficiaryPersons.taskCardViewModels || []).filter(taskCard => !taskCard.isTaskCardInfo).length;

      const shouldShowBtn = taskCardLength >= maxBeneficiaryAllowed
        || (beneficiaryPersons.taskCardViewModels || []).some(b => !!b.isTaskCardInfo && ![Visibility.hidden, Visibility.collapsed].includes(b.visibility));
      if (shouldShowBtn) {
        btn.visibility = Visibility.collapsed;
      } else {
        btn.formControl.updateValueAndValidity();
        btn.visibility = Visibility.visible;
      }
    }
  }
}
