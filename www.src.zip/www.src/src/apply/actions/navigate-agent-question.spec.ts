import { NavigateAgentQuestion } from './navigate-agent-question';
import { LocatorService, GlobalNavigationService } from '@providers';
import { TestBed } from '@angular/core/testing';

class Action extends NavigateAgentQuestion {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'globalNavigationService') {
            return new MockGlobalNavigationService();
        }

    }
}

class MockGlobalNavigationService {
    navigateTo() {
        return;
    }
}

describe('NavigateAgentQuestion', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: GlobalNavigationService, useClass: MockGlobalNavigationService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
        spyOn(action.ls, 'getService').and.callThrough();
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});