import { Injectable } from '@angular/core';
import { LocatorService, ActionService, FormBuilderService, SystemEventService, BaseAction, DialogService, AppContextService, ErrorOccurred, DialogData } from '@providers';
import { DialogShellComponent } from '@shared/shells';
import { ButtonComponent, DataSourceComponent } from '@shared/ui-elements';
import { BeneficiaryModel } from '@apply/models';
import { BeneficiaryDialogComponent } from '@apply/pages';

@Injectable()
export class EditBeneficaryDialog extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any): void {
    const data = params.isOwner ? params.dataBeneficiary : (params.isEdit ? this.viewModel : new BeneficiaryModel());

    const dialogData = {
      viewModel: data,
      formFieldConfig: this.parentFormFieldConfig,
      params: {
        header: params.titleBeneficiary
      }
    };

    this.ls.getService<DialogService>('dialogService')
      .showFormBuilderDialog(BeneficiaryDialogComponent, DialogShellComponent, dialogData, (result: BeneficiaryModel) => {
        if (result) {
          const currentFormBuilder = this.ls.getService<AppContextService>('appContextService').currentFormBuilder;
          currentFormBuilder.refreshData(() => {
            const relationships = this.formFieldConfig.relationships || this.parentFormFieldConfig.relationships;

            if (relationships) {
              relationships.forEach(fieldId => {
                const component = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(fieldId) as DataSourceComponent;
                component.loadDataSource();
              });
            }

            const actionParams = this.ls.getService<ActionService>('actionService').createActionParams(this, params);
            this.ls.getAction('checkAvailable').invoke(actionParams);
            const btAdd = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('btn-add') as ButtonComponent;
            btAdd.formControl.updateValueAndValidity();
          });
        }
        const removeErrorOccurred = new ErrorOccurred('');
        this.ls.getService<SystemEventService>('systemEventService').publish(removeErrorOccurred);
      });
  }
}
