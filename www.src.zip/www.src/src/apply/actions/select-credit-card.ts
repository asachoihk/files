import { BaseAction, LocatorService, DialogService, ActionService } from '@providers';
import { DialogShellComponent } from '@shared/shells';
import { ChangePaymentMethodComponent } from '@shared/components';

export class SelectCreditCard extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(_params?: any) {
    const actionData = this.ls.getService<ActionService>('actionService').createActionParams(this);
    actionData.width = '720px';
    actionData.height = '535px';
    this.ls.getService<DialogService>('dialogService').showFormBuilderDialog(ChangePaymentMethodComponent, DialogShellComponent, actionData, (_result: any) => { });
  }
}
