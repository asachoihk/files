import { LocatorService, FormBuilderService, BaseAction } from '@providers';
import * as _ from 'lodash';
import { FilterListViewPipe } from '@shared/pipes';
import { ApplicationService } from '@apply/services';
import { map } from 'rxjs/operators';
import { ApplyServiceNames } from '@apply/const';

export class GetAgentApplications extends BaseAction {
	constructor(protected ls: LocatorService) {
		super(ls);
	}

	execute(params: any) {
		let applicationList = [];
		if (params && params.keywords !== undefined) {
			applicationList = _.cloneDeepWith(params.data);
			applicationList = applicationList = new FilterListViewPipe().transform(params.data, params.keywords, this.formFieldConfig.dataSource.params.filerByColumns);

			this.ls.getService<FormBuilderService>('formBuilderService').notifyDependentFieldChanged(this.formFieldConfig, { 'number': applicationList.length, 'total': params.data.length });
			return applicationList;
		} else {
			return this.ls.getService<ApplicationService>(ApplyServiceNames.applicationService).getAgentApplicationsHeader(!!params.keywords).pipe(map(
				data => {
					if (data && Array.isArray(data)) {
						applicationList = [];
						data.forEach(element => {
							applicationList.push(element);
						});
						if (this.formFieldConfig.dataSource.params.columnSortDefault.isAscending) {
							applicationList = _.sortBy(applicationList, this.formFieldConfig.dataSource.params.columnSortDefault.columnName);
						} else {
							applicationList = _.sortBy(applicationList, this.formFieldConfig.dataSource.params.columnSortDefault.columnName).reverse();
						}
						this.ls.getService<FormBuilderService>('formBuilderService').notifyDependentFieldChanged(this.formFieldConfig, { 'number': applicationList.length, 'total': applicationList.length });
						return applicationList;
					}
				}));
		}
	}
}
