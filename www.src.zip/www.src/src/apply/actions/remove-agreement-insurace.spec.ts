import { RemoveAgreementInsurace } from './remove-agreement-insurace';
import { LocatorService, FormBuilderService, DialogService, SystemEventService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { TranslationService } from 'angular-l10n';

class Action extends RemoveAgreementInsurace {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

        if (serviceName === 'systemEventService') {
            return new MockSystemEventService();
        }

        if (serviceName === 'dialogService') {
            return new MockDialogService();
        }

    }

    get() {
        return new MockTranslationService();
    }
}

class MockFormBuilderService {
    viewModel = {
        relationships: [
            'abc',
            'xyz'
        ]
    };
    getComponentByFormFieldConfigId() {
        return {
            dataSource: [this.viewModel, {}],
            visibility: 'visible',
            formControl: {
                markAsDirty() {
                    return;
                }
            }
        };
    }

    setBindingData() {
        return {};
    }

    deleteFieldComponentMapItemsByFormFieldConfig() {
        return {};
    }

    getChildComponentsByFormFieldConfig() {
        return [
            {
                formFieldConfig: {
                    id: 'abc'
                }
            }
        ];
    }
}

class MockDialogService {
    showCustomDialog(CustomDialogComponent, dialogConfig, callback) {
        return callback({
            action: 'yes'
        });
    }
}

class MockSystemEventService {
    publish() {
        return;
    }
}

class MockTranslationService {
    translate() {
        return 'translated text';
    }
}

describe('RemoveAgreementInsurace', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService },
                { provide: DialogService, useClass: MockDialogService },
                { provide: SystemEventService, useClass: MockSystemEventService },
                { provide: TranslationService, useClass: MockTranslationService },

            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {

            const viewModel = {
                relationships: [
                    'abc'
                ]
            };
            const params = {
                addBtnFieldId: 'abc'
            };
            action.parentViewModel = {} as any;
            action.parentFormFieldConfig = {
                id: 'abc',
                dataBinding: {
                    path: 'abc'
                }
            } as any;
            action.formFieldConfig = viewModel as any;

            action.viewModel = viewModel as any;
            spyOn(action.ls, 'getService').and.returnValue({

                getComponentByFormFieldConfigId() {
                    return {
                        dataSource: [action.viewModel, {}],
                        visibility: 'visible',
                        formControl: {
                            markAsDirty() {
                                return;
                            }
                        }
                    };
                },
                setBindingData() {
                    return {};
                },
                deleteFieldComponentMapItemsByFormFieldConfig() {
                    return {};
                },
                getChildComponentsByFormFieldConfig() {
                    return [
                        {
                            formFieldConfig: {
                                id: 'abc'
                            }
                        }
                    ];
                },
                showCustomDialog(CustomDialogComponent, dialogConfig, callback) {
                    return callback({
                        action: 'yes'
                    });
                },
                publish() {
                    return;
                },
                translate() {
                    return 'translated text';
                }
            });
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});
