import { GetPaymentMethod } from './get-payment-method';
import { LocatorService, JsonConfigService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { PaymentService } from '@apply/services';
import { ApplyModel, PaymentModel } from '@apply/models';
import { PaymentMethod } from '@apply/enums';

class Action extends GetPaymentMethod {
  viewModel: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockJsonConfigService {
  getInitialPaymentMethod() {
    return [
      {
        label: 'Cash',
        value: 'CASH'
      },
      {
        label: 'Bank Transfer',
        value: 'BT'
      },
      {
        label: 'POS Payment',
        value: 'POS'
      },
      {
        label: 'Online Payment',
        value: 'ONLINE'
      }
    ];
  }
}

class MockPaymentService {
  calculateInitialPayment(totalPayment, method) {
    return 45000;
  }
}

class MockLocatorService {
  getService() {
    return new MockJsonConfigService();
  }
  get() {
    return new MockPaymentService();
  }
}

describe('Get payment method', () => {
  let action: Action;
  let params: any;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: PaymentService, useClass: MockPaymentService },
        { provide: JsonConfigService, useClass: MockJsonConfigService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      action.viewModel = new ApplyModel();
      action.viewModel.totalPayment = {
        annual: 123,
        currency: 'qd',
        monthly: 123,
        semi: 123,
        single: 123,
        quarterly: 123
      };
      action.viewModel.payment = new PaymentModel();
      action.viewModel.payment.method = PaymentMethod.CASH;
      params = {
        exclude: ['ONLINE'],
        cashPaymentLimit: 40000
      };
      expect(action.execute(params));
    });

    it('should be run', () => {
      action.viewModel = new ApplyModel();
      action.viewModel.totalPayment = {
        annual: 123,
        currency: 'qd',
        monthly: 123,
        semi: 123,
        single: 123,
        quarterly: 123
      };
      action.viewModel.payment = new PaymentModel();
      action.viewModel.payment.method = PaymentMethod.CASH;
      params = {
        cashPaymentLimit: 50000
      };
      expect(action.execute(params));
    });
  });
})