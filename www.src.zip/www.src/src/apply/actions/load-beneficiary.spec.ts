import { LoadBeneficiary } from './load-beneficiary';
import { LocatorService } from '@providers';
import { TestBed } from '@angular/core/testing';

class Action extends LoadBeneficiary {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {

}

describe('LoadBeneficiary', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            const parentViewModel = {};
            action.parentViewModel = parentViewModel as any;
            expect(action.execute()).toBeDefined();
        });
    });
});