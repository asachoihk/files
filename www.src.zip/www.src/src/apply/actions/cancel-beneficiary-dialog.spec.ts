import { TestBed } from '@angular/core/testing';

import { CancelBeneficiaryDialog } from './cancel-beneficiary-dialog';
import { LocatorService, DialogService, CustomDialogActionType } from '@providers';
import { TranslationService } from 'angular-l10n';
import { CustomDialogComponent } from '@shared/ui-elements';
import { MatDialogRef } from '@angular/material/dialog';
import { Observable, of } from 'rxjs';
import 'rxjs/add/observable/of';

class Action extends CancelBeneficiaryDialog {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    constructor() { }
    getService() {
        return new MockDialogService();
    }

    get() {
        return new MockTranslationService();
    }
}

class MockTranslationService {
    translate() {
        return 'translate text';
    }
}

class MockDialogService {
    open() {
        return { afterClosed: () => Observable.of({}) };
    }

    close() {
        return true;
    }


    showCustomDialog(component, dialogConfig, callback) {
        return callback({
            action: 'yes'
        });
    }
}

class MockMatDialogRef {

    open() {
        return { afterClosed: () => Observable.of({}) };
    }

    close() {
        return true;
    }
}

describe('CancelBeneficiaryDialog', () => {
    let action: Action;
    let ls;
    let translationService;
    let dialog;

    beforeEach(() => {

        TestBed.configureTestingModule({

            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: TranslationService, useClass: MockTranslationService },
                { provide: DialogService, useClass: MockDialogService },
                { provide: MatDialogRef, useClass: MockMatDialogRef },
            ],

        });
        ls = TestBed.get(LocatorService);
        dialog = TestBed.get(MatDialogRef);
    });

    beforeEach(() => {
        action = new Action(ls);
        action.dialogRef = dialog;
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            expect(action.execute());
        });
    });
});
