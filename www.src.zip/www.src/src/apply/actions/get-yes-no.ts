import { LocatorService, BaseAction } from '@providers';

export class GetYesNo extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(_params: any) {
    const data = [
      {
        label: 'Yes',
        value: 'Yes'
      },
      {
        label: 'No',
        value: 'No'
      }
    ];
    return data;
  }
}
