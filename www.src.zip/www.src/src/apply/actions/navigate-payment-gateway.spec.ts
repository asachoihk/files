import { NavigatePaymentGateway } from './navigate-payment-gateway';
import { LocatorService, ActionService, SystemEventService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { ApplyModel } from '@apply/models';

class Action extends NavigatePaymentGateway {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {

        if (serviceName === 'actionService') {
            return new MockActionService();
        }

        if (serviceName === 'systemEventService') {
            return new MockSystemEventService();
        }

    }
}

class MockActionService {
    executeAction(a, b, c, callback) {
        return callback({});
    }
}

class MockSystemEventService {
    publish() {
        return {};
    }
}

describe('NavigatePaymentGateway', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ActionService, useClass: MockActionService },
                { provide: SystemEventService, useClass: MockSystemEventService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run - applyModel.status === APPLICATION_STATUS.PAYMENT_PENDING', () => {
            const model = {
                declaration_answer: {
                    agent_answer: 'abc'
                },
                status: 'PAYMENT_PENDING'
            } as ApplyModel;
            action.viewModel = model;
            expect(action.execute().subscribe()).toBeTruthy();
        });

        it('should be run - applyModel.status !== APPLICATION_STATUS.PAYMENT_PENDING', () => {
            const model = {
                declaration_answer: {
                    agent_answer: 'PAYMENTONLINEFAILED',
                    agent_question: 'Y'
                },
                status: 'SUBMISSION_CONFIRMED'
            } as ApplyModel;
            action.viewModel = model;
            expect(action.execute().subscribe()).toBeTruthy();
        });
    });

});