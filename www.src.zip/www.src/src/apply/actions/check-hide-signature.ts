import { BaseAction, LocatorService, Visibility } from '@providers';
import { ApplicationService } from '@apply/services';

export class CheckHideSignature extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    return this.ls.getService<ApplicationService>('applicationService').isHideSignature() ? Visibility.hidden : Visibility.visible;
  }
}
