import { LocatorService, FormBuilderService, AppContextService, SystemEventService, ViewMode } from '@providers';
import { of } from 'rxjs';
import { TestBed } from '@angular/core/testing';
import { CheckReviewButtonStatus } from './check-review-button-status';
import { ApplicationService } from '@apply/services';
import { ApplyModel } from '@apply/models';

class Action extends CheckReviewButtonStatus {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'appContextService') {
            return new MockAppContextService();
        }

        if (serviceName === 'systemEventService') {
            return new MockSystemEventService();
        }

        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

        if (serviceName === 'applicationService') {
            return new MockApplicationService();
        }
    }
}

class MockSystemEventService {
    publish() {
        return of({});
    }
}

class MockAppContextService {
    appContext = {
        viewMode: 'status',
        stepper: {
            steps: [
                {
                    status: 'completed'
                }
            ]
        }
    };

    currentFormBuilder = {
        viewModel: {
            payment: {
                mode: 'annual',
                method: 'cash',
                renewalMethod: 'string',
                documents: [],
                onlinePaymentMethod: 'abc'
            }
        }
    };

}

class MockApplicationService {

    isApplicationReadOnlyMode() {
        return;
    }
}

class MockFormBuilderService {
    constructor() { }

    getBindingData() {
        return 'text';
    }
}

describe('CheckReviewButtonStatus', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: AppContextService, useClass: MockAppContextService },
                { provide: SystemEventService, useClass: MockSystemEventService },
                { provide: FormBuilderService, useClass: MockFormBuilderService },
                { provide: ApplicationService, useClass: MockApplicationService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run - params.mode !== ViewMode[currentMode]', () => {
            const params = {
                mode: {
                    CONVERTED: 'converted',
                    DRAFT: 'draft',
                    EXPIRED: 'expired',
                    FINAL: 'final',
                },
                requiredFields: 'abc'
            };
            expect(action.execute(params)).toEqual('hidden');
        });

        it('should be run - params.mode === ViewMode[currentMode] - application readonly mode === true', () => {
            const params = {
                mode: 'normal',
                requiredFields: undefined
            };
            spyOn(action.ls, 'getService').and.returnValue({
                isApplicationReadOnlyMode() {
                    return true;
                },

                currentFormBuilder() {
                    return {
                        viewModel: undefined
                    };
                },
                appContext() {
                    return {
                        viewMode: 'status',
                    };
                }
            });

            const model = {
            };

            action.viewModel = model as ApplyModel;
            expect(action.execute(params)).toEqual('hidden');
        });

        it('should be run - params.mode === ViewMode[currentMode] - application readonly mode !== true', () => {
            const params = {
                mode: 'normal',
                requiredFields: undefined
            };
            spyOn(action.ls, 'getService').and.returnValue(
                {
                    isApplicationReadOnlyMode() {
                        return false;
                    },

                    currentFormBuilder() {
                        return {
                            viewModel: undefined
                        };
                    },
                    publish() {
                        return of({});
                    },
                    appContext: {
                        viewMode: 'normal',
                        stepper: {
                            steps: [
                                {
                                    status: 'completed'
                                }
                            ]
                        }
                    }
                });

            action.viewModel = new ApplyModel();
            expect(action.execute(params)).toEqual('hidden');
        });
    });

    it('should be run - params.mode === ViewMode[currentMode] - application readonly mode !== true - stepper === undefined', () => {
        const params = {
            mode: 'normal',
            requiredFields: null
        };

        spyOn(action.ls, 'getService').and.returnValue({
            isApplicationReadOnlyMode() {
                return false;
            },
            currentFormBuilder: {
                viewModel: new ApplyModel()
            },
            appContext: {
                viewMode: undefined
            }
        });

        action.viewModel = {
            payment: {}
        } as ApplyModel;
        expect(action.execute(params)).toEqual('visible');
    });

    it('should be run - params.mode === ViewMode[currentMode] - application readonly mode !== true - stepper === undefined', () => {
        const params = {
            mode: 'normal',
            requiredFields: ['abc', 'xyz']
        };

        spyOn(action.ls, 'getService').and.returnValue({
            isApplicationReadOnlyMode() {
                return false;
            },
            currentFormBuilder: {
                viewModel: {
                    payment: {
                        mode: 'annual',
                        method: 'cash',
                        renewalMethod: 'string',
                        documents: [],
                        onlinePaymentMethod: 'abc'
                    }
                }
            },
            appContext: {
                viewMode: undefined
            },
            getBindingData() {
                return 'text';
            },
            publish() {
                return of({});
            }
        });

        action.viewModel = {

        } as ApplyModel;
        expect(action.execute(params)).toEqual('hidden');
    });
});
