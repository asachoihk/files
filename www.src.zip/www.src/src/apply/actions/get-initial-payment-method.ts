import { LocatorService, JsonConfigService, BaseAction } from '@providers';

export class GetInitialPaymentMode extends BaseAction {
    constructor(protected ls: LocatorService) {
      super(ls);
    }

    execute(_params: any) {
      return this.ls.getService<JsonConfigService>('jsonConfigService').getInitialPaymentMethod();

    }
  }
