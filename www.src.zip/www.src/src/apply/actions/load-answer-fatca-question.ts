import { BaseAction, LocatorService, FormBuilderService } from '@providers';
import { QuestionairePanelComponent } from '@shared/ui-elements';
import { InsuredModel } from '@apply/models';

export class LoadAnswerFatcaQuestion extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    const answerConfigured = params.answer;
    const viewModel = this.viewModel as InsuredModel;
    viewModel.agreement.requireFatca = false;
    const answer = viewModel.agreement.anwserFatca;
    const questionairePanel = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as QuestionairePanelComponent;

    const citizenship = viewModel.person.basicInfo.citizenship ? viewModel.person.basicInfo.citizenship === 'US' : false;

    if (answerConfigured === answer) {
      if (citizenship) {
        this.showFatcaW9(questionairePanel, true);
      }
      this.showFatcaW8(questionairePanel, !citizenship);
    } else if (answer) {
      this.showFatcaW9(questionairePanel, true);
    } else if (citizenship) {
      this.showFatcaW9(questionairePanel, true);
    }
  }

  showFatcaW8(questionairePanel, isDelete = true) {
    const viewModel = this.viewModel as InsuredModel;
    viewModel.agreement.requireFatca = true;
    if (isDelete) {
      questionairePanel.reset();
    }
    questionairePanel.loadAnswerComponent('fatcaForm', { viewModel: viewModel, parentFormFieldConfig: this.parentFormFieldConfig });
  }

  showFatcaW9(questionairePanel, isDelete = true) {
    const viewModel = this.viewModel as InsuredModel;
    viewModel.agreement.requireFatca = true;
    if (isDelete) {
      questionairePanel.reset();
    }
    questionairePanel.loadAnswerComponent('fatcaW9Form', { viewModel: viewModel, parentFormFieldConfig: this.parentFormFieldConfig });
  }
}
