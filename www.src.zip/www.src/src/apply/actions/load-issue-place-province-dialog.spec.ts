import { LocatorService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { TranslationService } from 'angular-l10n';
import { LoadIssuePlaceProvinceDialog } from './load-issue-place-province-dialog';

class Action extends LoadIssuePlaceProvinceDialog {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    get() {
        return new MockTranslationService();
    }
}

class MockTranslationService {
    translate() {
        return 'translated text';
    }
}

describe('LoadIssuePlaceProvinceDialog', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: TranslationService, useClass: MockTranslationService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - getDialogData', () => {
        it('should be run', () => {
            action.viewModel = {} as any;
            action.parentFormFieldConfig = {} as any;
            action.formFieldConfig = {
                dataSourceMetadata: {},
                label: 'text'
            } as any;
            expect(action.getDialogData()).toEqual({
                viewModel: action.viewModel,
                formFieldConfig: action.parentFormFieldConfig,
                params: {
                    componentParams: {
                        header: 'Search province',
                        dataSource: {
                            actionName: 'getProvinces'
                        },
                        dataSourceMetadata: action.formFieldConfig.dataSourceMetadata
                    },
                    header: action.formFieldConfig.label
                }
            });
        });
    });

    describe('Function - getKeyName', () => {
        it('should be run', () => {
            action.viewModel = {} as any;
            action.parentFormFieldConfig = {} as any;
            action.formFieldConfig = {
                dataSourceMetadata: {},
                label: ''
            } as any;
            expect(action.getKeyName()).toEqual('value');
        });
    });
});