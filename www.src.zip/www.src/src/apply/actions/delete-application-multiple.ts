import { LocatorService, CustomDialogActionType, DialogService, CustomDialogResult, FormBuilderService, BaseAction, CustomerService, SystemEventService, APPLICATION_STATUS } from '@providers';
import { TranslationService } from 'angular-l10n';
import { CustomDialogComponent, SearchBarComponent, TableComponent } from '@shared/ui-elements';
import { ApplicationService } from '@apply/services';
import { map } from 'rxjs/operators';

export class DeleteApplicationMultiple extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const viewModel = this.viewModel as any;
    if (viewModel && viewModel.selected) {
      const applicationIds = viewModel.selected.filter(app => app.applicationId && this.checkStatus(app.status)).map(app => app['applicationId']);
      const dialogConfig = {
        disableClose: true,
        data: {
          message: this.ls.get(TranslationService).translate('MSGA058'),
          buttons: [
            { title: 'no', type: 'red-outline', action: CustomDialogActionType.no },
            { title: 'yes', type: 'red', action: CustomDialogActionType.yes }
          ]
        }
      };
      this.ls.getService<DialogService>('dialogService').showCustomDialog(CustomDialogComponent, dialogConfig, (result: CustomDialogResult) => {
        if (result.action === CustomDialogActionType.yes) {
          const customerId = this.ls.getService<CustomerService>('customerService').getCurrent().customerId;
          this.ls.getService<ApplicationService>('applicationService').deleteApplication(customerId, applicationIds).subscribe(
            () => {
              this.ls.getService<SystemEventService>('systemEventService').tempEventDeleteMultiCustomer.next(false);
              const searchComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('searchBar') as SearchBarComponent;
              const tableComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as TableComponent;
              if (tableComponent && searchComponent) {
                tableComponent.loadDataSource(searchComponent.textSearch, applicationIds);
              }
            },
            error => {
              console.log(`can't delete application with error: ${error}`);
            });
        }
      });
    }
  }

  private checkStatus(status) {
    return status === APPLICATION_STATUS.INPROGRESS || status === APPLICATION_STATUS.EXPIRED;
  }
}
