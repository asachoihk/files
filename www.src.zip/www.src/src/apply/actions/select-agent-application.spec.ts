import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { ActivatedRoute } from '@angular/router';
import { SelectAgentApplication } from './select-agent-application';

class Action extends SelectAgentApplication {
    constructor(public ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    constructor() {}
    getService() {
        return null;
    }
}

describe('SelectAgentApplication', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getById() {
                    return [
                        {
                            customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab'
                        }
                    ];
                },
                getApplication() {
                    return [{
                        applicationId: '18072433-c834-755a-9372-6826ef99f9fb'
                    }];
                },
                transformCustomerData2UI() {
                    return {

                    };
                },
                setCurrent() {
                    return;
                },
                navigateTo() {
                    return '';
                }
            });
            const params = {
                applicationId: '18072433-c834-755a-9372-6826ef99f9fb',
                customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab',
                status: 'SUBMITTED'
            };
            action.execute(params).subscribe(res => {
                expect(res).toBeFalsy();
            });
        });

        it('should be return with status = DEFAULT', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getById() {
                    return [
                        {
                            customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab'
                        }
                    ];
                },
                getApplication() {
                    return [{
                        applicationId: '18072433-c834-755a-9372-6826ef99f9fb'
                    }];
                },
                transformCustomerData2UI() {
                    return {

                    };
                },
                setCurrent() {
                    return;
                },
                navigateTo() {
                    return '';
                }
            });
            const params = {
                applicationId: '18072433-c834-755a-9372-6826ef99f9fb',
                customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab',
                status: 'DEFAULT'
            };
            action.execute(params).subscribe(res => {
                expect(res).toBeFalsy();
            });
        });
    });
});
