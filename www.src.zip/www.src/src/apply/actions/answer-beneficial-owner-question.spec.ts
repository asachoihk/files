import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { FormBuilderService } from 'providers/services/form-builder/form-builder.service';
import { InsuredModel } from '@apply/models';
import { AnswerBeneficialOwnerQuestion, LoadAnswerBeneficialOwnerQuestion } from './answer-beneficial-owner-question';

class ActionAnswer extends AnswerBeneficialOwnerQuestion {
    constructor(protected ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    get(): MockFormBuilderService {
        return new MockFormBuilderService();
    }

    getService(serviceName: string): any {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }
        return new MockActionService();
    }
}

class MockActionService {
    createActionParams() {
        return {};
    }
}

class MockFormBuilderService {
    constructor() { }
    get() {
        return null;
    }

    getComponentByFormFieldConfigId() {
        return {
            formFieldConfig: {
                metadata: {
                    max: 3
                },
                dataBinding: {
                    path: 'agreement.insurance'
                }
            },
            dataSource: [{
                beneficialNumber: 'Beneficial Owner 1',
                dateOfBirth: undefined,
                firstName: undefined,
                guid: 'a03a1196-441f-4fc6-ad82-7219ea02fd11',
                lastName: undefined,
                middleName: undefined,
                percentageOfShare: undefined,
                valueChanges: null,
                _guid: 'a03a1196-441f-4fc6-ad82-7219ea02fd11'
            }]
        };
    }

    setBindingData() {
        return null;
    }


    getComponentByFormFieldConfig() {
        return {
            loadAnswerComponent() {
                return null;
            },
            reset() {
                return null;
            }
        };
    }


    deleteFieldComponentMapItemsByFormFieldConfigId() {
        return null;
    }

    deleteFieldComponentMapItemsByParentFormFieldConfigId() {
        return null;
    }
}

describe('AnswerBeneficialOwnerQuestion', () => {
    let action: ActionAnswer;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new ActionAnswer(ls);
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        const params = {
            answer: 'Y',
        };
        it('should be run with answer = "Y"', () => {
            action.$event = {
                value: 'Y'
            };
            action.viewModel = new InsuredModel();
            expect(action.execute(params)).toBeFalsy();
        });
        it('should be run with answer = "N"', () => {
            params.answer = 'N';
            action.$event = {
                value: 'Y'
            };
            action.viewModel = new InsuredModel();
            expect(action.execute(params)).toBeFalsy();
        });
    });
});

class ActionLoadAnswer extends LoadAnswerBeneficialOwnerQuestion {
    constructor(protected ls: LocatorService) {
        super(ls);
    }
}

describe('LoadAnswerBeneficialOwnerQuestion', () => {
    let action: ActionLoadAnswer;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new ActionLoadAnswer(ls);
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            action.viewModel = new InsuredModel();
            expect(action.execute({answer: 'Y'})).toBeFalsy();
        });
    });
});

