import { BaseAction, LocatorService, GlobalNavigationService, ActionService } from '@providers';
import { Observable } from 'rxjs';

export class ResubmitApplication extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(): Observable<any> {
        return new Observable(subscriber => {
            const data = this.ls.getService<GlobalNavigationService>('globalNavigationService').getPreviousPageData();
            this.ls.getService<ActionService>('actionService').executeAction(data.previousAction, data.context, null, () => {
                subscriber.next();
            });
        });
    }

}
