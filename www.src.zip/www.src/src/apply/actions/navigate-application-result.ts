import { LocatorService, CustomerService, SaveAction, APPLICATION_STATUS } from '@providers';
import { ActivatedRoute } from '@angular/router';
import { Observable, Subscriber } from 'rxjs';
import { ApplicationService, SaveDocumentsService } from '@apply/services';
import { ApplyModel, TransactionResultData } from '@apply/models';
import { ApplySection } from '@apply/const';

export class NavigateApplicationResult extends SaveAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any): Observable<any> {
    return new Observable<any>(subscriber => {
      const customerId = this.ls.get(ActivatedRoute).snapshot.queryParams.customerId || this.ls.getService<CustomerService>('customerService').getCurrent().customerId;
      const applyData = this.viewModel as ApplyModel;
      if (params.applicationStatus === APPLICATION_STATUS.PAYMENT_PENDING) {
        applyData.payment.method = null;
      }
      if (params.saveDocumentInsured) {
        this.ls.getService<SaveDocumentsService>('saveDocumentsService').saveDocumentInsured(applyData.payment).subscribe(response => {
          if (response && response.uploadFileSuccess) {
            if (response.insuredPerson && response.insuredPerson.documents) {
              applyData.payment.documents = response.insuredPerson.documents;
              this.saveApplication(applyData, customerId, params, subscriber);
            }
          }
        });
      } else {
        this.saveApplication(applyData, customerId, params, subscriber);
      }
    });
  }

  ignoreValidationResult() {
    return true;
  }

  saveApplication(applyData: ApplyModel, customerId: string, params: any, subscriber: Subscriber<any>) {
    applyData.status = params.applicationStatus;
    if (applyData.status === APPLICATION_STATUS.SUBMITTED) {
      applyData.policyNumber = this.getPolicyNumber();
      applyData.paymentResult = applyData.paymentResult || new TransactionResultData();
      applyData.paymentResult.RECEIPT_NUM = '3AG152568DFUVB689';
      const submissionSection = applyData.progress.sections.find(s => s.name === ApplySection.SUBMISSION.toString());
      submissionSection.progress = 100;
    }

    this.ls
      .getService<ApplicationService>('applicationService')
      .saveApplyData(customerId, [applyData])
      .subscribe(result => {
        if (this.dialogRef) {
          this.dialogRef.close();
        }
        this.ls.getAction('checkData').invoke(null);
        subscriber.next(result);
      });
  }

  getPolicyNumber() {
    const min = Math.ceil(999);
    const max = Math.floor(9999);
    const randomNuber = Math.floor(Math.random() * (max - min + 1)) + min;

    return randomNuber + ' 1234 56';
  }
}
