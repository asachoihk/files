import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { CheckDefaultId } from './check-default-id';


class Action extends CheckDefaultId {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }

    getService() {
        return new MockFormBuilderService();
    }
}

class MockFormBuilderService {
    getComponentByFormFieldConfig() {
       return {
        visibility: 'hidden'
       };
    }
    getComponentByFormFieldConfigId() {
        return {
            formFieldConfig: {
                metadata: {
                    max: 3
                },
                dataBinding: '/'
            },
            dataSource: [{
                beneficialNumber: 'Beneficial Owner 1',
                dateOfBirth: undefined,
                firstName: undefined,
                guid: 'a03a1196-441f-4fc6-ad82-7219ea02fd11',
                lastName: undefined,
                middleName: undefined,
                percentageOfShare: undefined,
                valueChanges: null,
                _guid: 'a03a1196-441f-4fc6-ad82-7219ea02fd11'
            }]
        };
    }
    setBindingData() {
        return null;
    }
    getBindingData() {
        return null;
    }
    notifyDependentFieldChanged() {
        return null;
    }
}

describe('CheckDefaultId', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        const params = {
            identityTypeField: 'id',
            default: 'test'
        };
        it('should be run', () => {
            expect(action.execute(params)).toBeFalsy();
        });
    });
});
