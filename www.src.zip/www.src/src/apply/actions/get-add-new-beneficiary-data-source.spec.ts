import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { GetAddNewBeneficiaryDataSource } from './get-add-new-beneficiary-data-source';

class Action extends GetAddNewBeneficiaryDataSource {
    constructor(public ls: LocatorService) {
      super(ls);
    }
  }

  class MockLocatorService {
    constructor() {
    }
  }

describe('GetAddNewBeneficiaryDataSource', () => {
    let action: Action;
    let ls: LocatorService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
      });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            expect(action.execute().title).toEqual('Add beneficiary');
            expect(action.execute().type).toEqual('beneficiary');
        });
    });
});
