import { LocatorService, BaseAction } from '@providers';
import { ActivatedRoute } from '@angular/router';
import { ApplyModel } from '@apply/models';
import { ApplicationService } from '@apply/services';

export class GetAgentQuestion extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const router = this.ls.get(ActivatedRoute);
    const appId = router.snapshot.queryParams.applicationId;
    const applyData = this.ls.getService<ApplicationService>('applicationService').getApplyData(appId) as ApplyModel;

    return applyData.declaration_answer;
  }
}
