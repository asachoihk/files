
import { TestBed } from '@angular/core/testing';

import { LocatorService, FormatterService, FormBuilderService } from '@providers';
import { GetInitialPayment } from './get-initial-payment';
import { PaymentService } from '@apply/services';
import { ApplyModel, PaymentModel } from '@apply/models';
import { PaymentMode } from '@apply/enums/payment-mode.enum';

class Action extends GetInitialPayment {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}
class MockFormatterService {
  constructor() { }

  formatCurrency() {
    return '28,836';
  }
}

class MockFormBuilderService {
  constructor() { }

  setFormFieldValue(viewModel, formFieldConfig, value) {

  }
}

class MockPaymentService {
  constructor() { }
  calculateInitialPayment(premium, paymentMethod) {
    return 28836;
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formatterService':
        return new MockFormatterService();
      case 'formBuilderService':
        return new MockFormBuilderService();
      default:
        break;
    }
  }
  get() {
    return new MockPaymentService();
  }
}

describe('GetInitialPayment', () => {
  let action: Action;
  let ls: LocatorService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormatterService, useClass: MockFormatterService },
        { provide: PaymentService, useClass: MockPaymentService },
        { provide: FormBuilderService, useClass: MockFormBuilderService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run with PHP', () => {
      action.viewModel = new ApplyModel();
      const applyModel = new ApplyModel();
      applyModel.totalPayment.annual = 57670;
      applyModel.totalPayment.monthly = 4806;
      applyModel.totalPayment.quarterly = 14418;
      applyModel.totalPayment.semi = 28835;
      applyModel.payment = new PaymentModel();
      applyModel.payment.mode = PaymentMode.quarterly;
      applyModel.currency = 'PHP';
      action.viewModel = applyModel;
      expect(action.execute());
    });

    it('should be run with VND', () => {
      action.viewModel = new ApplyModel();
      const applyModel = new ApplyModel();
      applyModel.totalPayment.annual = 57670;
      applyModel.totalPayment.monthly = 4806;
      applyModel.totalPayment.quarterly = 14418;
      applyModel.totalPayment.semi = 28835;
      applyModel.payment = new PaymentModel();
      applyModel.payment.mode = PaymentMode.quarterly;
      applyModel.currency = 'VND';
      action.viewModel = applyModel;
      expect(action.execute());
    });
  });
});
