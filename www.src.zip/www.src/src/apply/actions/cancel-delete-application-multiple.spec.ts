import { TestBed } from '@angular/core/testing';
import { LocatorService, SystemEventService, FormBuilderService } from '@providers';
import { Subject } from 'rxjs';
import { CancelDeleteApplicationMultiple } from './cancel-delete-application-multiple';

class Action extends CancelDeleteApplicationMultiple {
    constructor(protected ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'systemEventService') {
            return new MockSystemEventService();
        }

        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }
    }

}

class MockSystemEventService {
    tempEventDeleteMultiCustomer = new Subject<any>();
}

class MockFormBuilderService {
    constructor() { }
    get() {
        return null;
    }

    getComponentByFormFieldConfigId(configId: string) {
        if (configId === 'applications') {
            return {
                loadDataSource() {
                    return null;
                }
            };
        }

        if (configId === 'searchBar') {
            return {};
        }

    }
    setBindingData() {
        return null;
    }

}

describe('CancelDeleteApplicationMultiple', () => {
    let action: Action;
    let ls;

    beforeEach(() => {

        TestBed.configureTestingModule({

            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: SystemEventService, useClass: MockSystemEventService },
                { provide: FormBuilderService, useClass: MockFormBuilderService },
            ],

        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        const params = {
            applicationsFieldId: 'applications',
        };
        it('should be run', () => {
            expect(action.execute(params));
        });
    });
});
