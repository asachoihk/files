import { GetOwner } from './get-owner';
import { LocatorService } from '@providers';
import { ApplyModel } from '@apply/models';
import { TestBed } from '@angular/core/testing';
import { ApplicationService, InsuredPersonService } from '@apply/services';

class Action extends GetOwner {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockApplicationService {
  appId: any;
  constructor() { }

  getCurrentApplyData() {
    return {};
  }
}

class MockInsuredPersonService {
  applyData: ApplyModel;
  constructor() { }

  getInsuredPersons(applyData) {
    return [
      {
        type: 'o',
        person: {
          basicInfo: {
            firstName: 'Tang',
            middleName: '',
            lastName: 'Hao'
          }
        }
      }
    ];
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'applicationService':
        return new MockApplicationService();
      case 'insuredPersonService':
        return new MockInsuredPersonService();
      default:
        break;
    }
  }
}

describe('Get Owner', () => {
  let ls: LocatorService;
  let action: Action;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: ApplicationService, useClass: MockApplicationService },
        { provide: InsuredPersonService, useClass: MockInsuredPersonService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      expect(action.execute());
    });
  });

  describe('Function - Excute - Fullname', () => {
    it('should be run', () => {
      spyOn( action.ls, 'getService').and.returnValue({
        getInsuredPersons(applyData) {
          return [
            {
              type: 'o',
              person: {
                basicInfo: {
                  firstName: 'Tang',
                  middleName: '',
                  lastName: 'Hao',
                  fullName: 'An'
                }
              }
            }
          ];
        },
        getCurrentApplyData() {
          return {};
        }
      });
      expect(action.execute());
    });
  });

  describe('Function - Excute - Ownernull', () => {
    it('should be run', () => {
      spyOn( action.ls, 'getService').and.returnValue({
        getInsuredPersons(applyData) {
          return [];
        },
        getCurrentApplyData() {
          return {};
        }
      });
      expect(action.execute());
    });
  });
});
