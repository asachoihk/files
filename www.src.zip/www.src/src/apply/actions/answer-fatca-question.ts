import { BaseAction, LocatorService, FormBuilderService, SystemEventService } from '@providers';
import { QuestionairePanelComponent } from '@shared/ui-elements';
import { DocumentType } from 'providers/enums/document-type.enum';
import { DocumentDeleted } from 'providers/models/system-event/document-deleted';
import { InsuredModel, AgreementModel } from '@apply/models';

export class AnswerFatcaQuestion extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    const answerConfigured = params.answer;
    const answer = this.$event.value;
    const questionairePanel = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as QuestionairePanelComponent;
    const vm = this.viewModel as InsuredModel;
    vm.agreement.requireFatca = false;
    const agreement = vm.agreement as AgreementModel;

    const citizenship = vm.person.basicInfo.citizenship ? vm.person.basicInfo.citizenship === 'US' : false;
    if (answerConfigured === answer) {
      if (citizenship) {
        this.showFatcaW9(agreement, questionairePanel, true);
      }
      this.showFatcaW8(agreement, questionairePanel, !citizenship);
    } else {
      if (!citizenship) {
        agreement.documents = [];
        vm.documents = (vm.documents || []).filter(d => d.type !== DocumentType.FATCA);
        this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfigId('fatcaW9Document');
      }
      this.showFatcaW9(agreement, questionairePanel, true);
    }
    this.ls.getService<SystemEventService>('systemEventService').publish(new DocumentDeleted(vm));
  }

  showFatcaW8(agreement, questionairePanel, isDelete = true) {
    const vm = this.viewModel as InsuredModel;
    vm.agreement.requireFatca = true;
    if (isDelete) {
      agreement.documents = [];
      vm.documents = (vm.documents || []).filter(d => d.type !== DocumentType.FATCA);
      questionairePanel.reset();
      this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfigId('fatcaW9Form');
      this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfigId('fatcaW9Document');
    }
    questionairePanel.loadAnswerComponent('fatcaForm', { viewModel: vm, parentFormFieldConfig: this.parentFormFieldConfig });
  }

  showFatcaW9(agreement, questionairePanel, isDelete = true) {
    const vm = this.viewModel as InsuredModel;
    vm.agreement.requireFatca = true;
    if (isDelete) {
      agreement.anwserFatca2 = '';
      questionairePanel.reset();
      this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfigId('fatcaForm');
      this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfigId('fatcaW8Document');
    }
    questionairePanel.loadAnswerComponent('fatcaW9Form', { viewModel: this.viewModel, parentFormFieldConfig: this.parentFormFieldConfig });
  }
}
