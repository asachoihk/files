import { LocatorService } from '@providers';
import { GetRulebookParamValue } from '@shared/actions/disclosure/get-rulebook-param-value';
import { DisclosureParams } from 'disclosure/models/disclosure-params';

export class GetMyEducationUnbornApplyFlagParamValue extends GetRulebookParamValue {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  protected getParamValue(disclosureParams: DisclosureParams): any {
    
    return 'N';
  }
}