import { LocatorService } from '@providers';
import { GetRulebookParamValue } from '@shared/actions/disclosure/get-rulebook-param-value';
import { DisclosureParams } from 'disclosure/models/disclosure-params';
import { InsuredModel } from '@apply/models';
import { HEIGHT_UNIT, WEIGHT_UNIT } from '@apply/const';

export class GetBmiParamValue extends GetRulebookParamValue {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  protected getParamValue(disclosureParams: DisclosureParams): any {
    const insuredPerson = disclosureParams.insuredPerson as InsuredModel;
    return this.calculateBmi(insuredPerson);
  }

  protected calculateBmi(insuredPerson: InsuredModel) {
    const basicInfo = insuredPerson.person.basicInfo;
    const height = basicInfo.height.unit === HEIGHT_UNIT.M ? basicInfo.height.value : (basicInfo.height.value * 0.01);
    const weight = basicInfo.weight.unit === WEIGHT_UNIT.KG ? basicInfo.weight.value : (basicInfo.weight.value * 0.4535923);

    return (weight / Math.pow(height, 2)).toFixed(2);
  }
}