import { LocatorService } from '@providers';
import { GetRulebookParamValue } from '@shared/actions/disclosure/get-rulebook-param-value';
import { DisclosureParams } from 'disclosure/models/disclosure-params';
import { InsuredModel } from '@apply/models';

export class GetAgeBandParamValue extends GetRulebookParamValue {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  protected getParamValue(disclosureParams: DisclosureParams): any {
    const insuredPerson = disclosureParams.insuredPerson as InsuredModel;
    const age = insuredPerson.person.basicInfo.age;

    return this.calculateAgeBand(age);
  }

  protected calculateAgeBand(age: any): string {
    const a = parseInt(age);

    if (a >= 10 && a <= 15) {
      return '10_15';
    } else if (a >= 16 && a <= 17) {
      return '16_17';
    } else if (a >= 18 && a <= 65) {
      return '18_65';
    } else if (a > 65) {
      return 'OVER_65';
    }

    return '';
  }
}