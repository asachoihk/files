import { LocatorService } from '@providers';
import { GetRulebookParamValue } from '@shared/actions/disclosure/get-rulebook-param-value';
import { DisclosureParams } from 'disclosure/models/disclosure-params';
import { InsuredModel } from '@apply/models';

export class GetSmokerStatusParamValue extends GetRulebookParamValue {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  protected getParamValue(disclosureParams: DisclosureParams): any {
    const insuredPerson = disclosureParams.insuredPerson as InsuredModel;
    const smokingStatus = insuredPerson.person.basicInfo.smokingStatus;

    return smokingStatus === 'NEVER_SMOKE' ? 'NON_SMOKER' : 'SMOKER';
  }
}