import { LocatorService } from '@providers';
import { GetRulebookParamValue } from '@shared/actions/disclosure/get-rulebook-param-value';
import { DisclosureParams } from 'disclosure/models/disclosure-params';
import { InsuredModel } from '@apply/models';

export class GetAgeParamValue extends GetRulebookParamValue {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  protected getParamValue(disclosureParams: DisclosureParams): any {
    const insuredPerson = disclosureParams.insuredPerson as InsuredModel;
    return insuredPerson.person.basicInfo.age;
  }
}