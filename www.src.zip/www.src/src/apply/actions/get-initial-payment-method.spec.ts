
import { TestBed } from '@angular/core/testing';
import { LocatorService, JsonConfigService } from '@providers';
import { GetInitialPaymentMode } from './get-initial-payment-method';

class Action extends GetInitialPaymentMode {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}


class MockJsonConfigService {
  constructor() { }

  getInitialPaymentMethod() {
    return [{
      label: 'Cash',
      value: 'CASH'
    }];
  }
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'jsonConfigService':
        return new MockJsonConfigService();
      default:
        break;
    }
  }
}

describe('GetInitialPaymentMode', () => {
  let action: Action;
  let ls: LocatorService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: JsonConfigService, useClass: MockJsonConfigService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run', () => {
      const params = null;
      expect(JSON.stringify(action.execute(params))).toEqual(JSON.stringify([{
        label: 'Cash',
        value: 'CASH'
      }]));
    });
  });
});
