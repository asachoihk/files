import { BaseAction, LocatorService, FormBuilderService, ActionService } from '@providers';
import { QuestionairePanelComponent } from '@shared/ui-elements';
import { InsuredModel, AgreementModel } from '@apply/models';

export class LoadAnswerAgreementQuestion extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params: any) {
        const questionairePanel = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as QuestionairePanelComponent;
        if (questionairePanel) {
            const answerConfigured = params.answer;
            const viewModel = this.viewModel as InsuredModel;
            const agreement = viewModel.agreement as AgreementModel;
            const answer = agreement.hasExistingPolicy;
            if (answerConfigured === answer) {
                const actionParams = this.ls.getService<ActionService>('actionService').createActionParams(this);
                questionairePanel.loadAnswerComponent('replacementForm', actionParams);
            }
        }
    }
}
