import { BaseAction, LocatorService, FormBuilderService } from '@providers';
import { ApplicationService, AddressService } from '@apply/services';
import { PersonAddressType } from '@apply/enums';
import { AddressComponent } from '@shared/ui-elements';

export class CopyResidentialAddress extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params: any): void {
        const checked = this.$event.checked;
        const addressType = params.addressType;
        const addressFieldId = params.addressFieldId;
        const addressComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(addressFieldId, this.formConfig) as AddressComponent;
        const currentAddress = addressComponent.addressModel;
        const applyData = this.ls.getService<ApplicationService>('applicationService').getCurrentApplyData();
        const cachedResidentialAddress = (applyData.masterProfileAddressData || []).find(a => a.addressType === PersonAddressType.HOME);
        const cachedAddress = (applyData.masterProfileAddressData || []).find(a => a.addressType === addressType);
        if (!cachedAddress || !cachedResidentialAddress) { return; }

        this.ls.getService<AddressService>('addressService').copyAddress(checked ? cachedResidentialAddress : cachedAddress, currentAddress);
        addressComponent.refreshAddressData();
    }
}
