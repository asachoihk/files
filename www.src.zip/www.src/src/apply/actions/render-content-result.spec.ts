import { RenderContentResult } from './render-content-result';
import { LocatorService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { ApplyModel } from '@apply/models';

class Action extends RenderContentResult {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {

}

describe('RenderContentResult', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            const clean =
                '<p>Congratulations! <b>Your application is conditionally approved</b> subject to internal record checking. <b>Your payment is successfully completed</b>. You will be notified through your insurance advisor and trough you provided email address if there are further requirement(s).</p>';
            action.viewModel = {
                declaration_answer: {
                    agent_question: 'Y',
                    agent_answer: 'abc'
                }
            } as ApplyModel;
            expect(action.execute()).toEqual(clean);
        });
    });
});