import { LocatorService, BaseAction, AppContextService } from '@providers';
import { InsuredModel } from '@apply/models';
import { SupportingDocsService } from '@apply/services';

export class GetSupportingDocsSteps extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(): any[] {
        const insuredPerson = this.ls.getService<AppContextService>('appContextService').currentFormBuilder.viewModel as InsuredModel;
        const availableDocumentTypes = this.ls.getService<SupportingDocsService>('supportingDocsService').getAvailableDocumentTypes(insuredPerson);

        return availableDocumentTypes.map(t => {
            return { id: t.toString(), text: t.toString(), hidden: true };
        });
    }
}