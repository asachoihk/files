import { GlobalNavigationService, CustomerService, CustomerTransformationService, BaseAction, APPLICATION_STATUS } from '@providers';
import { map } from 'rxjs/operators';
import { ApplicationService } from '@apply/services';
import { forkJoin } from 'rxjs';

export class SelectAgentApplication extends BaseAction {
    execute(params: any) {
        if (params && params.applicationId && params.customerId && params.status) {
            const applicationId = params.applicationId;
            const customerID = params.customerId;
            const status = params.status;
            const getCustomer = this.ls.getService<CustomerService>('customerService').getById(customerID);
            const getApplyData = this.ls.getService<ApplicationService>('applicationService').getApplication(customerID, applicationId);
            return forkJoin([getCustomer, getApplyData]).pipe(
                map((data: any[]) => {
                    const customer = data[0];
                    
                    const customerUI = this.ls.getService<CustomerTransformationService>('customerTransformationService').transformCustomerData2UI(customer);
                    this.ls.getService<CustomerService>('customerService').setCurrent(customerUI);
                    switch (status) {
                        case APPLICATION_STATUS.SUBMITTED:
                            this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission', { applicationId: applicationId, previousData: params.keywords });
                            break;
                        default:
                            this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/basic-info', { applicationId: applicationId, previousData: params.keywords });
                            break;
                    }
                })
            );
        }
    }
}
