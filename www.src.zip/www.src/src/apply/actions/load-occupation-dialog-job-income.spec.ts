import { LocatorService, Occupation } from '@providers';
import { TestBed } from '@angular/core/testing';
import { TranslationService } from 'angular-l10n';
import { LoadOccupationDialogJobIncome } from './load-occupation-dialog-job-income';
import { IncomeSourceModel } from '@apply/models';

class Action extends LoadOccupationDialogJobIncome {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService() {
        return new MockFormBuilderService();
    }

    get() {
        return new MockTranslationService();
    }
}

class MockTranslationService {
    translate() {
        return 'translated text';
    }
}

class MockFormBuilderService {
    setFormFieldValue() {
        return {};
    }
}

describe('LoadOccupationDialogJobIncome', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: TranslationService, useClass: MockTranslationService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - getDialogData', () => {
        it('should be run', () => {
            action.viewModel = {
                notifyValueChanges() {
                    return {};
                }
            } as any;
            action.parentFormFieldConfig = {} as any;
            action.formFieldConfig = {
                dataSourceMetadata: {}
            } as any;
            expect(action.getDialogData()).toEqual({
                viewModel: action.viewModel,
                formFieldConfig: action.parentFormFieldConfig,
                params: {
                    componentParams: {
                        header: 'translated text',
                        dataSource: {
                            actionName: 'getOccupation'
                        },
                        dataSourceMetadata: action.formFieldConfig.dataSourceMetadata
                    }
                }
            });
        });
    });

    describe('Function - handleSearchListDialogClosed', () => {
        it('should be run - incomeSource === undefined', () => {
            const result = {
                id: 'abc',
                description: 'abc'
            };
            action.viewModel = {
                notifyValueChanges() {
                    return {};
                },
                person: {
                    incomeSource: {} as IncomeSourceModel
                }
            } as any;
            action.parentFormFieldConfig = {} as any;
            action.formFieldConfig = {
                dataSourceMetadata: {},
                label: ''
            } as any;
            action.handleSearchListDialogClosed(result as Occupation);
            expect(action.ls.getService).toBeTruthy();
        });

        it('should be run - incomeSource !== undefined', () => {
            const result = {
                id: 'abc',
                description: 'abc'
            };
            action.viewModel = {
                notifyValueChanges() {
                    return {};
                },
                person: {
                    incomeSource: undefined
                }
            } as any;
            action.parentFormFieldConfig = {} as any;
            action.formFieldConfig = {
                dataSourceMetadata: {},
                label: ''
            } as any;
            action.handleSearchListDialogClosed(result as Occupation);
            spyOn(action.ls, 'getService').and.callThrough();
            expect(action.ls.getService).toBeTruthy();
        });
    });

    describe('Function - getKeyName', () => {
        it('should be run', () => {
            action.viewModel = {
                notifyValueChanges() {
                    return {};
                },
                person: {
                    incomeSource: {} as IncomeSourceModel
                }
            } as any;
            action.parentFormFieldConfig = {} as any;
            action.formFieldConfig = {
                dataSourceMetadata: {},
                label: ''
            } as any;
            expect(action.getKeyName()).toEqual('value');
        });
    });
});