import { LocatorService, BaseAction, APPLICATION_STATUS } from '@providers';
import { ApplyModel } from '@apply/models';
import { ApplicationService, ApplicationsMapperService } from '@apply/services';

export class GetApplyData extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): ApplyModel {
    const applyData = this.ls.getService<ApplicationService>('applicationService').getCurrentApplyData();
    const expiryDate = ApplicationsMapperService.getDate(applyData.expiryDate);
    applyData.status = ApplicationsMapperService.checkIfExpired(expiryDate, applyData.status) ? APPLICATION_STATUS.EXPIRED : applyData.status;

    return applyData;
  }
}
