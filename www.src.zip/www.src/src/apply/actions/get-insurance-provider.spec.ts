import { GetInsuranceProvider } from './get-insurance-provider';
import { LocatorService, JsonConfigService } from '@providers';
import { TestBed, async } from '@angular/core/testing';

class Action extends GetInsuranceProvider {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockJsonConfigService {
  constructor() { }

  getInsuranceProvider() {
    return [{
      id: '001',
      name: 'Manulife'
    }];
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'jsonConfigService':
        return new MockJsonConfigService();
      default:
        break;
    }
  }
}

describe('Get Insurance Provider', () => {
  let action: Action;
  let ls: LocatorService;
  const formFieldConfig = { id: 'list', type: 'list', label: 'Proceed_Signature' };


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: JsonConfigService, useClass: MockJsonConfigService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run', async(() => {
      action.formFieldConfig = formFieldConfig;
      action.formFieldConfig.type = 'list';
      expect(action.execute().subscribe());
    }));

    it('should be run', async(() => {
      action.formFieldConfig = formFieldConfig;
      action.formFieldConfig.type = 'button';
      expect(action.execute().subscribe());
    }));

    it('should be run', async(() => {
      action.formFieldConfig = formFieldConfig;
      action.formFieldConfig.type = 'button';
      action.formFieldConfig.default  = 'abc';
      expect(action.execute().subscribe());
    }));
  });
});
