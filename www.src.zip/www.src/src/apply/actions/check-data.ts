import { LocatorService, GlobalNavigationService, BaseAction, APPLICATION_STATUS } from '@providers';
import { ActivatedRoute } from '@angular/router';
import { ApplyModel } from '@apply/models';
import { ApplicationService } from '@apply/services';
import { PaymentMethod } from '@apply/enums';

export class CheckData extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const router = this.ls.get(ActivatedRoute);
    const appId = router.snapshot.queryParams.applicationId;
    const applyData = this.ls.getService<ApplicationService>('applicationService').getApplyData(appId) as ApplyModel;

    switch (applyData.status) {
      case APPLICATION_STATUS.SUBMISSION_CONFIRMED:
        this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission/agent-question');
        break;
      case APPLICATION_STATUS.PAYMENT_PENDING:
        this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission/payment-online');
        break;
      case APPLICATION_STATUS.SUBMISSION_AGENT_QUESTION:
        if (applyData.payment.method === PaymentMethod.ONLINE.toString()) {
          this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission/payment-online');
        } else {
          this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission/application-result');
        }
        break;
      case APPLICATION_STATUS.PAID:
      case APPLICATION_STATUS.SUBMITTED:
        this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission/application-result');
        break;
      default:
        break;
    }
  }
}
