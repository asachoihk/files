import { LocatorService, BaseAction } from '@providers';

export class CloseCountryDialog extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params: any): void {
        this.dialogRef.close(params);
    }
}
