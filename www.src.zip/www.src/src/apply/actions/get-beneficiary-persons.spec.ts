import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { GetBeneficiaryPersons } from './get-beneficiary-persons';
import { ApplyModel } from '@apply/models';


class Action extends GetBeneficiaryPersons {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }

    getService() {
    }

    get() {}
}

describe('GetBeneficiaryPersons', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be return', () => {
            action.formFieldConfig = {
                id: 'id',
                type: 'dropdown'
            };
            action.viewModel = new ApplyModel();
            (action.viewModel as any) = {
                beneficiaries: [{
                    person: {
                        basicInfo: {
                            gender: 'male'
                        },
                    },
                    insuredRelationship: [],
                    guid: 'id'
                }],
                owner: {
                    id: 'id'
                }
            };
            spyOn(action.ls, 'get').and.returnValue({
                translate() {
                    return 'abc';
                }
            });
            spyOn(action.ls, 'getService').and.returnValue({
                getComponentByFormFieldConfig() {
                    return {
                        taskCardSelectionVisibility: []
                    };
                }
            });
            const params = {maxBeneficiaryAllowed: 1};
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
            expect(action.ls.get).toHaveBeenCalled();
        });
    });

    describe('Function - Excute', () => {
        it('should run', () => {
            spyOn(action.ls, 'get').and.returnValue({
                translate() {
                    return 'abc';
                }
            });
            spyOn(action.ls, 'getService').and.returnValue({
                getRelationCode() {
                    return [{
                        id: 'id'
                    }];
                }
            });
            action.convertRelationCode('id');
            expect(action.ls.getService).toHaveBeenCalled();
            expect(action.ls.get).toHaveBeenCalled();
        });
    });
});
