import { LocatorService, BaseAction } from '@providers';
import { ApplicationService } from '@apply/services';

export class GetCurrentApplicationName extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(): string {
        return this.ls.getService<ApplicationService>('applicationService').getCurrentApplyData().basicPlan.name;
    }
}
