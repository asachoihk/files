import { BaseAction, LocatorService } from '@providers';

export class GetCreditCards extends BaseAction {
  constructor(protected ls: LocatorService) {
      super(ls);
  }

  execute(params?: any): any[] {
    const cards = params.cards as any[];
    return cards.map(c => {
      c.action = params.action;
      return c;
    });
  }
}
