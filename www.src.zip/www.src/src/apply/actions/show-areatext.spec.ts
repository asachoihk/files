import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { ShowAreatext } from './show-areatext';
import { ApplyModel } from '@apply/models';

class Action extends ShowAreatext {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }
    getService() { }
}


describe('ShowAreatext', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be create', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - excute', () => {
        it('should be run', () => {
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton', relationships: ['beneficialOwnerList', 'beneficialOwnerAllocation'], dataBinding: { path: ''} };
            action.viewModel = new ApplyModel();
            (action.viewModel as any) = {
                declaration_answer: {},
                notifyValueChanges() {
                    return;
                }
            };
            spyOn(action.ls, 'getService').and.returnValue({
                getComponentByFormFieldConfigId() {
                    return {
                        visibility: 'hidden'
                    };
                },
                setBindingData() {
                    return;
                }
            });
            action.execute('defaultVal');
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be run agent_quenstionb = N', () => {
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton', relationships: ['beneficialOwnerList', 'beneficialOwnerAllocation'], dataBinding: { path: ''} };
            action.viewModel = new ApplyModel();
            (action.viewModel as any) = {
                declaration_answer: {
                    agent_question: 'N'
                },
                notifyValueChanges() {
                    return;
                }
            };
            spyOn(action.ls, 'getService').and.returnValue({
                getComponentByFormFieldConfigId() {
                    return {
                        visibility: 'hidden'
                    };
                },
                setBindingData() {
                    return;
                }
            });
            action.execute('test');
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be run without params', () => {
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton', relationships: ['beneficialOwnerList', 'beneficialOwnerAllocation'], dataBinding: { path: ''} };
            action.viewModel = new ApplyModel();
            (action.viewModel as any) = {
                declaration_answer: {},
                notifyValueChanges() {
                    return;
                }
            };
            action.$event = {
                value: 'Y'
            };
            spyOn(action.ls, 'getService').and.returnValue({
                getComponentByFormFieldConfigId() {
                    return {
                        visibility: 'hidden',
                        formFieldConfig: {
                            dataBinding: { path: ''}
                        }
                    };
                },
                setBindingData() {}
            });
            action.execute('');
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be run without params & event.value = "N"', () => {
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton', relationships: ['beneficialOwnerList', 'beneficialOwnerAllocation'], dataBinding: { path: ''} };
            action.viewModel = new ApplyModel();
            (action.viewModel as any) = {
                declaration_answer: {},
                notifyValueChanges() {
                    return;
                }
            };
            action.$event = {
                value: 'N'
            };
            spyOn(action.ls, 'getService').and.returnValue({
                getComponentByFormFieldConfigId() {
                    return {
                        visibility: 'hidden',
                        formFieldConfig: {
                            dataBinding: { path: ''}
                        }
                    };
                },
                setBindingData() {}
            });
            action.execute('');
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });

});
