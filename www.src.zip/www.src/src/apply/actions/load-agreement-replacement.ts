import { BaseAction, LocatorService, FormBuilderService, AgreementAnswerMetadata, Visibility } from '@providers';
import { ButtonComponent } from '@shared/ui-elements';
import { AgreementInsuranceListComponent } from '@apply/components';

export class LoadAgreementReplacement extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    if (params && params.addBtnFieldId && params.agreementInsurancesFieldId) {
      const button = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(params.addBtnFieldId) as ButtonComponent;
      const agreementInsuranceList = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(params.agreementInsurancesFieldId) as AgreementInsuranceListComponent;
      if (button && agreementInsuranceList) {
        const metadata = agreementInsuranceList.formFieldConfig.metadata as AgreementAnswerMetadata;
        button.visibility = metadata && metadata.max && agreementInsuranceList.dataSource.length >= metadata.max ? Visibility.hidden : Visibility.visible;
      }
    }
  }
}
