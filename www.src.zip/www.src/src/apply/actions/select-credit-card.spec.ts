import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { SelectCreditCard } from './select-credit-card';

class Action extends SelectCreditCard {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    getService(serviceName: string): any {
        if (serviceName === 'actionService') {
            return new MockActionService();
        }
        return new MockDialogService();
    }
}

class MockActionService {
    createActionParams = () => {
        return { width: '', height: '' };
    }
}

class MockDialogService {
    showFormBuilderDialog = (component, dialog, action, callback) => { callback({}); };
}

describe('SelectCreditCard', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            expect(action.execute()).toBeFalsy();
        });
    });
});
