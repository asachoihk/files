import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { SelectApplication } from './select-application';
import { ApplicationsMapperService } from '@apply/services';
import { of } from 'rxjs/observable/of';

class Action extends SelectApplication {
    constructor(public ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    constructor() { }
    getService() {
        return null;
    }
}

class MockApplicationsMapperService {
    getDate() {
        return null;
    }

    checkIfExpired() {
        return 'SUBMISSION_CONFIRMED';
    }
}

describe('SelectApplication', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ApplicationsMapperService, useClass: MockApplicationsMapperService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        const params = {
            applicationId: '18072433-c834-755a-9372-6826ef99f9fb',
            customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab',
            status: 'SUBMITTED',
            keywords: 'test'
        };
        it('should be run', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getApplication() {
                     return of({
                        status: 'SUBMISSION_CONFIRMED',
                        expiryDate: '2019-06-27T07:52:50.352Z'
                     });
                },
                navigateTo: () => '/apply/application-details/submission/application-result'
            });
            action.execute(params).subscribe((result) => {
                expect(result).toBeFalsy();
            });
        });

        it('should be run status = SUBMITTED', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getApplication() {
                     return of({
                        status: 'SUBMITTED',
                        expiryDate: '2019-06-27T07:52:50.352Z'
                     });
                },
                navigateTo: () => '/apply/application-details/submission/application-result'
            });
            action.execute(params).subscribe((result) => {
                expect(result).toBeFalsy();
            });
        });

        it('should be run status = PAID', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getApplication: () => {
                     return of({
                        status: 'PAID',
                        expiryDate: '2019-06-27T07:52:50.352Z'
                     });
                },
                navigateTo: () => '/apply/application-details/submission/application-result'
            });
            action.execute(params).subscribe((result) => {
                expect(result).toBeFalsy();
            });
        });

        it('should be run status = DEFAULT', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                getApplication() {
                     return of({
                        status: 'DEFAULT',
                        expiryDate: '2019-06-27T07:52:50.352Z'
                     });
                },
                navigateTo: () => '/apply/application-details/submission/application-result'
            });
            action.execute(params).subscribe((result) => {
                expect(result).toBeFalsy();
            });
        });
    });
});
