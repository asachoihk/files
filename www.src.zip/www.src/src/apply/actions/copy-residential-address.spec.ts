import { LocatorService, FormBuilderService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { AddressService, ApplicationService } from '@apply/services';
import { CopyResidentialAddress } from './copy-residential-address';

class Action extends CopyResidentialAddress {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

        if (serviceName === 'applicationService') {
            return new MockApplicationService();
        }

        if (serviceName === 'addressService') {
            return new MockAddressService();
        }

    }
}

class MockFormBuilderService {
    getComponentByFormFieldConfigId() {
        return {};
    }
}

class MockApplicationService {
    getCurrentApplyData() {
        return {};
    }
}

class MockAddressService {
    copyAddress() {
        return {};
    }
}

describe('CopyResidentialAddress', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService },
                { provide: AddressService, useClass: MockAddressService },
                { provide: ApplicationService, useClass: MockApplicationService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run - (!cachedAddress || !cachedResidentialAddress) === true', () => {
            const params = {
                addressType: undefined,
                addressFieldId: undefined
            };
            action.$event = {} as any;
            expect(action.execute(params)).toBeUndefined();
        });

        it('should be run - (!cachedAddress || !cachedResidentialAddress) === false', () => {
            const params = {
                addressType: 'P',
                addressFieldId: undefined
            };
            action.$event = {} as any;
            spyOn(action.ls, 'getService').and.returnValue({
                getCurrentApplyData() {
                    return {
                        masterProfileAddressData: [
                            {
                                addressType: 'P'
                            }
                        ]
                    };
                },
                getComponentByFormFieldConfigId() {
                    return {
                        refreshAddressData() {
                            return {};
                        }
                    };
                },
                copyAddress() {
                    return {};
                }
            });
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});