import { LocatorService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { ApplyModel } from '@apply/models';
import { GetSignPersons } from './get-sign-persons';

class Action extends GetSignPersons {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockFormBuilderService {
  getComponentByFormFieldConfigId(): any { return [{ showPrecondition: '' }]; }
}

class MockReportSignatureService {
  initFNAForm() { return of({}); }
  initProposalForm() { return of({}); }
  initLifeInsuranceApplicationForm() { return of({}); }
  initOthersInsuredForm() { }
  initEDisclosureForms() { }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      default:
        break;
    }
  }

  get(service) {
    if (service.name === 'ReportSignatureService') {
      return new MockReportSignatureService();
    }
  }
}

describe('GetSignPersons', () => {
  let action: Action;
  let ls: LocatorService;

  const viewModel = {
    proposalId: 'proposalId',
    report_forms: [{ header: 'a' }, { header: 'b' }],
    original_report_forms: [{}],
    agent: {
      agentId: '',
      firstName: 'first',
      lastName: 'last',
      middleName: 'middle'
    },
    owner: {
      id: '123',
      uwDetails: {},
      person: {
        basicInfo: {
          fullName: 'owner fullname'
        }
      },
      agreement: {}
    },
    insured: {
      id: '1234',
      documents: [
        {
          type: 'abc'
        }
      ],
      person: {
        basicInfo: {
          age: 30
        }
      }
    },
    dependents: []
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      action.viewModel = viewModel as ApplyModel;
      action.viewModel['dependents'] = [{
        id: '21312',
        type: 'r',
        fullName: 'dependent fullname',
        maritalStatus: '',
        person: {
          basicInfo: {
            age: 30
          }
        },
        relationToInsured: 'Parent'
      }];

      expect(action.execute()).toBeDefined();
    });
  });
});
