import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { CheckAvailable } from './check-available';


class Action extends CheckAvailable {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }

    getService() {
        return new MockFormBuilderService();
    }
}

class MockFormBuilderService {
    getComponentByFormFieldConfigId(fieldId: string) {
        if (fieldId === 'beneficialOwnerList') {
            return {
                taskCardViewModels: [
                    {
                        test1: '1'
                    }
                ]
            };
        }
        return {
            visibility: 'hidden'
        };
    }
}

describe('CheckAvailable', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        const parans = {
            maxBeneficiaryAllowed: 3,
            addNewMemberButtonFieldId: 'test'
        };
        it('should be run', () => {
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton', relationships: ['beneficialOwnerList', 'beneficialOwnerAllocation'] };
            expect(action.execute(parans)).toBeFalsy();
        });

        it('should be run without relationships in formFieldConfig', () => {
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton' };
            action.parentFormFieldConfig = {
                id: 'btnTest',
                type: 'button'
            };
            expect(action.execute(parans)).toBeFalsy();
        });

        it('should be run without relationships in formFieldConfig and not have parentFormFieldConfig', () => {
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton' };
            expect(action.execute(parans)).toBeFalsy();
        });
    });
});
