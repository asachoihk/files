import { LocatorService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import { GetCurrentInsuredPerson } from './get-current-insured-person';
import { InsuredModel } from '@apply/models';

class Action extends GetCurrentInsuredPerson {
  parentViewModel: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockLocatorService {
}

describe('GetCurrentInsuredPerson', () => {
  let action: Action;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      const params = '';
      action.parentViewModel = new InsuredModel();
      expect(action.execute(params) instanceof InsuredModel).toBe(true);
    });
  });
});
