import { LocatorService, CustomerService, ValidatorService, SystemEventService, SaveAction, ErrorOccurred } from '@providers';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { TranslationService } from 'angular-l10n';
import { ApplicationService } from '@apply/services';
import { BeneficiaryModel } from '@apply/models';

export class SaveBeneficiaryPerson extends SaveAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any): Observable<any> {
    return new Observable<any>(subscriber => {
      const beneficiary = this.viewModel as BeneficiaryModel;
      const customerId = this.ls.get(ActivatedRoute).snapshot.queryParams.customerId || this.ls.getService<CustomerService>('customerService').getCurrent().customerId;

      const applyData = this.ls.getService<ApplicationService>('applicationService').getCurrentApplyData();
      applyData.beneficiaries = applyData.beneficiaries || [];
      const index = applyData.beneficiaries.findIndex(b => b.guid === beneficiary.guid);
      if (index >= 0) {
        applyData.beneficiaries.splice(index, 1);
      }

      if (!params || !params.isDelete) {
        beneficiary.type = 'Beneficiary';
        applyData.beneficiaries.push(beneficiary);
      }
      this.ls
      .getService<ApplicationService>('applicationService')
        .saveApplyData(customerId, [applyData])
        .subscribe(result => {
          if (this.dialogRef) {
            this.dialogRef.close(result);
          }
          subscriber.next(result);
        });
    });
  }

  validateForm(formId, _actionParams) {
    const isValidForm = this.ls.getService<ValidatorService>('validatorService').validateForm(formId);
    const deleteMode = _actionParams.params ? _actionParams.params.isDelete : false;
    if (!isValidForm && !deleteMode) {
      const customerError = new ErrorOccurred(this.ls.get(TranslationService).translate('MSGC021'), true);
      this.ls.getService<SystemEventService>('systemEventService').publish(customerError);
    }
    return isValidForm;
  }
  ignoreValidationResult(_actionParams) {
    return _actionParams && _actionParams.params && _actionParams.params.isDelete ? true : false;
  }
}
