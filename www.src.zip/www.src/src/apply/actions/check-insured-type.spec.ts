import { TestBed } from '@angular/core/testing';
import { LocatorService, Visibility } from '@providers';
import { CheckInsuredType } from './check-insured-type';
import { InsuredModel } from '@apply/models';
import { of } from 'rxjs/internal/observable/of';
import { FormControl } from '@angular/forms';
import { BaseComponent, BaseUiElement, BaseControlComponent } from '@shared/ui-elements';


class Action extends CheckInsuredType {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }

    getService(serviceName) {
        return serviceName === 'systemEventService' ? new MockSystemEventService() : new MockFormBuilderService();
    }
}

class MockSystemEventService {
    publish() {
        return of({});
    }
}

class MockFormBuilderService {
    getChildComponentsByFormFieldConfig() {
        return BaseUiElement;
    }
}

describe('CheckInsuredType', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {

        it('should be return when insured type = r', (done) => {
            action.component  =  (action.component as BaseComponent);
            action.component = {
                visibility: 'hidden',
                formControl: new FormControl()
            };
            setTimeout(() => {
                action.viewModel =  new InsuredModel();
                (action.viewModel as any).type = 'r';
                done();
            }, 2000);

            expect(action.execute('PO')).toBeTruthy();
        });

        it('should be return when insured type = o', (done) => {
            action.component  =  (action.component as BaseControlComponent);
            action.component = {
                visibility: 'hidden',
                formControl: new FormControl()
            };
            setTimeout(() => {
                action.viewModel =  new InsuredModel();
                (action.viewModel as any).type = 'o';
                done();
            }, 2000);

            expect(action.execute('PO')).toBeTruthy();
        });
    });
});
