
import { TestBed } from '@angular/core/testing';
import { LocatorService, InsuredType } from '@providers';
import { GetInsuredPersons } from './get-insured-persons';
import { InsuredPersonService } from '@apply/services';
import { ApplyModel } from '@apply/models';

class Action extends GetInsuredPersons {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}


class MockInsuredPersonService {
  constructor() { }
  getInsuredPersons(applyData) {
    return [
      {
        id: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab'

      }
    ];
  }
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'insuredPersonService':
        return new MockInsuredPersonService();
      default:
        break;
    }
  }
}

describe('GetInsuredPersons', () => {
  let action: Action;
  let ls: LocatorService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: InsuredPersonService, useClass: MockInsuredPersonService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    // const paramsNull = null;
    it('should be run with no params', () => {
      action.viewModel = new ApplyModel();
      expect(action.execute());
    });

    const params = { section: 'disclosure' };
    it('should be run with params is section', () => {
      const appModel = new ApplyModel();
      appModel.owner.id = 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdear';
      appModel.riders = [
        {
          insuredId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab',
          id: '',
          code: '',
          name: '',
          type: '',
          faceAmount: 0,
          classImpatient: '',
          classOutpatient: '',
          classDental: '',
          insuredName: '',
          premiums: []
        }
      ];
      appModel.insured.type = InsuredType.o;
      action.viewModel = appModel;
      expect(action.execute(params));
    });

    const paramsApplyData = { applyData: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeac' };
    it('should be run with params is applyData', () => {
      action.viewModel = new ApplyModel();
      expect(action.execute(paramsApplyData));
    });
  });
});
