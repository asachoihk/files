import { TestBed, async } from '@angular/core/testing';
import { LocatorService, JsonConfigService } from '@providers';
import { GetBankBranchs } from './get-bank-branch';


class Action extends GetBankBranchs {
    constructor(public ls: LocatorService) {
      super(ls);
    }
  }

  class MockLocatorService {
    getService(serviceName: string) {
        switch (serviceName) {
          case 'jsonConfigService':
            return new MockJsonConfigService();
          default:
            break;
        }
      }
  }

  class MockJsonConfigService {
    constructor() {
    }
    getBankBranches() {
      return [];
    }
  }

describe('GetBankBranchs', () => {
    let action: Action;
    let ls: LocatorService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: JsonConfigService, useClass: MockJsonConfigService },
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
      });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', async(() => {
          action.execute().subscribe(data =>{
            expect(data).toEqual([]);
          });
        }));
    });
});
