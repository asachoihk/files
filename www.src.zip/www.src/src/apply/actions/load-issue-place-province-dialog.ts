import { LocatorService, DialogData } from '@providers';
import { OpenSearchListDialog } from '@shared/actions/search-list/open-search-list-dialog';

export class LoadIssuePlaceProvinceDialog extends OpenSearchListDialog {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  getDialogData(): DialogData {
    return {
      viewModel: this.viewModel,
      formFieldConfig: this.parentFormFieldConfig,
      params: {
        componentParams: {
          header: 'Search province',
          dataSource: {
            actionName: 'getProvinces'
          },
          dataSourceMetadata: this.formFieldConfig.dataSourceMetadata
        },
        header: this.formFieldConfig.label
      }
    };
  }

  getKeyName(): string {
    return 'value';
  }

}
