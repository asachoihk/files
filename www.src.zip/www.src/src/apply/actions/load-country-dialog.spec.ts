import { LoadCountryDialog } from './load-country-dialog';
import { LocatorService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { TranslationService } from 'angular-l10n';

class Action extends LoadCountryDialog {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {

    get() {
        return new MockTranslationService();
    }
}

class MockTranslationService {
    translate() {
        return 'translated text';
    }
}

describe('LoadCountryDialog', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: TranslationService, useClass: MockTranslationService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - getDialogData', () => {
        it('should be run', () => {
            const model = {};
            const parentFormFieldConfig = {
                dataSourceMetadata: {}
            };
            const formFieldConfig = {
                label: 'abc'
            };
            action.viewModel = model as any;
            action.parentFormFieldConfig = parentFormFieldConfig as any;
            action.formFieldConfig = formFieldConfig as any;
            expect(action.getDialogData());
        });
    });
});