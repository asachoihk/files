import { LocatorService, FormBuilderService, BaseAction } from '@providers';
import { InsuredModel } from '@apply/models';

export class UpdateBankInfo extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params: any): void {
        const bankNamebindingPath = params;
        const bankName = this.$event.source.triggerValue;

        const bankModel = this.viewModel as InsuredModel;

        if (bankName) {
            bankModel.person.bankInfo.branchCode = '';
            bankModel.person.bankInfo.branchName = '';
        }

        this.ls.getService<FormBuilderService>('formBuilderService').setBindingData(this.viewModel, bankNamebindingPath, bankName);
    }
}
