import { LocatorService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import { LoadAgreementsDialog } from './load-agreements-dialog';
import { InsuredModel } from '@apply/models';

class Action extends LoadAgreementsDialog {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockFormBuilderService {
  getComponentByFormFieldConfig() {
    return {
      loadDataSource: () => { }
    };
  }
}

class MockAppContextService {
  currentFormBuilder = {
    refreshData: (callback) => {
      return callback();
    }
  };
}

class MockDialogService {
  showFormBuilderDialog(component, dialogConfig, data, callback) {
    return callback({
      action: 'yes'
    });
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'appContextService':
        return new MockAppContextService();
      case 'dialogService':
        return new MockDialogService();
      default:
        break;
    }
  }
}

describe('LoadAgreementsDialog', () => {
  let action: Action;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    beforeEach(() => {
      spyOn(action.ls, 'getService').and.callThrough();
    });

    it('should be run dependent', () => {
      action.viewModel = new InsuredModel();
      action.viewModel['type'] = 'r';

      action.execute();
      expect(action.ls.getService).toHaveBeenCalled();
    });

    it('should be run insured', () => {
      action.viewModel = new InsuredModel();
      action.viewModel['type'] = 'i';

      action.execute();
      expect(action.ls.getService).toHaveBeenCalled();
    });

    it('should be run owner', () => {
      action.viewModel = new InsuredModel();
      action.viewModel['type'] = 'o';

      action.execute();
      expect(action.ls.getService).toHaveBeenCalled();
    });
  });
});
