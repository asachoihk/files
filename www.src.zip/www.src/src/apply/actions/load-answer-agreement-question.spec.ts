import { LocatorService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import { InsuredModel } from '@apply/models';
import { LoadAnswerAgreementQuestion } from './load-answer-agreement-question';

class Action extends LoadAnswerAgreementQuestion {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockFormBuilderService {
  getComponentByFormFieldConfig() {
    return {
      loadAnswerComponent: () => { }
    };
  }
}

class MockActionService {
  createActionParams() { return {}; }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'actionService':
        return new MockActionService();
      default:
        break;
    }
  }
}

describe('LoadAnswerAgreementQuestion', () => {
  let action: Action;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    beforeEach(() => {
      spyOn(action.ls, 'getService').and.callThrough();
    });

    it('should be run', () => {
      action.viewModel = new InsuredModel();
      action.viewModel['agreement']['hasExistingPolicy'] = 'yes';

      const params = { answer: 'yes' };
      action.execute(params);
      expect(action.ls.getService).toHaveBeenCalled();
    });
  });
});
