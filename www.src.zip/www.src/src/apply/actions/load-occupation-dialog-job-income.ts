import { LocatorService, FormBuilderService, DialogData, Occupation } from '@providers';
import { TranslationService } from 'angular-l10n';
import { OpenSearchListDialog } from '@shared/actions/search-list/open-search-list-dialog';
import { InsuredModel, IncomeSourceModel } from '@apply/models';

export class LoadOccupationDialogJobIncome extends OpenSearchListDialog {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  getDialogData(): DialogData {
    const headerOccupation = this.ls.get(TranslationService).translate('searchOccupation');
    return {
      viewModel: this.viewModel,
      formFieldConfig: this.parentFormFieldConfig,
      params: {
        componentParams: {
          header: headerOccupation,
          dataSource: {
            actionName: 'getOccupation'
          },
          dataSourceMetadata: this.formFieldConfig.dataSourceMetadata
        }
      }
    };
  }

  handleSearchListDialogClosed(result: Occupation) {
    const viewModel = this.viewModel as InsuredModel;
    let incomeSource = viewModel.person.incomeSource;
    if (!incomeSource) {
      incomeSource = new IncomeSourceModel();
      viewModel.person.incomeSource = incomeSource;
    }
    incomeSource.occupation = result.description;
    incomeSource.occupationId = result.id;

    this.ls.getService<FormBuilderService>('formBuilderService').setFormFieldValue(this.viewModel, this.formFieldConfig, incomeSource);
    this.viewModel.notifyValueChanges(this.formFieldConfig);
  }

  getKeyName(): string {
    return 'value';
  }
}
