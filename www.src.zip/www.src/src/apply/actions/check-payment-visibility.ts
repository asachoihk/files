import { LocatorService, FormBuilderService, BaseAction, Visibility, APPLICATION_STATUS } from '@providers';
import { ButtonComponent, CardListComponent } from '@shared/ui-elements';
import { ApplyModel } from '@apply/models';

export class CheckPaymentVisibility extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute() {
        const continueBtn = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as ButtonComponent;
        const cardList = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('cardList') as CardListComponent;
        const applyData = this.viewModel as ApplyModel;
        if (continueBtn) {
            switch (applyData.status) {
                case APPLICATION_STATUS.SUBMISSION_AGENT_QUESTION:
                    continueBtn.visibility = Visibility.disabled;
                    break;
                case APPLICATION_STATUS.PAYMENT_PENDING:
                    switch (cardList.visibility) {
                        case Visibility.visible:
                            continueBtn.visibility = cardList.selectedItem ? Visibility.visible : Visibility.disabled;
                            break;
                        case Visibility.hidden:
                            continueBtn.visibility = applyData.payment.documents && applyData.payment.documents.length ? Visibility.visible : Visibility.disabled;
                            break;
                        default:
                            continueBtn.visibility = Visibility.disabled;
                            break;
                    }
            }
        }
    }
}
