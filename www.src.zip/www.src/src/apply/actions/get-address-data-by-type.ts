import { BaseAction, LocatorService, PersonAddressModel, FormBuilderService, AddressMetadata, JsonConfigService } from '@providers';

export class GetAddressDataByType extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): PersonAddressModel {
    const addressMetadata = this.formFieldConfig.metadata as AddressMetadata;
    let addressModels: PersonAddressModel[] = this.ls.getService<FormBuilderService>('formBuilderService').getBindingData(this.viewModel, this.formFieldConfig.dataBinding.path);
    if (!addressModels) {
      addressModels = [];
      this.ls.getService<FormBuilderService>('formBuilderService').setBindingData(this.viewModel, this.formFieldConfig.dataBinding.path, addressModels);
    }

    let addressModel = addressModels.find(p => p.addressType === addressMetadata.type);
    if (!addressModel) {
      addressModel = new PersonAddressModel();
      addressModel.addressType = addressMetadata.type;
      addressModels.push(addressModel);
    } else if (!addressModel.notifyValueChanges) {
      const oldAddress = addressModel;
      addressModels.splice(addressModels.indexOf(oldAddress), 1);
      addressModel = new PersonAddressModel();
      Object.keys(oldAddress).forEach(name => {
        addressModel[name] = oldAddress[name];
      });

      addressModels.push(addressModel);
    }

    if (!addressModel.zipcode || addressModel.zipcode.length !== 6) {
      addressModel.zipcode = '';
    }

    if (!addressModel.country || addressModel.country === 'Vietnam') {
      addressModel.country = this.ls.getService<JsonConfigService>('jsonConfigService').getAppConfig().homeCountry.countryCode;
    }

    return addressModel;
  }
}