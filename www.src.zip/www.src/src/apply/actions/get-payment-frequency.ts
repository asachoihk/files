import { LocatorService, BaseAction } from '@providers';
import { ApplyModel } from '@apply/models';
import { PaymentMode } from '@apply/enums';

export class GetPaymentFrequency extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    const applyData = this.viewModel as ApplyModel;
    const paymentMode = applyData.payment ? applyData.payment.mode : null;
    const premium = applyData.totalPayment;
    const data = [];
    Object.keys(premium).forEach(key => {
      const selected = key === paymentMode;
      data.push({
        label: key,
        value: key,
        selected: selected
      });
    });

    if (applyData.basicPlan.code === params['excludeMonthlyIf']) {
      return data.filter(d => d.value !== PaymentMode.monthly);
    }
    return data;
  }
}
