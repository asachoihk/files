import { LocatorService, JsonConfigService, BaseAction, JsonConfigItem } from '@providers';
import * as _ from 'lodash';
import { Observable } from 'rxjs';

export class GetIdentities extends BaseAction {
    readonly currentCountry = 'VN';

    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(): Observable<JsonConfigItem[]> {
        return new Observable<JsonConfigItem[]>(subscriber => {
            const defaultValues = (this.parentFormFieldConfig || this.formFieldConfig).default as string;
            if (!defaultValues) {
                subscriber.next([]);
            } else {
                const identityTypes = this.ls.getService<JsonConfigService>('jsonConfigService').getIdentityTypes();
                subscriber.next(_.cloneDeepWith(identityTypes.filter(i => (!i.country || i.country.split(',').includes(this.currentCountry)) && defaultValues.includes(i.id))));
            }
        });
    }
}
