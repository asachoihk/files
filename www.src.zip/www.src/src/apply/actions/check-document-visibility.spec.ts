import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { CheckDocumentVisibility } from './check-document-visibility';
import { InsuredModel } from '@apply/models';


class Action extends CheckDocumentVisibility {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }

    getService() {
        return new MockSupportingDocsService();
    }
}

class MockSupportingDocsService {
    getAvailableDocumentTypes() {
        return ['docType1'];
    }
}

describe('CheckDocumentVisibility', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        const params = {
            docType: 'IMPORTANT',
            defaultValue: 'defaultValue'
        };
        it('should be run', () => {
            action.viewModel = new InsuredModel();
            (action.viewModel as any).registration = {};
            action.component = {
                visibility: 'hidden'
            };
            expect(action.execute(params)).toBeDefined();
        });
    });
});
