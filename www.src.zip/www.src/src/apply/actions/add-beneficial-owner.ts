import { LocatorService, FormBuilderService, SystemEventService, AgreementAnswerMetadata, Visibility, VisibilityRefreshed, BaseAction } from '@providers';
import { ProportionListComponent } from '@shared/components';
import { ButtonComponent } from '@shared/ui-elements';
import { BeneficialOwnerListComponent } from '@apply/components';
import { BeneficialOwnerModel } from '@apply/models';

export class AddBeneficialOwner extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): any {
    const beneficialOwnerListComponentId = this.formFieldConfig.relationships[0];
    const proportionListId = this.formFieldConfig.relationships[1];

    const beneficialOwnerListComponent = this.ls.getService<FormBuilderService>('formBuilderService')
      .getComponentByFormFieldConfigId(beneficialOwnerListComponentId) as BeneficialOwnerListComponent;
    const proportionList = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(proportionListId) as ProportionListComponent;

    const metadata = beneficialOwnerListComponent.formFieldConfig.metadata as AgreementAnswerMetadata;

    if (!beneficialOwnerListComponent || (metadata && metadata.max && beneficialOwnerListComponent.dataSource.length >= metadata.max)) {
      return;
    } else {
      const dataBeneficialList = beneficialOwnerListComponent.dataSource || [];
      // dataBeneficialList = dataBeneficialList ? dataBeneficialList : [];
      const len = dataBeneficialList.length;
      const beneficialOwner = new BeneficialOwnerModel();
      if (len > 0) {
        beneficialOwner.beneficialNumber = 'Beneficial Owner ' + (len + 1);
      }

      dataBeneficialList.push(beneficialOwner);
      // beneficialOwnerListComponent.loadDataSource();
      this.ls.getService<FormBuilderService>('formBuilderService')
        .setBindingData(this.viewModel, beneficialOwnerListComponent.formFieldConfig.dataBinding.path, dataBeneficialList);

      const button = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as ButtonComponent;
      proportionList.loadDataSource(dataBeneficialList);
      if (metadata.max) {
        button.visibility = dataBeneficialList.length >= metadata.max ? Visibility.hidden : Visibility.visible;
      }
      this.ls.getService<SystemEventService>('systemEventService').publish(new VisibilityRefreshed());
    }
  }
}
