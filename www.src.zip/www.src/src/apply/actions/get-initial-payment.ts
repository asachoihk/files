import { LocatorService, FormatterService, FormBuilderService, BaseAction, CurrencyType } from '@providers';
import { ApplyModel } from '@apply/models';
import { PaymentService } from '@apply/services';

export class GetInitialPayment extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute() {
    const vm = this.viewModel as ApplyModel;
    const initialPayment = this.ls.getService<PaymentService>('paymentService').calculateInitialPayment(vm.totalPayment, vm.payment.mode);
    // const initialPayment = this.ls.getService<PaymentService>('paymentService').calculateInitialPayment(vm.totalPayment, vm.payment.mode);
    const strInitialPayment = this.ls.getService<FormatterService>('formatterService').formatCurrency(initialPayment);
    const formatCurrency = vm && vm.currency === CurrencyType.VND ? '.000 ' + vm.currency : ' ' + vm.currency;
    this.ls.getService<FormBuilderService>('formBuilderService').setFormFieldValue(this.viewModel, this.formFieldConfig, strInitialPayment + formatCurrency);
  }
}
