import { BaseAction, LocatorService, InsuredType, FormBuilderService, DialogService, AppContextService } from '@providers';
import { DialogShellComponent } from '@shared/shells';
import { TaskCardListComponent } from '@shared/components';
import { InsuredModel } from '@apply/models';
import { SupportingDocsDialogComponent } from '@apply/pages';

export class LoadSupportingDocsDialog extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute() {
        let jsonName = 'supporting-docs-owner-dialog';
        const viewModel = this.viewModel as InsuredModel;
        const type = viewModel.type;

        switch (type) {
            case InsuredType.io:
            case InsuredType.o:
                jsonName = 'supporting-docs-owner-dialog';
                break;
            case InsuredType.i:
                jsonName = 'supporting-docs-insured-dialog';
                break;
            case InsuredType.r:
                jsonName = 'supporting-docs-insured-dialog';
                break;
        }
        if (jsonName) {
            const data = {
                viewModel: viewModel,
                jsonName: jsonName
            };
            this.ls.getService<DialogService>('dialogService').showFormBuilderDialog(SupportingDocsDialogComponent, DialogShellComponent, data, _result => {
                // if (result) {
                const currentFormBuilder = this.ls.getService<AppContextService>('appContextService').currentFormBuilder;
                currentFormBuilder.refreshData(() => {

                    const taskCardList = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as TaskCardListComponent;
                    if (taskCardList) {
                        taskCardList.loadDataSource();
                    }
                });
                // }
            });
        }
    }
}
