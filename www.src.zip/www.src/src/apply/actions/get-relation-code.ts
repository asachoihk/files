import { LocatorService, JsonConfigService, BaseAction, JsonConfigItem } from '@providers';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import { TranslationService } from 'angular-l10n';

export class GetRelationCode extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Observable<JsonConfigItem[]> {
    return new Observable<JsonConfigItem[]>(subscriber => {
      const relationCode = this.ls.getService<JsonConfigService>('jsonConfigService').getRelationCode();
      for (let i = 0; i < relationCode.length; i++) {
        relationCode[i].value = this.ls.get(TranslationService).translate(relationCode[i].value);
      }
      subscriber.next(_.cloneDeepWith(relationCode));
    });
  }
}
