import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { FormBuilderService } from 'providers/services/form-builder/form-builder.service';
import { CheckApplicationChanges } from './check-application-changes';
import { MatDialogRef } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import 'rxjs/add/observable/of';

class Action extends CheckApplicationChanges {
    constructor(public ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    get() {
        return new MockTranslationService();
    }

    getService(serviceName: string): any {
        switch (serviceName) {
            case 'appContextService':
                return new MockAppContextService();
            case 'dialogService':
                return new MockDialogService();
            case 'globalNavigationService':
                return new MockGlobalNavigationService();
            case 'insuredPersonService':
                return new MockInsuredPersonService();
            case 'ActionService':
                return new MockActionService();
            default:
                break;
        }
    }
}

class MockTranslationService {
    translate() {
        return 'abc';
    }
}

class MockActionService {
    executeAction(actionName, context, callback) {
        return callback;
    }
}

class MockInsuredPersonService {
    filterBeneficiaries() {
        return null;
    }
}

class MockDialogService {
    open() {
        return { afterClosed: () => Observable.of({}) };
    }

    close() {
        return true;
    }

    showCustomDialog(component, dialogConfig, callback) {
        return callback({
            action: 'yes'
        });
    }
}

class MockGlobalNavigationService {
    navigateTo(url) {
        return url;
    }
}

class MockAppContextService {
    currentFormBuilder = {
        hasChanges: true,
        id: 'signature'
    };
}

class MockMatDialogRef {

    open() {
        return { afterClosed: () => Observable.of({}) };
    }

    close() {
        return true;
    }
}

describe('CheckApplicationChanges', () => {
    let action: Action;
    let ls;
    let dialog;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: MatDialogRef, useClass: MockMatDialogRef }
            ],
        });
        ls = TestBed.get(LocatorService);
        dialog = TestBed.get(MatDialogRef);
    });
    beforeEach(() => {
        action = new Action(ls);
        action.dialogRef = dialog;
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        const params = {
            url: '/test',
            confirmMessage: 'MSGO25',
            autoSave: true
        };
        it('should be run', () => {
            expect(action.execute(params)).toBeFalsy();
        });

        it('should be return currentPage = basic-info ', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                currentFormBuilder: {
                    hasChanges: true,
                    id: 'basic-info'
                },
                filterBeneficiaries() {
                    return null;
                },
                executeAction(actionName, context, callback) {
                    return { context, callback };
                }
            });
            action.execute(params);
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be return currentPage = agreement, dialog answer = yes', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                currentFormBuilder: {
                    hasChanges: true,
                    id: 'agreement'
                },
                filterBeneficiaries() {
                    return null;
                },
                executeAction(actionName, context, callback) {
                    return { context, callback };
                },
                showCustomDialog(component, dialogConfig, callback) {
                    return callback({
                        action: 'yes'
                    });
                }
            });
            action.execute({
                url: '/test',
                confirmMessage: 'MSGO25',
                autoSave: false
            });
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be return currentPage = agreement, dialog answer = no', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                currentFormBuilder: {
                    hasChanges: true,
                    id: 'agreement'
                },
                filterBeneficiaries() {
                    return null;
                },
                executeAction(actionName, context, callback) {
                    return { context, callback };
                },
                showCustomDialog(component, dialogConfig, callback) {
                    return callback({
                        action: 'no'
                    });
                },
                navigateTo() {
                    return ('/application');
                }
            });
            action.execute({
                url: '/test',
                confirmMessage: 'MSGO25',
                autoSave: false
            });
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be return hasChanges = false', () => {
            spyOn(action.ls, 'getService').and.returnValue({
                currentFormBuilder: {
                    hasChanges: false,
                    id: 'agreement'
                },
                filterBeneficiaries() {
                    return null;
                },
                executeAction(actionName, context, callback) {
                    return { context, callback };
                },
                showCustomDialog(component, dialogConfig, callback) {
                    return callback({
                        action: 'no'
                    });
                },
                navigateTo() {
                    return ('/application');
                }
            });
            action.execute({
                url: '/test',
                confirmMessage: 'MSGO25',
                autoSave: false
            });
            expect(action.ls.getService).toHaveBeenCalled();
        });

    });
});
