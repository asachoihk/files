import { LocatorService, BaseAction } from '@providers';

export class SetIssuePlace extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(_params: any): void {
        // return this.ls.getAction('getIssuePlaces').execute.call(this, _params);
    }
}
