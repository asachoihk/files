import { LocatorService, DialogService, CustomDialogActionType, FormBuilderService, CustomDialogResult, ActionService, BaseAction, AppContextService } from '@providers';
import { TranslationService } from 'angular-l10n';
import { CustomDialogComponent, DataSourceComponent } from '@shared/ui-elements';
import { ProportionListComponent, TaskCardListComponent } from '@shared/components';

export class DeleteBeneficiary extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    this.$event.preventDefault();
    this.$event.stopPropagation();
    const dialogConfig = {
      data: {
        message: this.ls.get(TranslationService).translate('MSGA044'),
        buttons: [
          { title: 'no', type: 'red-outline', action: CustomDialogActionType.no },
          { title: 'yes', type: 'red', action: CustomDialogActionType.yes }
        ]
      }
    };
    this.ls.getService<DialogService>('dialogService').showCustomDialog(CustomDialogComponent, dialogConfig, (result: CustomDialogResult) => {
      if (result.action === CustomDialogActionType.yes) {
        this.resetErrors();
        const currentFormBuilder = this.ls.getService<AppContextService>('appContextService').currentFormBuilder;
        const actionParams = this.ls.getService<ActionService>('actionService').createActionParams(this, { isDelete: true });
        const resultSave = this.ls.getAction('saveBeneficiaryPerson').invoke(actionParams);
        this.ls.getService<ActionService>('actionService').retreiveActionResult(resultSave, () => {
          currentFormBuilder.refreshData(() => {
            const beneficiaryPersons = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.parentFormFieldConfig) as TaskCardListComponent;
            if (beneficiaryPersons instanceof TaskCardListComponent) {
              // beneficiaryPersons.loadDataSource();

              if (this.parentFormFieldConfig.relationships) {
                this.parentFormFieldConfig.relationships.forEach(fieldId => {
                  const component = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(fieldId) as DataSourceComponent;
                  component.loadDataSource();
                });
              }
            }

            const actionParamsCheck = this.ls.getService<ActionService>('actionService').createActionParams(this, params);
            this.ls.getAction('checkAvailable').invoke(actionParamsCheck);
          });
        });
      }
    });
  }

  private resetErrors() {
    if (this.parentFormFieldConfig.relationships) {
      this.parentFormFieldConfig.relationships.forEach(fieldId => {
        const component = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(fieldId);
        if (component instanceof ProportionListComponent) {
          (component as ProportionListComponent).resetError();
        }
      });
    }
  }
}
