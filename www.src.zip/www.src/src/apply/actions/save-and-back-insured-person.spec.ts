
import { TestBed, async } from '@angular/core/testing';
import { LocatorService, AppContextService, CustomerService, GlobalNavigationService, FormBuilderService, Visibility } from '@providers';
import { ActivatedRoute } from '@angular/router';
import { ApplicationService, ProgressService, SaveDocumentsService, InsuredPersonService, AddressService } from '@apply/services';
import { ApplyModel, InsuredModel } from '@apply/models';
import { of, Observable } from 'rxjs';
import { SaveAndBackInsuredPerson } from './save-and-back-insured-person';
import { BaseControlComponent } from '@shared/ui-elements';
import { MatDialogRef } from '@angular/material';

class Action extends SaveAndBackInsuredPerson {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}


class MockFormBuilderService {
  constructor() { }

  markFormTouched(formId) {

  }
}

class MockGlobalNavigationService {
  constructor() { }

  getCurrentNavigationPage() {
    return {
      checkChanges: 'checkApplicationChanges',
      id: 'payment',
      isBreadscrumbItem: true,
      isLeftNavigationItem: true,
      label: 'basicInformation',
      labelAction: 'getCurrentApplicationName'
    };
  }

  getLeftNavigationItems() {
    return [
      { id: 'payment' },
      { id: 'disclosure' }
    ];
  }

  navigateTo() {

  }
}

class MockCustomerService {
  constructor() { }

  getCurrent() {
    return {
      customerId: ''
    };
  }
}

class MockSaveDocumentsService {
  constructor() { }

  saveDocumentInsured(insuredPerson, currentSectionName): Observable<any[]> {
    return new Observable(subscriber => {
      return subscriber.next([{}]);
    });
  }
}

class MockProgressService {
  constructor() { }

  publish() {
    return of({});
  }

  updateSectionProgress() {

  }

  calculateCurrentInsuredPersonProgress() {

  }

  updateInsuredPersonProgress() { }
}

class MockApplicationService {
  constructor() { }

  saveApplyData(customerId: string, applyModels: ApplyModel[], isAddNew?: boolean): Observable<any[]> {
    return new Observable(subscriber => {
      return subscriber.next([{}]);
    });
  }
}

class MockAppContextService {
  constructor() { }
  appContext = { currentPage: { viewModel: {} } };
  currentFormBuilder = { id: 'signature' };
}

class MockActivatedRoute {
  constructor() { }

  snapshot = {
    queryParams: {
      applicationId: '18072433-c834-755a-9372-6826ef99f9fb',
      customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab'
    }
  };
}

class MockInsuredPersonService {
  constructor() { }

  updateInsuredPersonToApplication(clonedInsuredPerson, applyData) { }

  updateBeneficiaryOwner(applyData) { }
}

class MockAddressService {
  constructor() { }

  checkAndCascadeInsuredAddress(clonedInsuredPerson, applyData) { }
}

class MockValidatorService {
  constructor() { }

  validateForm() { }
}

class MockMatDialogRef {
  close() {
    return true;
  }
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'globalNavigationService':
        return new MockGlobalNavigationService();
      case 'customerService':
        return new MockCustomerService();
      case 'progressService':
        return new MockProgressService();
      case 'applicationService':
        return new MockApplicationService();
      case 'appContextService':
        return new MockAppContextService();
      case 'saveDocumentsService':
        return new MockSaveDocumentsService();
      case 'insuredPersonService':
        return new MockInsuredPersonService();
      case 'addressService':
        return new MockAddressService();
      case 'validatorService':
        return new MockValidatorService();
      default:
        break;
    }
  }

  get() {
    return new MockActivatedRoute();
  }
}

describe('SaveAndBackInsuredPerson', () => {
  let action: Action;
  let ls: LocatorService;
  let dialogRef: any;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService },
        { provide: GlobalNavigationService, useClass: MockGlobalNavigationService },
        { provide: CustomerService, useClass: MockCustomerService },
        { provide: ProgressService, useClass: MockProgressService },
        { provide: ApplicationService, useClass: MockApplicationService },
        { provide: AppContextService, useClass: MockAppContextService },
        { provide: ActivatedRoute, useClass: MockActivatedRoute },
        { provide: SaveDocumentsService, useClass: MockSaveDocumentsService },
        { provide: InsuredPersonService, useClass: MockInsuredPersonService },
        { provide: AddressService, useClass: MockAddressService },
        { provide: MatDialogRef, useClass: MockMatDialogRef }
      ],
    });
    ls = TestBed.get(LocatorService);
    dialogRef = TestBed.get(MatDialogRef);
  });

  beforeEach(() => {
    action = new Action(ls);
    action.dialogRef = dialogRef;
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run when saveDocumentInsured has data', async(
      () => {
        action.actionParams = { params: { onlySave: true, groups: ['identity'] } };
        spyOn(action.ls, 'getService').and.returnValue({
          currentFormBuilder: { id: 'signature' },
          appContext: { currentPage: { viewModel: {} } },
          validateForm() { },
          updateBeneficiaryOwner(applyData) { },
          updateInsuredPersonProgress() { },
          checkAndCascadeInsuredAddress(clonedInsuredPerson, applyData) { },
          updateInsuredPersonToApplication(clonedInsuredPerson, applyData) { },
          calculateCurrentInsuredPersonProgress() {
          },
          saveDocumentInsured() {
            return of({
              uploadFileSuccess: true,
              insuredPerson: {
                id: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab'
              } as InsuredModel
            });
          },
          saveApplyData(customerId: string, applyModels: ApplyModel[], isAddNew?: boolean): Observable<any[]> {
            return new Observable(subscriber => {
              return subscriber.next([{}]);
            });
          },
          getCurrentNavigationPage() {
            return {
              checkChanges: 'checkApplicationChanges',
              id: 'payment',
              isBreadscrumbItem: true,
              isLeftNavigationItem: true,
              label: 'basicInformation',
              labelAction: 'getCurrentApplicationName'
            };
          },
          getLeftNavigationItems() {
            return [
              { id: 'payment' },
              { id: 'disclosure' }
            ];
          },
          getCurrent() {
            return {
              customerId: ''
            };
          },
          markFormTouched(formId) {

          }
        });
        const insuredModel = new InsuredModel();
        insuredModel.documents = [];
        action.viewModel = insuredModel;
        expect(action.execute().subscribe());

      }
    ));

    it('should be run when saveDocumentInsured empty', async(
      () => {
        action.actionParams = { params: { onlySave: false, groups: ['identity'] } };
        spyOn(action.ls, 'getService').and.returnValue({
          currentFormBuilder: { id: 'signature' },
          appContext: { currentPage: { viewModel: {} } },
          validateForm() { },
          updateBeneficiaryOwner(applyData) { },
          updateInsuredPersonProgress() { },
          checkAndCascadeInsuredAddress(clonedInsuredPerson, applyData) { },
          updateInsuredPersonToApplication(clonedInsuredPerson, applyData) { },
          calculateCurrentInsuredPersonProgress() {
          },
          saveApplyData(customerId: string, applyModels: ApplyModel[], isAddNew?: boolean): Observable<any[]> {
            return new Observable(subscriber => {
              return subscriber.next([{}]);
            });
          },
          saveDocumentInsured() {
            return new Observable(subscriber => {
              return subscriber.next([{}]);
            });
          },
          getCurrentNavigationPage() {
            return {
              checkChanges: 'checkApplicationChanges',
              id: 'payment',
              isBreadscrumbItem: true,
              isLeftNavigationItem: true,
              label: 'basicInformation',
              labelAction: 'getCurrentApplicationName'
            };
          },
          getLeftNavigationItems() {
            return [
              { id: 'payment' },
              { id: 'disclosure' }
            ];
          },
          getCurrent() {
            return {
              customerId: ''
            };
          },
          markFormTouched(formId) {

          }
        });
        const insuredModel = new InsuredModel();
        insuredModel.documents = [];
        action.viewModel = insuredModel;
        expect(action.execute().subscribe());

      }
    ));

    it('should be run for ignoreValidationResult function', () => {
      expect(action.ignoreValidationResult()).toBeTruthy();
    });

    it('should be run for validateForm function', () => {
      action.actionParams = { params: { onlySave: true } };
      const insuredModel = new InsuredModel();
      insuredModel.documents = [];
      action.viewModel = insuredModel;
      expect(action.validateForm('1234', action.actionParams)).toBeFalsy();
    });

    it('should be run for shouldValidate function', () => {
      const params = {
        formControl: {
          status: 'ENABLE'
        },
        visibility: Visibility.visible
      } as BaseControlComponent;
      expect(action.shouldValidate(params)).toBeTruthy();
    });
  });
});
