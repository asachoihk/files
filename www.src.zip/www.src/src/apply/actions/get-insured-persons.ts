import { LocatorService, InsuredType, BaseAction } from '@providers';
import { ApplyModel, InsuredModel } from '@apply/models';
import { InsuredPersonService } from '@apply/services';
import { ApplySection } from '@apply/const';

export class GetInsuredPersons extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params?: any): any[] {
        let applyData = this.viewModel as ApplyModel;
        if (params && params['applyData']) {
            applyData = params['applyData'] as ApplyModel;
        }
        const insuredPeople = this.ls.getService<InsuredPersonService>('insuredPersonService').getInsuredPersons(applyData) as InsuredModel[];
        if (params && params['section'] === ApplySection.DISCLOSURE) {
            if (applyData.insured.type !== InsuredType.io) {
                // if PO has no rider, do not show its task card
                const poId = applyData.owner.id;
                const poHasRider = applyData.riders.some(r => r.insuredId === poId);
                if (!poHasRider) {
                    return insuredPeople.filter(i => i.id !== poId);
                }
            }

        }
        return insuredPeople;
    }
}
