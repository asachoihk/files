import { LocatorService, BaseAction, FormBuilderService, SystemEventService, Visibility, AppContextService, ViewMode, StepStatus, ViewModeChanged } from '@providers';
import { StepperComponent } from '@shared/ui-elements';
import { ApplyModel } from '@apply/models';
import { ApplicationService } from '@apply/services';

export class CheckReviewButtonStatus extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params: any): Visibility {
        const viewModel = this.ls.getService<AppContextService>('appContextService').currentFormBuilder.viewModel;
        const currentMode = this.ls.getService<AppContextService>('appContextService').appContext.viewMode || ViewMode.normal;
        if (params.mode !== ViewMode[currentMode]) {
            return Visibility.hidden;
        }

        if (this.ls.getService<ApplicationService>('applicationService').isApplicationReadOnlyMode()) {
            return Visibility.hidden;
        }

        let result = Visibility.visible;
        const stepper = this.ls.getService<AppContextService>('appContextService').appContext.stepper as StepperComponent;

        if (stepper) {
            result = stepper.steps.every(s => s.status === StepStatus[StepStatus.completed]) ? Visibility.hidden : Visibility.visible;
        } else if (viewModel as ApplyModel) {
            const applyModel = viewModel as ApplyModel;

            if (!applyModel.payment || !params.requiredFields) {
                result = Visibility.visible;
            } else {
                const allRequiredFieldValid = (params.requiredFields as string[]).every(path => !!this.ls.getService<FormBuilderService>('formBuilderService').getBindingData(applyModel, path));
                result = allRequiredFieldValid ? Visibility.hidden : Visibility.visible;
            }
        }

        if (result === Visibility.hidden) {
            this.ls.getService<SystemEventService>('systemEventService').publish(new ViewModeChanged(ViewMode.normal));
        }

        return result;
    }
}
