import { DocumentType } from 'providers/enums/document-type.enum';
import { LocatorService, BaseAction, Visibility, ID_TYPE } from '@providers';
import { BaseUiElement } from '@shared/ui-elements';
import { InsuredModel, RegistrationModel } from '@apply/models';
import { SupportingDocsService } from '@apply/services';

export class CheckDocumentVisibility extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    const insuredPerson = this.viewModel as InsuredModel;
    const docType = params ? params['docType'] : DocumentType.IMPORTANT;
    const defaultValue = params ? params['defaultValue'] : ID_TYPE.ID;
    const availableDocTypes = this.ls.getService<SupportingDocsService>('supportingDocsService').getAvailableDocumentTypes(insuredPerson);

    if (docType === DocumentType.IMPORTANT && (!insuredPerson.person.registration || !insuredPerson.person.registration.idType)) {
      const registration = new RegistrationModel();
      registration.idType = defaultValue;
      insuredPerson.person.registrations = [registration];
    }

    if (!availableDocTypes.includes(docType)) {
      (this.component as BaseUiElement).visibility = Visibility.hidden;
    }

    return (this.component as BaseUiElement).visibility;
  }

}
