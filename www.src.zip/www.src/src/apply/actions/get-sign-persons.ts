import { LocatorService, BaseAction } from '@providers';
import { SignatureModel, ApplyModel } from '@apply/models';
import { SignatureType } from '@apply/enums';

export class GetSignPersons extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(): SignatureModel[] {
        const applyData = this.viewModel as ApplyModel;
        const signPersons = applyData.signatures ? applyData.signatures : [];
        if (signPersons && signPersons.length > 0) {
            return signPersons;
        }

        const agent = new SignatureModel();
        agent.id = applyData.agent.agentId;
        agent.type = SignatureType.agent;
        agent.fullName = applyData.agent.firstName + ' ' + (applyData.agent.middleName ? applyData.agent.middleName + ' ' : '') + applyData.agent.lastName;
        signPersons.push(agent);

        const owner = new SignatureModel();
        owner.id = applyData.owner.id;
        owner.type = SignatureType.owner;
        owner.fullName = applyData.owner.person.basicInfo.fullName;
        signPersons.push(owner);

        if (applyData.insured && applyData.insured.id !== applyData.owner.id && applyData.insured.person.basicInfo.age >= 18) {
            const insured = new SignatureModel();
            insured.id = applyData.insured.id;
            insured.type = SignatureType.insured;
            insured.fullName = applyData.insured.person.basicInfo.fullName;
            signPersons.push(insured);
        }

        if (applyData.dependents) {
            applyData.dependents.forEach(result => {
                if (result.person.basicInfo.age >= 18) {
                    const dependent = new SignatureModel();
                    dependent.id = result.id;
                    dependent.type = SignatureType.other;
                    dependent.fullName = result.person.basicInfo.fullName;
                    signPersons.push(dependent);
                }
            });
        }
        applyData.signatures = signPersons as SignatureModel[];

        return signPersons;
    }
}
