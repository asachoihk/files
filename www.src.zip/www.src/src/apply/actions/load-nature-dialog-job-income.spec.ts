import { LocatorService } from '@providers';
import { TestBed } from '@angular/core/testing';
import { TranslationService } from 'angular-l10n';
import { LoadNatureDialogJobIncome } from './load-nature-dialog-job-income';

class Action extends LoadNatureDialogJobIncome {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService() {
        return new MockFormBuilderService();
    }

    get() {
        return new MockTranslationService();
    }
}

class MockTranslationService {
    translate() {
        return 'translated text';
    }
}

class MockFormBuilderService {
    setFormFieldValue() {
        return {};
    }
}

describe('LoadNatureDialogJobIncome', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: TranslationService, useClass: MockTranslationService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - getDialogData', () => {
        it('should be run', () => {
            action.viewModel = {
                notifyValueChanges() {
                    return {};
                }
            } as any;
            action.parentFormFieldConfig = {} as any;
            action.formFieldConfig = {
                dataSourceMetadata: {}
            } as any;
            expect(action.getDialogData()).toEqual({
                viewModel: action.viewModel,
                formFieldConfig: action.parentFormFieldConfig,
                params: {
                    componentParams: {
                        header: 'Nature of Business',
                        dataSource: {
                            actionName: 'getNatureOfBusiness'
                        },
                        dataSourceMetadata: action.formFieldConfig.dataSourceMetadata
                    }
                }
            });
        });
    });

    describe('Function - handleSearchListDialogClosed', () => {
        it('should be run', () => {
            const result = {
                transId: 'abc'
            };
            action.viewModel = {
                notifyValueChanges() {
                    return {};
                }
            } as any;
            action.parentFormFieldConfig = {} as any;
            action.formFieldConfig = {
                dataSourceMetadata: {},
                label: ''
            } as any;
            action.handleSearchListDialogClosed(result);
            spyOn(action.ls, 'getService').and.callThrough();
            expect(action.ls.getService).toBeTruthy();
        });
    });
});