import { LocatorService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import { GetPhoneDataByType } from './get-phone-data-by-type';

class Action extends GetPhoneDataByType {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockFormBuilderService {
  constructor() { }

  getComponentByFormFieldConfigId(): any { return { }; }

  setBindingData(): void { }
  getBindingData(): Array<any> { return null; }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      default:
        break;
    }
  }
}

describe('GetPhoneDataByType', () => {
  let action: Action;
  const formFieldConfig = {
    id: 'businessPhoneNumber',
    type: 'phone',
    dataBinding: { path: 'phone'},
    metadata: {
      type: 'business'
    }
  };
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      action.formFieldConfig = formFieldConfig;
      expect(action.execute()).toBeDefined();
    });
  });
});
