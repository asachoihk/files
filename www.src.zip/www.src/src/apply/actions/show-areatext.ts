import { LocatorService, FormBuilderService, BaseAction, Visibility } from '@providers';
import { TextAreaComponent } from '@shared/ui-elements';
import { ApplyModel } from '@apply/models';

export class ShowAreatext extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    const questionId = this.formFieldConfig.relationships[0];
    const answerComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(questionId) as TextAreaComponent;
    const questionModel = this.viewModel as ApplyModel;
    if (params === 'defaultVal' && !(questionModel.declaration_answer && questionModel.declaration_answer.agent_question)) {
      this.ls.getService<FormBuilderService>('formBuilderService').setBindingData(this.viewModel, this.formFieldConfig.dataBinding.path, 'N');
      questionModel.notifyValueChanges(this.formFieldConfig);
      return;
    }
    if (!params) {
      const val = this.$event.value;
      if (val === 'Y') {
        this.ls.getService<FormBuilderService>('formBuilderService').setBindingData(this.viewModel, answerComponent.formFieldConfig.dataBinding.path, '');
        questionModel.notifyValueChanges(answerComponent.formFieldConfig);
        if (answerComponent) {
          answerComponent.visibility = Visibility.visible;
        }
      } else {
        if (answerComponent) {
          answerComponent.visibility = Visibility.collapsed;
        }
      }
    } else {
      const question = questionModel.declaration_answer.agent_question || '';
      if (question === '' || question === 'N') {
        if (answerComponent) {
          answerComponent.visibility = Visibility.collapsed;
        }
      }
    }
  }
}
