import { Injectable } from '@angular/core';
import { LocatorService, ActionService, SystemEventService, BaseAction, ComponentNotified, VisibilityRefreshed, ToolbarActionsChanged, APPLICATION_STATUS } from '@providers';
import { Observable } from 'rxjs';
import { ApplyModel } from '@apply/models';

@Injectable()
export class NavigatePaymentGateway extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Observable<any> {
    return new Observable(subscriber => {
      const applyModel = this.viewModel as ApplyModel;
      const answer = (applyModel.declaration_answer.agent_answer || '').toUpperCase();

      if (applyModel.status === APPLICATION_STATUS.PAYMENT_PENDING) {
        this.ls.getService<ActionService>('actionService').executeAction('navigateApplicationResult', this, { applicationStatus: APPLICATION_STATUS.SUBMITTED, saveDocumentInsured: true }, () => {
          subscriber.next();
        });
      } else {
        const nextStatus = (applyModel.declaration_answer.agent_question === 'Y' && answer === 'PAYMENTONLINEFAILED')
          ? APPLICATION_STATUS.PAYMENT_PENDING
          : APPLICATION_STATUS.SUBMITTED;
        this.ls.getService<ActionService>('actionService').executeAction('navigateApplicationResult', this, { applicationStatus: nextStatus }, () => {
          if (nextStatus === APPLICATION_STATUS.PAYMENT_PENDING) {
            this.ls.getService<SystemEventService>('systemEventService').publish(new ComponentNotified('preconditionForPayment'));
            this.ls.getService<SystemEventService>('systemEventService').publish(new VisibilityRefreshed());
            this.ls.getService<SystemEventService>('systemEventService').publish(new ToolbarActionsChanged());
          }
          subscriber.next();
        });
      }
    });
  }
}
