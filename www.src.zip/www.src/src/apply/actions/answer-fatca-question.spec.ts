import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { FormBuilderService } from 'providers/services/form-builder/form-builder.service';
import { of } from 'rxjs/internal/observable/of';
import { FormControl } from '@angular/forms';
import { InsuredModel } from '@apply/models';
import { AnswerFatcaQuestion } from './answer-fatca-question';

class Action extends AnswerFatcaQuestion {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    get(): MockFormBuilderService {
        return new MockFormBuilderService();
    }

    getService(serviceName: string): any {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        } else if (serviceName === 'systemEventService') {
            return new MockSystemEventService();
        }
        return new MockActionService();
    }
}

class MockSystemEventService {
    publish() {
        return of({});
    }
}

class MockActionService {
    createActionParams() {
        return {};
    }
}

class MockFormBuilderService {
    constructor() { }
    get() {
        return null;
    }

    getComponentByFormFieldConfig() {
        return {
            loadAnswerComponent() {
                return null;
            },
            reset() {
                return null;
            }
        };
    }

    deleteFieldComponentMapItemsByFormFieldConfigId() {
        return null;
    }

    deleteFieldComponentMapItemsByParentFormFieldConfigId() {
        return null;
    }
}

describe('AnswerFatcaQuestion', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        const params = {
            answer: 'Y',
        };
        it('should be run with answer = "Y"', () => {
            action.$event = {
                value: 'Y'
            };
            action.viewModel = new InsuredModel();
            expect(action.execute({ answer: 'Y' })).toBeFalsy();
        });
        it('should be run with answer = "N"', () => {
            action.$event = {
                value: 'Y'
            };
            action.viewModel = new InsuredModel();
            expect(action.execute({ answer: 'N' })).toBeFalsy();
        });
    });
});
