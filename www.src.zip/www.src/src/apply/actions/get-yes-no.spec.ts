import { LocatorService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import { GetYesNo } from './get-yes-no';

class Action extends GetYesNo {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockLocatorService { }

describe('GetYesNo', () => {
  let action: Action;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      expect(action.execute({})).toBeDefined();
    });
  });
});
