import { TranslationService } from 'angular-l10n';
import { CustomDialogActionType, DialogService, CustomDialogResult, CustomerService, FormBuilderService, BaseAction } from '@providers';
import { CustomDialogComponent, TableComponent, SearchBarComponent } from '@shared/ui-elements';
import { ApplicationService } from '@apply/services';

export class DeleteApplication extends BaseAction {
    execute(params: any): void {
        if (params && params.selectedId) {
            const applicationId = params.selectedId;
            const dialogConfig = {
                disableClose: true,
                data: {
                    message: this.ls.get(TranslationService).translate('MSGA058'),
                    buttons: [
                        { title: 'no', type: 'red-outline', action: CustomDialogActionType.no },
                        { title: 'yes', type: 'red', action: CustomDialogActionType.yes }
                    ]
                }
            };
            this.ls.getService<DialogService>('dialogService').showCustomDialog(CustomDialogComponent, dialogConfig, (result: CustomDialogResult) => {
                if (result.action === CustomDialogActionType.yes) {
                    const customerId = this.ls.getService<CustomerService>('customerService').getCurrent().customerId;
                    this.ls.getService<ApplicationService>('applicationService').deleteApplication(customerId, [applicationId]).subscribe(() => {
                        const searchComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('searchBar') as SearchBarComponent;
                        const tableComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as TableComponent;
                        if (tableComponent && searchComponent) {
                            tableComponent.loadDataSource(searchComponent.textSearch, [applicationId]);
                        }
                    });
                }
            });
        }
    }
}
