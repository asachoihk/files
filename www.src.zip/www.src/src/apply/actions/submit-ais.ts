import { LocatorService, ActionService, GlobalNavigationService, CustomerService, SaveAction, APPLICATION_STATUS } from '@providers';
import { Observable } from 'rxjs';
import { TranslationService } from 'angular-l10n';
import { ActivatedRoute } from '@angular/router';
import { ApplyModel } from '@apply/models';
import { ApplicationService } from '@apply/services';
import { PaymentMethod } from '@apply/enums';

export class SubmitAis extends SaveAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(): Observable<any> {
        return new Observable(subscriber => {
            const applyData = this.viewModel as ApplyModel;
            const declarationAnswer = applyData.declaration_answer;
            const answer = (declarationAnswer.agent_answer || '').toUpperCase();
            let message = '';

            if (declarationAnswer.agent_question === 'Y' && !this.ls.getService<GlobalNavigationService>('globalNavigationService').getPreviousPageData()) {
                if (answer === 'MSGA042A' || answer === 'MSGA042B' || answer === 'MSGA042C') {
                    message = this.ls.get(TranslationService).translate(answer);
                }
            }

            if (message) {
                const customerId = this.ls.get(ActivatedRoute).snapshot.queryParams.customerId || this.ls.getService<CustomerService>('customerService').getCurrent().customerId;
                this.ls.getService<ApplicationService>('applicationService').saveApplyData(customerId, [applyData]).subscribe(() => {
                    const queryParams = { previousData: { message: message, context: this, previousAction: 'submitAis' } };
                    this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission/retry', queryParams);
                    subscriber.next();
                });
            } else {
                const hasOnlinePayment = applyData.payment.method === PaymentMethod.ONLINE.toString();
                const params = { applicationStatus: hasOnlinePayment ? APPLICATION_STATUS.SUBMISSION_AGENT_QUESTION : APPLICATION_STATUS.SUBMITTED };
                this.ls.getService<ActionService>('actionService').executeAction('navigateApplicationResult', this, params, () => {
                    subscriber.next();
                });
            }
        });
    }

    validateForm(formId, actionParams) {
        const applyData = this.viewModel as ApplyModel;
        return applyData.declaration_answer.agent_question === 'N' ? true : super.validateForm(formId, actionParams);
    }
}
