import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { BeneficiaryModel } from '@apply/models';
import { CheckOwnerBeneficiary } from './check-owner-beneficiary';

class Action extends CheckOwnerBeneficiary {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }

    getService(serviceName) {
        return serviceName === 'appContextService' ? new MockAppContextService() : new MockFormBuilderService();
    }
}

class MockAppContextService {
    appContext = {
        currentPage: {
            applyData: {
                owner: {
                    id: '1'
                }
            }
        }
    };
}

class MockFormBuilderService {
    getComponentByFormFieldConfigId() {
        return {
            visibility: 'hidden'
        };
    }
}

describe('CheckOwnerBeneficiary', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            action.parentViewModel = new BeneficiaryModel();
            action.formFieldConfig = { id: 'proceedSignature', type: 'button', label: 'Proceed_Signature' };
            (action.parentViewModel as any ) = {
                guid: '1',
            };
            expect(action.execute()).toBeFalsy();
        });
    });
});
