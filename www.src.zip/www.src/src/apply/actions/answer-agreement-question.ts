import { BaseAction, LocatorService, FormBuilderService, ActionService } from '@providers';
import { QuestionairePanelComponent } from '@shared/ui-elements';
import { InsuredModel, AgreementModel, InsuranceModel } from '@apply/models';

export class AnswerAgreementQuestion extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute(params: any) {
        const questionairePanel = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as QuestionairePanelComponent;
        const answer = this.$event.value;
        if (questionairePanel && answer) {
            const answerConfigured = params.answer;
            const viewModel = this.viewModel as InsuredModel;
            const agreement = viewModel.agreement as AgreementModel;
            if (answerConfigured === answer && questionairePanel) {
                const insurance = new InsuranceModel();
                agreement.insurance = [];
                agreement.insurance.push(insurance);
                const actionParams = this.ls.getService<ActionService>('actionService').createActionParams(this);
                questionairePanel.loadAnswerComponent('replacementForm', actionParams);
            } else {
                agreement.insurance = [];
                questionairePanel.reset();
                this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfigId('replacementForm');
                this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByFormFieldConfigId('agreementInsurances');
                this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByParentFormFieldConfigId('agreementInsurances');
                this.ls.getService<FormBuilderService>('formBuilderService').deleteFieldComponentMapItemsByParentFormFieldConfigId('replacementQuestion', ['button']);
            }
        }
    }
}

