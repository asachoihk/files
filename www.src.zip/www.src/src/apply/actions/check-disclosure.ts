import { BaseAction, LocatorService, FormBuilderService, Visibility, AppContextService } from '@providers';
import { ApplyModel, InsuredModel, UnderwritingModel } from '@apply/models';


export class CheckDisclosure extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Visibility {
    const component = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig);
    // const vm = this.ls.getService<AppContextService>('appContextService').appContext.currentPage.viewModel as ApplyModel;
    const insuredModel = this.viewModel as InsuredModel;
    const uwDetails = insuredModel.uwDetails as UnderwritingModel;
    const answers = uwDetails.answers;
    if (answers && component) {
      answers.forEach(item => {
        if (item.answer) {
          component.visibility = Visibility.disabled;
        }
      });
    } else {
      return component.visibility;
    }
  }
}
