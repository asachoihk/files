import { LocatorService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import { GetReportList } from './get-report-list';
import { of } from 'rxjs';
import { ApplyModel } from '@apply/models';

class Action extends GetReportList {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockFormBuilderService {
  getComponentByFormFieldConfigId(): any { return [{ showPrecondition: '' }]; }
}

class MockReportSignatureService {
  initFNAForm() { return of({}); }
  initProposalForm() { return of({}); }
  initLifeInsuranceApplicationForm() { return of({}); }
  initOthersInsuredForm() { }
  initEDisclosureForms() { }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      default:
        break;
    }
  }

  get(service) {
    if (service.name === 'ReportSignatureService') {
      return new MockReportSignatureService();
    }
  }
}

describe('GetReportList', () => {
  let action: Action;
  let ls: LocatorService;

  const viewModel = {
    proposalId: 'proposalId',
    report_forms: [{header: 'a'}, {header: 'b'}],
    original_report_forms: [{}],
    owner: {
      id: '123',
      uwDetails: {},
      person: {},
      agreement: {}
    },
    insured: {
      id: '123',
      documents: [
        {
          type: 'abc'
        }
      ]
    },
    dependents: []
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run with fnaReportGeneratedDate', () => {
      viewModel['fnaReportGeneratedDate'] = '2019-06-27T07:52:50.352Z';
      viewModel['report_forms'] = [{header: 'a'}, {header: 'b'}];
      action.viewModel = viewModel as ApplyModel;
      action.execute().subscribe(result => {
        expect(result).toBeDefined();
      });
    });

    it('should be run with precondition', () => {
      spyOn( action.ls, 'getService' ).and.returnValue({
        getComponentByFormFieldConfigId(precondition) {
          if (precondition === 'precondition') {
            return { showPrecondition: true };
          }
        }
      });

      action.execute().subscribe(result => {
        expect(result).toBeDefined();
      });
    });

    it('should be run without report_forms', () => {
      viewModel['fnaReportGeneratedDate'] = '2019-06-27T07:52:50.352Z';
      viewModel['report_forms'] = [];
      action.viewModel = viewModel as ApplyModel;

      action.execute().subscribe(result => {
        expect(result).toBeDefined();
      });
    });
  });
});
