import { BaseAction, LocatorService, JsonConfigService } from '@providers';
import { PaymentService } from '@apply/services/payment/payment-service';
import { ApplyModel } from '@apply/models';

export class GetPaymentMethod extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    const vm = this.viewModel as ApplyModel;
    const initialPayment = this.ls.getService<PaymentService>('paymentService').calculateInitialPayment(vm.totalPayment, vm.payment.method);
    let paymentMethods = this.ls.getService<JsonConfigService>('jsonConfigService').getInitialPaymentMethod();
    const exclude = (params['exclude'] || []) as string[];
    paymentMethods = paymentMethods.filter(p => !exclude.includes(p.value));

    if (initialPayment < params['cashPaymentLimit']) {
      return paymentMethods;
    } else {
      return paymentMethods.filter((a) => a.value !== 'CASH');
    }
  }
}
