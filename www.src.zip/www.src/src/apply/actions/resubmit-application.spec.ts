
import { TestBed, async } from '@angular/core/testing';
import { LocatorService, ActionService, GlobalNavigationService } from '@providers';
import { ResubmitApplication } from './resubmit-application';

class Action extends ResubmitApplication {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}


class MockGlobalNavigationService {
  getPreviousPageData() {
    return false;
  }
}

class MockActionService {
  executeAction() {
  }
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'globalNavigationService':
        return new MockGlobalNavigationService();
      case 'actionService':
        return new MockActionService();
      default:
        break;
    }
  }
}

describe('ResubmitApplication', () => {
  let action: Action;
  let ls: LocatorService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: GlobalNavigationService, useClass: MockGlobalNavigationService },
        { provide: ActionService, useClass: MockActionService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run', async(
      () => {
        action.execute().subscribe();
        spyOn(action.ls, 'getService').and.callThrough();
        expect(action.ls.getService).toBeTruthy();
      })
    );
  });
});
