import { Observable } from 'rxjs';
import { LocatorService } from '@providers';
import { ApplyModel } from '@apply/models';
import { InsuredPersonService } from '@apply/services';
import { SaveApplicationAndContinue } from './save-application-and-continue';

export class SaveBasicInfo extends SaveApplicationAndContinue {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any): Observable<any> {

    this.ls.getService<InsuredPersonService>('insuredPersonService').filterBeneficiaries(this.viewModel as ApplyModel);
    return super.execute(params);
  }
}
