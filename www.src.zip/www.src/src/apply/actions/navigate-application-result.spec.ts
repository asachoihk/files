import { NavigateApplicationResult } from './navigate-application-result';
import { LocatorService, CustomerService } from '@providers';
import { defer } from 'rxjs';
import { TestBed, fakeAsync } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { ApplicationService, SaveDocumentsService } from '@apply/services';
import { CheckData } from './check-data';
import { ApplyModel } from '@apply/models';

class Action extends NavigateApplicationResult {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'saveDocumentsService') {
            return new MockSaveDocumentsService();
        }

        if (serviceName === 'customerService') {
            return new MockCustomerService();
        }

        if (serviceName === 'applicationService') {
            return new MockApplicationService();
        }

    }

    get() {
        return new MockActivatedRoute();
    }

    getAction() {
        return new MockCheckData();
    }
}

class MockActivatedRoute {
    snapshot = {
        queryParams: {
            customerId: ''
        }
    };
}

class MockSaveDocumentsService {
    saveDocumentInsured() {
        return defer(() => Promise.resolve({
            uploadFileSuccess: true,
            insuredPerson: {
                documents: {}
            }
        }));
    }
}

class MockCustomerService {
    getCurrent() {
        return {
            customerId: 'abc'
        };
    }
}

class MockApplicationService {
    saveApplyData() {
        return defer(() => Promise.resolve({
            result: 'abc'
        }));
    }
}

class MockCheckData {
    invoke() {
        return;
    }
}

describe('NavigateApplicationResult', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ActivatedRoute, useClass: MockActivatedRoute },
                { provide: ApplicationService, useClass: MockApplicationService },
                { provide: CheckData, useClass: MockCheckData },
                { provide: CustomerService, useClass: MockCustomerService },
                { provide: SaveDocumentsService, useClass: MockSaveDocumentsService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run - params.saveDocumentInsured === true', () => {
            const params = {
                applicationStatus: 'PAYMENT_PENDING',
                saveDocumentInsured: true
            };
            const model = {
                payment: {
                    method: {},
                    documents: {}
                }
            } as ApplyModel;
            action.viewModel = model;
            expect(action.execute(params).subscribe()).toBeTruthy();
        });

        it('should be run - params.saveDocumentInsured === false', () => {
            const params = {
                applicationStatus: 'SUBMITTED',
                saveDocumentInsured: false
            };
            const model = {
                payment: {
                    method: {},
                    documents: {}
                },
                status: 'SUBMITTED',
                progress: {
                    sections: [
                        {
                            name: 'submission'
                        }
                    ]
                }
            } as ApplyModel;
            action.viewModel = model;
            action.dialogRef = {
                close() {
                    return;
                }
            } as any;
            expect(action.execute(params).subscribe()).toBeTruthy();
        });
    });

    describe('Function - ignoreValidationResult', () => {
        it('should be run', () => {
            expect(action.ignoreValidationResult()).toBeTruthy();
        });
    });
});