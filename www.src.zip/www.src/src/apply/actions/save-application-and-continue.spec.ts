
import { TestBed, async } from '@angular/core/testing';
import { LocatorService, AppContextService, SystemEventService, CustomerService, GlobalNavigationService, FormBuilderService } from '@providers';
import { SaveApplicationAndContinue } from './save-application-and-continue';
import { ActivatedRoute } from '@angular/router';
import { ApplicationService, ProgressService } from '@apply/services';
import { ApplyModel, PaymentModel } from '@apply/models';
import { PaymentMethod } from '@apply/enums';
import { of, Observable } from 'rxjs';

class Action extends SaveApplicationAndContinue {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}


class MockFormBuilderService {
  constructor() { }

  markFormTouched(formId) {

  }
}

class MockGlobalNavigationService {
  constructor() { }

  getCurrentNavigationPage() {
    return {
      checkChanges: 'checkApplicationChanges',
      id: 'payment',
      isBreadscrumbItem: true,
      isLeftNavigationItem: true,
      label: 'basicInformation',
      labelAction: 'getCurrentApplicationName'
    };
  }

  getLeftNavigationItems() {
    return [
      { id: 'payment' },
      { id: 'disclosure' }
    ];
  }

  navigateTo() {

  }
}

class MockCustomerService {
  constructor() { }

  getCurrent() {
    return {
      customerId: ''
    };
  }
}

class MockSystemEventService {
  constructor() { }

  publish() {
  }
}

class MockProgressService {
  constructor() { }

  publish() {
    return of({});
  }

  updateSectionProgress() {

  }
}

class MockApplicationService {
  constructor() { }

  saveApplyData(customerId: string, applyModels: ApplyModel[], isAddNew?: boolean): Observable<any[]> {
    return new Observable(subscriber => {
      return subscriber.next([{}]);
    });
  }
}

class MockAppContextService {
  constructor() { }

  currentFormBuilder = { id: '' };
}

class MockActivatedRoute {
  constructor() { }

  snapshot = {
    queryParams: {
      applicationId: '18072433-c834-755a-9372-6826ef99f9fb',
      customerId: 'd3162f16-66bc-1b8c-0cc6-3c0cb54cdeab'
    }
  };
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'globalNavigationService':
        return new MockGlobalNavigationService();
      case 'customerService':
        return new MockCustomerService();
      case 'systemEventService':
        return new MockSystemEventService();
      case 'progressService':
        return new MockProgressService();
      case 'applicationService':
        return new MockApplicationService();
      case 'appContextService':
        return new MockAppContextService();
      default:
        break;
    }
  }

  get() {
    return new MockActivatedRoute();
  }
}

describe('SaveApplicationAndContinue', () => {
  let action: Action;
  let ls: LocatorService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService },
        { provide: GlobalNavigationService, useClass: MockGlobalNavigationService },
        { provide: CustomerService, useClass: MockCustomerService },
        { provide: SystemEventService, useClass: MockSystemEventService },
        { provide: ProgressService, useClass: MockProgressService },
        { provide: ApplicationService, useClass: MockApplicationService },
        { provide: AppContextService, useClass: MockAppContextService },
        { provide: ActivatedRoute, useClass: MockActivatedRoute }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run when PaymentMethod is ONLINE', async(
      () => {
        const applyModel = new ApplyModel();
        applyModel.payment = new PaymentModel();
        applyModel.payment.method = PaymentMethod.ONLINE;
        applyModel.payment.documents = [];
        action.viewModel = applyModel;
        const params = { ignoreGoToNextPage: false };
        expect(action.execute(params).subscribe()).toBeTruthy();

      }
    ));

    it('should be run when renewalMethod is AUTODEBIT', async(
      () => {
        const applyModel = new ApplyModel();
        applyModel.payment = new PaymentModel();
        applyModel.payment.renewalMethod = 'AUTODEBIT';
        applyModel.payment.documents = [];
        action.viewModel = applyModel;
        const params = { ignoreGoToNextPage: false };
        expect(action.execute(params).subscribe()).toBeTruthy();

      }
    ));
  });

  describe('Function - ignoreValidationResult', () => {
    it('should be run', () => {
      expect(action.ignoreValidationResult()).toBeTruthy();
    });
  });
});
