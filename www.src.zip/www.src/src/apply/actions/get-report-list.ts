import { BaseAction } from 'providers/actions/base-action';
import { LocatorService, FormBuilderService, APPLICATION_STATUS } from '@providers';
import { Observable, forkJoin } from 'rxjs';
import { map, filter } from 'rxjs/operators';
import * as _ from 'lodash';
import { ApplyModel } from '@apply/models';
import { PreconditionComponent } from '@apply/components';
import { ReportSignatureService } from '@apply/services';
import { DOCUMENT_MODEL, ApplyServiceNames } from '@apply/const';

export class GetReportList extends BaseAction {

  applyData: ApplyModel;
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): any {
    const viewModel = this.viewModel as ApplyModel;
    const precondition = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId('precondition') as PreconditionComponent;
    if (precondition && precondition.showPrecondition) {
      return new Observable<any>(subscriber => {
        subscriber.next([]);
        subscriber.complete();
      });
    }
    let report_forms = viewModel.report_forms ? viewModel.report_forms : [];
    if (report_forms && Array.isArray(report_forms) && report_forms.length) {
      return new Observable<any>(subscriber => {
        report_forms.sort((a, b) => (a.header > b.header) ? 1 : -1);
        subscriber.next(report_forms);
        subscriber.complete();
      });
    }
    const hasSignatured = viewModel.status !== APPLICATION_STATUS.INPROGRESS;

    const subscribeForms = [];
    let original_report_forms = _.cloneDeepWith(viewModel.original_report_forms);
    if (original_report_forms) {
      original_report_forms = original_report_forms.filter(item => (item.type === DOCUMENT_MODEL.FINANCIAL || item.type === DOCUMENT_MODEL.PROPOSAL || item.type === DOCUMENT_MODEL.RISKPROFILE_QUESTIONAIRE) && item.serverId);
    }

    // clone Data
    if (viewModel.owner.id === viewModel.insured.id) {
      viewModel.owner.uwDetails = _.cloneDeepWith(viewModel.insured.uwDetails);
      viewModel.owner.person = _.cloneDeepWith(viewModel.insured.person);
      viewModel.owner.agreement = _.cloneDeepWith(viewModel.insured.agreement);
    }
    this.applyData = viewModel;

    if (!original_report_forms || original_report_forms.length === 0) {
      // get FNA report
      if (viewModel.fnaReportGeneratedDate) {
        const initFNAForm = this.ls.getService<ReportSignatureService>(ApplyServiceNames.reportSignatureService).initFNAForm(this.applyData.customerId, report_forms, viewModel.fnaReportGeneratedDate, hasSignatured);
        subscribeForms.push(initFNAForm);
      }
      if (viewModel.rpqReportGeneratedDate) {
        const initRPQForm = this.ls.getService<ReportSignatureService>(ApplyServiceNames.reportSignatureService).initRPQForm(this.applyData.customerId, report_forms, viewModel.rpqReportGeneratedDate, hasSignatured);
        subscribeForms.push(initRPQForm);
      }
      const initProposalForm = this.ls.getService<ReportSignatureService>(ApplyServiceNames.reportSignatureService).initProposalForm(this.applyData.customerId, report_forms, viewModel.proposalId, hasSignatured);
      subscribeForms.push(initProposalForm);
    } else {
      report_forms = _.cloneDeepWith(original_report_forms);
    }


    const initLifeInsuranceApplicationForm = this.ls.getService<ReportSignatureService>(ApplyServiceNames.reportSignatureService).initLifeInsuranceApplicationForm(this.applyData, report_forms, viewModel.insured.id, hasSignatured);
    subscribeForms.push(initLifeInsuranceApplicationForm);
    this.ls.getService<ReportSignatureService>(ApplyServiceNames.reportSignatureService).initOthersInsuredForm(this.applyData, subscribeForms, report_forms, viewModel.dependents, hasSignatured);
    this.ls.getService<ReportSignatureService>(ApplyServiceNames.reportSignatureService).initEDisclosureForms(this.applyData, subscribeForms, report_forms, viewModel.owner, viewModel.insured, viewModel.dependents, hasSignatured);

    return forkJoin(subscribeForms)
      .pipe(
        map((data: any[]) => {
          // map report_forms with serverId
          if (data && Array.isArray(data)) {
            report_forms.forEach((itm) => {
              const reportFormFind = data.find(item => item && item.id === itm.id);
              if (reportFormFind) {
                itm.serverId = reportFormFind && reportFormFind.serverId ? reportFormFind.serverId : null;
              }
            });
            report_forms = report_forms.filter(item => item.serverId);
            viewModel.report_forms = _.cloneDeepWith(report_forms);
            viewModel.original_report_forms = _.cloneDeepWith(report_forms);
            return report_forms.sort((a, b) => (a.header > b.header) ? 1 : -1);
          }
        })
      );
  }
}
