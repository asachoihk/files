
import { map } from 'rxjs/operators';
import { GlobalNavigationService, BaseAction, APPLICATION_STATUS } from '@providers';
import { Observable } from 'rxjs';
import { ApplicationService } from '@apply/services';
import { ApplicationsMapperService } from '@apply/services/application/applications-mapper.service';

export class SelectApplication extends BaseAction {
    execute(params: any): Observable<any> {
        const applicationId = params.applicationId;
        const customerId = params.customerId;
        return this.ls.getService<ApplicationService>('applicationService').getApplication(customerId, applicationId).pipe(map((selectedApp: any) => {
            const expiryDate = ApplicationsMapperService.getDate(selectedApp.expiryDate);
            selectedApp.status = ApplicationsMapperService.checkIfExpired(expiryDate, selectedApp.status) ? APPLICATION_STATUS.EXPIRED : selectedApp.status;

            const applyStatus = selectedApp.status;
            switch (applyStatus) {
                case APPLICATION_STATUS.SUBMISSION_CONFIRMED:
                case APPLICATION_STATUS.SUBMISSION_AGENT_QUESTION:
                case APPLICATION_STATUS.FAILED:
                case APPLICATION_STATUS.SUBMIT_FAILED:
                case APPLICATION_STATUS.PAYMENT_PENDING:
                case APPLICATION_STATUS.SIGNED:
                    this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission', { applicationId: applicationId, previousData: params.keywords });
                    break;
                case APPLICATION_STATUS.PAID:
                case APPLICATION_STATUS.SUBMITTED:
                    this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/submission/application-result', { applicationId: applicationId, previousData: params.keywords });
                    break;
                default:
                    this.ls.getService<GlobalNavigationService>('globalNavigationService').navigateTo('/apply/application-details/basic-info', { applicationId: applicationId, previousData: params.keywords });
                    break;
            }
        }));
    }
}
