import { LocatorService, FormBuilderService, BaseAction } from '@providers';

export class CheckWarning extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    const value = this.ls.getService<FormBuilderService>('formBuilderService').getDisplayValue(this.viewModel, this.formFieldConfig);
    if (isNaN(value)) {
      return;
    }
    let type = params.type;
    const min = params.min;
    const max = params.max;
    const valid = (min <= value && value <= max);

    if (!valid) {
      let warningMesage;
      if (type = 'height') {
        warningMesage = 'Entered value for Height is out of expected range';
      } else {
        warningMesage = 'Entered value for Weight is out of expected range';
      }
      const warningFormFieldConfig = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(params.warningFieldId).formFieldConfig;
      this.ls.getService<FormBuilderService>('formBuilderService').setFormFieldValue(this.viewModel, warningFormFieldConfig, warningMesage);
      this.viewModel.notifyValueChanges(warningFormFieldConfig);
    } else {
      const emptyFormFieldConfig = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(params.warningFieldId).formFieldConfig;
      this.ls.getService<FormBuilderService>('formBuilderService').setFormFieldValue(this.viewModel, emptyFormFieldConfig, null);
    }
  }
}
