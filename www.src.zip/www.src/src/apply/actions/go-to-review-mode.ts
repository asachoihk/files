import { LocatorService, SystemEventService, BaseAction, ValidatorService, AppContextService, ViewModeChanged, ViewMode, ToolbarActionsChanged } from '@providers';
import { DisclosureValidationService } from 'disclosure/services/disclosure-validation/disclosure-validation.service';

export class GoToReviewMode extends BaseAction {

    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute() {
        const currentFormBuilder = this.ls.getService<AppContextService>('appContextService').currentFormBuilder;
        if (currentFormBuilder.id.startsWith('/disclosure/')) {
            this.ls.getService<DisclosureValidationService>('disclosureValidationService').validateDisclosureData();
        } else {
            this.ls.getService<ValidatorService>('validatorService').validateForm(currentFormBuilder.id);
        }

        this.ls.getService<SystemEventService>('systemEventService').publish(new ViewModeChanged(ViewMode.review));
        this.ls.getService<SystemEventService>('systemEventService').publish(new ToolbarActionsChanged());
    }
}
