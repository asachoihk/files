
import { TestBed, async } from '@angular/core/testing';
import { LocatorService, JsonConfigService } from '@providers';
import { GetIdentities } from './get-identities';

class Action extends GetIdentities {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}


class MockJsonConfigService {
  constructor() { }

  getIdentityTypes() {
    return [{
      country: 'VN',
      id: 'ID',
      value: 'ID Card'
    }];
  }
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'jsonConfigService':
        return new MockJsonConfigService();
      default:
        break;
    }
  }
}

describe('GetIdentities', () => {
  let action: Action;
  let ls: LocatorService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: JsonConfigService, useClass: MockJsonConfigService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run', async(() => {
      action.formFieldConfig = {
        default: 'ID,PP,BC,MC'
      };

      expect(action.execute().subscribe());
    }));

    it('should be run', async(() => {
      action.formFieldConfig = {
        default: null
      };
      action.parentFormFieldConfig = null;

      expect(action.execute().subscribe());
    }));
  });
});
