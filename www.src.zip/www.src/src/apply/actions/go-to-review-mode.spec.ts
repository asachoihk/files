import { LocatorService } from 'providers/services';
import { TestBed } from '@angular/core/testing';
import { GoToReviewMode } from './go-to-review-mode';

class Action extends GoToReviewMode {
  constructor(public ls: LocatorService) {
    super(ls);
  }
}

class MockSystemEventService {
  publish() {}
}

class MockValidatorService {
  validateForm() {}
}

class MockAppContextService {
  currentFormBuilder = { id: 'currentFormBuilder' };
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'systemEventService':
        return new MockSystemEventService();
      case 'validatorService':
        return new MockValidatorService();
      case 'appContextService':
        return new MockAppContextService();
      default:
        break;
    }
  }
}

describe('GoToReviewMode', () => {
  let action: Action;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });

  describe('Function - Excute', () => {
    beforeEach(() => {
      spyOn(action.ls, 'getService').and.callThrough();
    });

    it('should be run', () => {
      action.execute();
      expect(action.ls.getService).toHaveBeenCalled();
    });
  });
});
