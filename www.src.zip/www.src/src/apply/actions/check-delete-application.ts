import { BaseAction, APPLICATION_STATUS } from '@providers';

export class CheckDeleteApplication extends BaseAction {
    execute(params: any): boolean {
        return params !== APPLICATION_STATUS.INPROGRESS && params !== APPLICATION_STATUS.EXPIRED;
    }
}
