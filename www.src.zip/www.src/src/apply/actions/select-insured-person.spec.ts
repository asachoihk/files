import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { SelectInsuredPerson } from './select-insured-person';
import { InsuredModel } from '@apply/models';

class Action extends SelectInsuredPerson {
    constructor(public ls: LocatorService) {
        super(ls);
    }

}

class MockLocatorService {
    getService(serviceName: string): any {
        if (serviceName === 'actionService') {
            return new MockActionService();
        } else if (serviceName === 'appContextService') {
            return new MockAppContextService();
        }
        return new MockFormBuilderService();
    }
}

class MockFormBuilderService {
}

class MockAppContextService {
}

class MockActionService {
    createActionParams = () => {
        return { width: '', height: '' };
    }
}

describe('SelectInsuredPerson', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            action.viewModel = new InsuredModel();
            (action.viewModel as any) = {
                type: 'o'
            };
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton', relationships: ['beneficialOwnerList', 'beneficialOwnerAllocation'] };
            spyOn(action.ls, 'getService').and.returnValue({
                showFormBuilderDialog(component, dialog, actionParams, callback) {
                    return callback({
                        action: 'yes'
                    });
                },
                currentFormBuilder: {
                    viewModel: undefined,
                    refreshData(callback) {
                        return callback({});
                    }
                },
                getComponentByFormFieldConfig() {},
                getComponentByFormFieldConfigId() {
                    return {
                        loadDataSource() {
                            return;
                        }
                    };
                }
            });
            action.execute({beneficiaryId: 'beneficiaryId'});
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be run when has taskCardList', () => {
            action.viewModel = new InsuredModel();
            (action.viewModel as any) = {
                type: 'o'
            };
            action.formFieldConfig = { id: 'floatingButton', type: 'floatingButton', label: 'floatingButton', relationships: ['beneficialOwnerList', 'beneficialOwnerAllocation'] };
            spyOn(action.ls, 'getService').and.returnValue({
                showFormBuilderDialog(component, dialog, actionParams, callback) {
                    return callback({
                        action: 'yes'
                    });
                },
                currentFormBuilder: {
                    viewModel: undefined,
                    refreshData(callback) {
                        return callback({});
                    }
                },
                getComponentByFormFieldConfig() {
                    return {
                        loadDataSource() {}
                    };
                },
                getComponentByFormFieldConfigId() {}
            });
            action.execute({beneficiaryId: 'beneficiaryId'});
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});
