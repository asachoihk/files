import { TestBed } from '@angular/core/testing';
import { LocatorService } from '@providers';
import { GetCurrentApplicationName } from './get-current-application-name';
import { ApplicationService } from '@apply/services';


class Action extends GetCurrentApplicationName {
    constructor(public ls: LocatorService) {
      super(ls);
    }
  }

  class MockLocatorService {
    getService(serviceName: string) {
        switch (serviceName) {
          case 'applicationService':
            return new MockApplicationService();
          default:
            break;
        }
      }
  }

  class MockApplicationService {
    constructor() {
    }
    getCurrentApplyData() {
        return {
            basicPlan : {
                name : 'EN'
            }
        }
    }
  }

describe('GetBasicInfoPageTitle', () => {
    let action: Action;
    let ls: LocatorService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ApplicationService, useClass: MockApplicationService },
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
      });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            expect(action.execute()).toEqual('EN');
        });
    });
});
