import { TestBed, async } from '@angular/core/testing';
import { LocatorService, JsonConfigService } from '@providers';
import { GetAgentQuestion } from './get-agent-question';
import { ApplicationService } from '@apply/services';
import { ApplyModel } from '@apply/models';
import { ActivatedRoute } from '@angular/router';


class Action extends GetAgentQuestion {
    constructor(public ls: LocatorService) {
      super(ls);
    }
  }

  class MockLocatorService {
    getService(serviceName: string) {
        switch (serviceName) {
          case 'applicationService':
            return new MockApplicationService();
          default:
            break;
        }
      }
    get() {
      return new MockActivatedRoute
    }
  }

  class MockActivatedRoute {
    constructor() {
    }

    snapshot = {
      queryParams: {
        applicationId : '9e101e2c-ca71-5789-bd34-60cde6d59540'
      }
    }

  }

  class MockApplicationService {
    constructor() {
    }
    getApplyData(appId) {
        return {
          declaration_answer : {
            id: 'id',
            agent_question: 'agent_question',
            agent_answer: 'agent_answer'
          }
        }
    }
  }

describe('GetAgentQuestion', () => {
    let action: Action;
    let ls: LocatorService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ApplicationService, useClass: MockApplicationService },
                { provide: ActivatedRoute, useClass: MockActivatedRoute },
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
      });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            expect(action.execute().agent_answer).toEqual('agent_answer');
        });
    });
});
