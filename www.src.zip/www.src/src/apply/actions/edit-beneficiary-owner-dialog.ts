import { Injectable } from '@angular/core';
import { LocatorService, AppContextService } from '@providers';
import { EditBeneficaryDialog } from './edit-beneficiary-dialog';
import { BeneficiaryModel, ApplyPage } from '@apply/models';

@Injectable()
export class EditBeneficaryOwnerDialog extends EditBeneficaryDialog {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any): void {
    const ownerBeneficiary = params as BeneficiaryModel;
    const currentPage = this.ls.getService<AppContextService>('appContextService').appContext.currentPage as ApplyPage;
    const ownerId = currentPage.applyData.owner.id;
    ownerBeneficiary.guid = ownerId;
    const beneficiaryParams = { ...params, dataBeneficiary: params };
    super.execute(beneficiaryParams);
  }
}
