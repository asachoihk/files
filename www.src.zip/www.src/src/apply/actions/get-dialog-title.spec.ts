
import { TestBed } from '@angular/core/testing';
import { LocatorService, AppContextService, GlobalNavigationService, BaseModel } from '@providers';
import { GetDialogTitle } from './get-dialog-title';
import { TranslationService } from 'angular-l10n';
import { InsuredModel } from '@apply/models';

class Action extends GetDialogTitle {
  formFieldConfig: any;
  constructor(public ls: LocatorService) {
    super(ls);
  }
}


class MockGlobalNavigationService {
  constructor() { }

  getCurrentNavigationPage() {
    return {
      label: 'basicInformation'
    };
  }

}

class MockAppContextService {
  constructor() { }
  currentFormBuilder() {
    return {
      data: {
        params: {
          insuredPerson: {
            person: {
              basicInfo: {
                firstName: 'First Name',
                lastName: 'Last Name'
              }
            }
          }
        }
      }
    };
  }
}

class MockTranslationService {
  constructor() { }

  translate() {
    return {
      label: 'basicInformation'
    };
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'globalNavigationService':
        return new MockGlobalNavigationService();
      case 'appContextService':
        return new MockAppContextService();
      case 'translationService':
        return new MockTranslationService();
      default:
        break;
    }
  }
}

describe('GetDialogTitle', () => {
  let action: Action;
  let ls: LocatorService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: GlobalNavigationService, useClass: MockGlobalNavigationService },
        { provide: AppContextService, useClass: MockAppContextService },
        { provide: TranslationService, useClass: MockTranslationService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });

  beforeEach(() => {
    action = new Action(ls);
  });

  it('should be created', () => {
    expect(action).toBeTruthy();
  });


  describe('Function - Excute', () => {
    it('should be run as InsuredModel', () => {
      action.viewModel = new InsuredModel();
      expect(action.execute());
    });
    it('should be run not as InsuredModel', () => {
      action.viewModel = new BaseModel();
      expect(action.execute());
    });
  });
});
