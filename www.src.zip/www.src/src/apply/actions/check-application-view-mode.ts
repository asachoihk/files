import { LocatorService, BaseAction, SystemEventService, ViewMode, ViewModeChanged } from '@providers';
import { ApplicationService } from '@apply/services';

export class CheckApplicationViewMode extends BaseAction {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    execute() {
        const viewMode = this.ls.getService<ApplicationService>('applicationService').isApplicationReadOnlyMode() ? ViewMode.readonly : ViewMode.normal;
        this.ls.getService<SystemEventService>('systemEventService').publish(new ViewModeChanged(viewMode));
    }
}
