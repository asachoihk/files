import { LocatorService, JsonConfigService, JsonConfigItem, BaseAction } from '@providers';
import { Observable } from 'rxjs';
import * as _ from 'lodash';

export class GetSourceOfFunds extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Observable<JsonConfigItem[]> {


    return new Observable<JsonConfigItem[]>(subscriber => {
      const source = this.ls.getService<JsonConfigService>('jsonConfigService').getSourceOfFunds();
      subscriber.next(_.cloneDeepWith(source));
    });
  }
}
