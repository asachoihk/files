import { TestBed, async } from '@angular/core/testing';
import { LocatorService, JsonConfigService } from '@providers';
import { GetApplyData } from './get-apply-data';
import { ApplicationService, ApplicationsMapperService } from '@apply/services';


class Action extends GetApplyData {
    constructor(public ls: LocatorService) {
      super(ls);
    }
  }

  class MockLocatorService {
    getService(serviceName: string) {
        switch (serviceName) {
          case 'applicationService':
            return new MockApplicationService();
          default:
            break;
        }
      }
    get() {
      return new MockApplicationService()
    }
  }

  class MockApplicationService {
    constructor() {
    }
    getCurrentApplyData() {
       return {
        expiryDate : 'expiryDate',
        status : 'SIGNED'
      }
    }
  }

  class MockApplicationsMapperService {
    getDate() {
        return null;
    }

    checkIfExpired() {
        return 'EXPIRED';
    }
}

describe('GetApplyData', () => {
    let action: Action;
    let ls: LocatorService;
    let mapper: ApplicationsMapperService
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: ApplicationService, useClass: MockApplicationService },
                { provide: ApplicationsMapperService, useClass: MockApplicationsMapperService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);
      });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run', () => {
            expect(action.execute().status).toEqual('SIGNED');
        });

        it('should be run', () => {
          spyOn(action.ls, 'getService').and.returnValue(
            {
              getCurrentApplyData() {
                return {
                  expiryDate : '2019-04-27T07:52:50.352Z',
                  status : 'SIGNED'
                }
             }
            });
            expect(action.execute().status).toEqual('EXPIRED');
        });
    });
});
