import { LoadSupportingDocsDialog } from './load-supporting-docs-dialog';
import { LocatorService, FormBuilderService, AppContextService, DialogService } from '@providers';
import { TaskCardListComponent } from '@shared/components';
import { TestBed } from '@angular/core/testing';
import { InsuredModel } from '@apply/models';

class Action extends LoadSupportingDocsDialog {
    constructor(public ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'formBuilderService') {
            return new MockFormBuilderService();
        }

        if (serviceName === 'appContextService') {
            return new MockAppContextService();
        }

        if (serviceName === 'dialogService') {
            return new MockDialogService();
        }

    }

}

class MockDialogService {
    showFormBuilderDialog(SupportingDocsDialogComponent, DialogShellComponent, data, callback) {
        return callback({});
    }
}

class MockAppContextService {
    currentFormBuilder = {
        refreshData(callback) {
            return callback({});
        }
    };
}

class MockFormBuilderService {
    getComponentByFormFieldConfig() {
        return {
            loadDataSource() {
                return;
            }
        } as TaskCardListComponent;
    }
}

describe('LoadSupportingDocsDialog', () => {
    let action: Action;
    let ls;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: FormBuilderService, useClass: MockFormBuilderService },
                { provide: AppContextService, useClass: MockAppContextService },
                { provide: DialogService, useClass: MockDialogService },
            ],
        });
        ls = TestBed.get(LocatorService);
    });
    beforeEach(() => {
        action = new Action(ls);
    });


    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be run - viewModel.type === InsuredType.o', () => {
            action.viewModel = {
                type: 'o'
            } as InsuredModel;
            expect(action.execute()).toBeUndefined();
        });

        it('should be run - viewModel.type === InsuredType.i', () => {
            action.viewModel = {
                type: 'i'
            } as InsuredModel;
            expect(action.execute()).toBeUndefined();
        });

        it('should be run - viewModel.type === InsuredType.r', () => {
            action.viewModel = {
                type: 'r'
            } as InsuredModel;
            expect(action.execute()).toBeUndefined();
        });
    });
});