import { TestBed } from '@angular/core/testing';
import { LocatorService, SystemEventService } from '@providers';
import { ChangePaymentMethod } from './change-payment-method';
import { ApplyModel } from '@apply/models';
import { of } from 'rxjs';

class Action extends ChangePaymentMethod {
    constructor(protected ls: LocatorService) {
        super(ls);
    }
}

class MockLocatorService {
    getService(serviceName: string) {
        if (serviceName === 'systemEventService') {
            return new MockSystemEventService();
        }
    }

}

class MockSystemEventService {
    publish() {
        return of({});
    }
}

describe('ChangePaymentMethod', () => {
    let action: Action;
    let ls;

    beforeEach(() => {

        TestBed.configureTestingModule({

            providers: [
                { provide: LocatorService, useClass: MockLocatorService },
                { provide: SystemEventService, useClass: MockSystemEventService }
            ],

        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => {
        action = new Action(ls);

    });

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    const actionParams = {
        documentType: 'abc'
    };

    describe('Function - Excute', () => {

        it('should be run - same id', () => {
            const model = {
                owner: {
                    id: '123'
                },
                insured: {
                    id: '123',
                    documents: [
                        {
                            type: 'abc'
                        }
                    ]
                }
            };
            action.viewModel = model as ApplyModel;
            expect(action.execute(actionParams));
        });

        it('should be run - different id', () => {
            const model = {
                owner: {
                    id: '123',
                    documents: [
                        {
                            type: 'abcd'
                        }
                    ]
                },
                insured: {
                    id: '1234'
                }
            };
            action.viewModel = model as ApplyModel;
            expect(action.execute(actionParams)).toBeUndefined();
        });
    });
});
