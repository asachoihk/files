import { LocatorService, SystemEventService, BaseAction, FormBuilderService, APPLICATION_STATUS } from '@providers';
import { TableComponent } from '@shared/ui-elements';

export class ShowDeleteApplicationMultiple extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(params: any) {
    this.ls.getService<SystemEventService>('systemEventService').tempEventDeleteMultiCustomer.next(true);
    const applicationsFieldId = params && params.applicationsFieldId ? params.applicationsFieldId : this.formFieldConfig.id;
    const tableComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(applicationsFieldId) as TableComponent;
    if (tableComponent && tableComponent.dataTable) {
      const status = [APPLICATION_STATUS.INPROGRESS, APPLICATION_STATUS.EXPIRED];
      const data = tableComponent.dataTable.filter(applyModel => status.indexOf(applyModel.status) > -1);
      tableComponent.loadDataSourceWithData(data);
    }
  }
}
