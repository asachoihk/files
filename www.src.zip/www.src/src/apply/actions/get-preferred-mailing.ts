import { LocatorService, JsonConfigService, BaseAction, JsonConfigItem } from '@providers';
import { Observable } from 'rxjs';
import * as _ from 'lodash';

export class GetPreferredMailing extends BaseAction {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  execute(): Observable<JsonConfigItem[]> {


    return new Observable<JsonConfigItem[]>(subscriber => {
      const banks = this.ls.getService<JsonConfigService>('jsonConfigService').getPreferredMailing();
      subscriber.next(_.cloneDeepWith(banks));
    });
  }
}
