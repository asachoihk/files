import { TestBed } from '@angular/core/testing';
import { LocatorService, BaseModel } from '@providers';
import { GetAddressDataByType } from './get-address-data-by-type';


class Action extends GetAddressDataByType {
    constructor(
        public ls: LocatorService
    ) {
        super(ls);
    }
}

class MockLocatorService {
    constructor() { }

    getService() {
    }

    get() { }
}

describe('GetAddressDataByType', () => {
    let action: Action;
    let ls;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: LocatorService, useClass: MockLocatorService }
            ]
        });
        ls = TestBed.get(LocatorService);
    });

    beforeEach(() => action = new Action(ls));

    it('should be created', () => {
        expect(action).toBeTruthy();
    });

    describe('Function - Excute', () => {
        it('should be return when has addressModel', () => {
            action.formFieldConfig = {
                id: 'id',
                type: 'dropdown',
                metadata: {
                    type: 'type'
                },
                dataBinding: {
                    path: 'path'
                }
            };
            action.viewModel = new BaseModel();
            spyOn(action.ls, 'getService').and.returnValue({
                getBindingData() {
                    return [{
                        addressType: 'type',
                    }];
                },
                getAppConfig() {
                    return {
                        homeCountry: {
                            countryCode: 'countryCode'
                        }
                    };
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });

        it('should be return when hasn"t addressModel', () => {
            action.formFieldConfig = {
                id: 'id',
                type: 'dropdown',
                metadata: {
                    type: 'type'
                },
                dataBinding: {
                    path: 'path'
                }
            };
            action.viewModel = new BaseModel();
            spyOn(action.ls, 'getService').and.returnValue({
                getBindingData() {
                    return null;
                },
                setBindingData() {
                    return null;
                },
                getAppConfig() {
                    return {
                        homeCountry: {
                            countryCode: 'countryCode'
                        }
                    };
                }
            });
            action.execute();
            expect(action.ls.getService).toHaveBeenCalled();
        });
    });
});
