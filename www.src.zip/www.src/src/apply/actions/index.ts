import { TypeConfig } from 'providers/models/config/type-config';
import { GetApplications } from './get-applications';
import { SelectApplication } from './select-application';
import { SelectInsuredPerson } from './select-insured-person';
import { GetInsuredPersons } from './get-insured-persons';
import { GetApplyData } from './get-apply-data';
import { GetIdentities } from './get-identities';
import { GetCountries } from './get-countries';
import { GetIssuePlaces } from './get-issue-places';
import { GetCurrentInsuredPerson } from './get-current-insured-person';
import { GetBasicInfoPageTitle } from './get-basic-info-page-title';
import { GetHabits } from './get-habits';
import { GetBanks } from './get-bank';
import { GetBankBranchs } from './get-bank-branch';
import { UpdateBankInfo } from './update-bank-info';
import { SetIssuePlace } from './set-issue-place';
import { LoadCountryDialog } from './load-country-dialog';
import { CloseCountryDialog } from './close-country-dialog';
import { SaveAndBackInsuredPerson } from './save-and-back-insured-person';
import { GetPreferredMailing } from './get-preferred-mailing';
import { GetBeneficiaryPersons } from './get-beneficiary-persons';
import { GetRelationCode } from './get-relation-code';
import { GetSourceOfFunds } from './get-source-of-funds';
import { LoadOccupationDialogJobIncome } from './load-occupation-dialog-job-income';
import { LoadNatureDialogJobIncome } from './load-nature-dialog-job-income';
import { DeleteBeneficiary } from './delete-beneficiary';
import { EditBeneficaryDialog } from './edit-beneficiary-dialog';
import { TransformApplications } from './transform-application';
import { LoadIssuePlaceDialog } from './load-issue-place-dialog';
import { LoadIssuePlaceProvinceDialog } from './load-issue-place-province-dialog';
import { GetCurrentApplicationName } from './get-current-application-name';
import { IndentityChange } from './indentity-change';
import { GetYesNo } from './get-yes-no';
import { CancelBeneficiaryDialog } from './cancel-beneficiary-dialog';
import { CheckWarning } from '@apply/actions/check-warning';
import { RemoveAgreementInsurace } from './remove-agreement-insurace';
import { AddBeneficialOwner } from './add-beneficial-owner';
import { RemoveBeneficialOwner } from './remove-beneficial-owner';
import { AddOtherAgreementInsurace } from './add-other-agreement-insurace';
import { SaveBeneficiaryPerson } from './save-beneficiary-person';
import { AnswerAgreementQuestion } from './answer-agreement-question';
import { LoadAnswerAgreementQuestion } from './load-answer-agreement-question';
import { LoadAgreementReplacement } from './load-agreement-replacement';
import { LoadAgreementsDialog } from './load-agreements-dialog';
import { GetBeneficialOwner } from './get-beneficial-owner';
import { AnswerBeneficialOwnerQuestion, LoadAnswerBeneficialOwnerQuestion } from './answer-beneficial-owner-question';
import { AnswerFatcaQuestion } from '@apply/actions/answer-fatca-question';
import { GetPercentageBeneficialOwner } from './get-percentage-beneficial-owner';
import { CheckAvailable } from './check-available';
import { LoadAnswerFatcaQuestion } from '@apply/actions/load-answer-fatca-question';
import { LoadBeneficiary } from './load-beneficiary';
import { LoadDisclosureDialog } from './load-disclosure-dialog';
import { GetIdentitiesPH } from './get-identities-ph';
import { AddSecondaryOccupation } from './add-secondary-occupation';
import { HiddenSecondaryOccupation } from './hidden-secondary-occupation';
import { RemoveSecondaryOccupation } from '@apply/actions/remove-secondary-occupation';
import { ShowSourceOfFunds } from '@apply/actions/show-source-of-funds';
import { GetReportList } from './get-report-list';
import { GetSignPersons } from './get-sign-persons';
import { CheckBeneficialOwner } from './check-beneficial-owner';
import { NavigateAgentQuestion } from './navigate-agent-question';
import { ShowAreatext } from './show-areatext';
import { NavigateApplicationResult } from './navigate-application-result';
import { GetAgentQuestion } from './get-agent-question';
import { CheckStatus } from './check-status';
import { CheckData } from './check-data';
import { GetPaymentFrequency } from './get-payment-frequency';
import { GetSubsequentPaymentMethod } from './get-subsequent-payment-method';
import { GetInitialPaymentMode } from './get-initial-payment-method';
import { GetInitialPayment } from './get-initial-payment';
import { SaveApplicationAndContinue } from './save-application-and-continue';
import { GetDialogTitle } from './get-dialog-title';
import { RenderContentResult } from './render-content-result';
import { SaveDisclosureDataAndContinue } from './save-disclosure-data-and-continue';
import { CloseDisclosureDialog } from './close-disclosure-dialog';
import { CheckApplicationStatus } from './check-application-status';
import { CheckDeleteApplication } from './check-delete-application';
import { DeleteApplication } from './delete-application';
import { DeleteApplicationMultiple } from './delete-application-multiple';
import { ShowDeleteApplicationMultiple } from './show-delete-application-multiple';
import { CheckApplicationChanges } from './check-application-changes';
import { GetOwner } from './get-owner';
import { GetAddNewBeneficiaryDataSource } from './get-add-new-beneficiary-data-source';
import { EditBeneficaryOwnerDialog } from './edit-beneficiary-owner-dialog';
import { CheckInsuredType } from './check-insured-type';
import { GetCivilStatus } from './get-civil-status';
import { SaveBasicInfo } from './save-basic-info';
import { CancelDeleteApplicationMultiple } from './cancel-delete-application-multiple';
import { CheckOwnerBeneficiary } from './check-owner-beneficiary';
import { CheckDefaultId } from './check-default-id';
import { GetCreditCards } from './get-credit-cards';
import { SelectCreditCard } from './select-credit-card';
import { LoadSupportingDocsDialog } from './load-supporting-docs-dialog';
import { CheckDocumentVisibility } from './check-document-visibility';
import { CheckReviewButtonStatus } from './check-review-button-status';
import { ExitReviewMode } from './exit-review-mode';
import { GoToReviewMode } from './go-to-review-mode';
import { ChangePaymentMethod } from './change-payment-method';
import { NavigatePaymentGateway } from './navigate-payment-gateway';
import { SubmitAis } from './submit-ais';
import { SubmitCas } from './submit-cas';
import { ResubmitApplication } from './resubmit-application';
import { CheckPaymentVisibility } from './check-payment-visibility';
import { CheckRemoveAgreementInsuraceVisibility } from './check-remove-agreement-insurace-visibility';
import { GetAgentApplications } from './get-agent-applications';
import { SelectAgentApplication } from './select-agent-application';
import { CheckHideReadonly } from './check-hide-readonly';
import { CheckShowHideWeightAtBirth } from './check-show-hide-weight-at-birth';
import { CopyResidentialAddress } from './copy-residential-address';
import { CheckHideSignature } from './check-hide-signature';
import { CheckApplicationViewMode } from './check-application-view-mode';
import { SelectPaymentMethod } from './select-payment-method';
import { CheckPaymentOnlineVisibility } from './check-payment-online-visibility';
import { CheckOwnerType } from './check-owner-type';
import { GetSupportingDocsSteps } from './get-supporting-docs-steps';
import { GetIdentificationUploadMetadata } from './get-identification-upload-metadata';
import { ShowDialogSignature } from './signature/show-dialog-signature';
import { GetSignature } from './signature/get-signature';
import { ReSignature } from './signature/re-signature';
import { GetCurrentSignature } from './signature/get-current-signature';
import { ProceedToSubmissionDialog } from './signature/proceed-to-submission-dialog';
import { CheckProceedButton } from './signature/check-proceed-button';
import { GetCurrentReport } from './signature/get-current-report';
import { GetUrlReport } from './signature/get-url-report';
import { ReviewReportSignature } from './signature/review-report-signature';
import { GetUrlSignature } from './signature/get-url-signature';
import { GetPhoneDataByType } from './get-phone-data-by-type';
import { GetPaymentMethod } from './get-payment-method';
import { GetAddressDataByType } from './get-address-data-by-type';
import { CheckDisclosure } from './check-disclosure';
import { CheckSameAsResidentialAddressVisibility } from './check-same-as-residential-address-visibility';
import { GetBeneficiaryTitle } from './get-beneficiary-title';
import { GetApplicationTypeParamValue } from './disclosure/get-application-type-param-value';
import { GetPaperApplicationFlagParamValue } from './disclosure/get-paper-application-flag-param-value';
import { GetAgeParamValue } from './disclosure/get-age-param-value';
import { GetAgeBandParamValue } from './disclosure/get-age-band-param-value';
import { GetGenderParamValue } from './disclosure/get-gender-param-value';
import { GetBmiParamValue } from './disclosure/get-bmi-param-value';
import { GetSmokerStatusParamValue } from './disclosure/get-smoker-status-param-value';
import { GetMyEducationUnbornApplyFlagParamValue } from './disclosure/get-my-education-unborn-apply-flag-param-value';

export const allApplyActionTypeConfigs: TypeConfig[] = [
  {
    name: 'closeCountryDialog',
    type: CloseCountryDialog
  },
  {
    name: 'getApplications',
    type: GetApplications
  },
  {
    name: 'selectApplication',
    type: SelectApplication
  },
  {
    name: 'selectInsuredPerson',
    type: SelectInsuredPerson
  },
  {
    name: 'getInsuredPersons',
    type: GetInsuredPersons
  },
  {
    name: 'getBeneficiaryPersons',
    type: GetBeneficiaryPersons
  },
  {
    name: 'getApplyData',
    type: GetApplyData
  },
  {
    name: 'getIdentities',
    type: GetIdentities
  },
  {
    name: 'getCountries',
    type: GetCountries
  },
  {
    name: 'getIssuePlaces',
    type: GetIssuePlaces
  },
  {
    name: 'getCurrentInsuredPerson',
    type: GetCurrentInsuredPerson
  },
  {
    name: 'getBasicInfoPageTitle',
    type: GetBasicInfoPageTitle
  },
  {
    name: 'getHabits',
    type: GetHabits
  },
  {
    name: 'getBanks',
    type: GetBanks
  },
  {
    name: 'getBankBranchs',
    type: GetBankBranchs
  },
  {
    name: 'updateBankInfo',
    type: UpdateBankInfo
  },
  {
    name: 'setIssuePlace',
    type: SetIssuePlace
  },
  {
    name: 'loadCountryDialog',
    type: LoadCountryDialog
  },
  {
    name: 'saveAndBackInsuredPerson',
    type: SaveAndBackInsuredPerson
  },
  {
    name: 'getRelationCode',
    type: GetRelationCode
  },
  {
    name: 'getSourceOfFunds',
    type: GetSourceOfFunds
  },
  {
    name: 'loadOccupationDialogJobIncome',
    type: LoadOccupationDialogJobIncome
  },
  {
    name: 'loadNatureDialogJobIncome',
    type: LoadNatureDialogJobIncome
  },
  {
    name: 'deleteBeneficiary',
    type: DeleteBeneficiary
  },
  {
    name: 'editBeneficiary',
    type: EditBeneficaryDialog
  },
  {
    name: 'transformApplications',
    type: TransformApplications
  },
  {
    name: 'loadIssuePlaceDialog',
    type: LoadIssuePlaceDialog
  },
  {
    name: 'loadIssuePlaceProvinceDialog',
    type: LoadIssuePlaceProvinceDialog
  },
  {
    name: 'getCurrentApplicationName',
    type: GetCurrentApplicationName
  },
  {
    name: 'indentityChange',
    type: IndentityChange
  },
  {
    name: 'getPreferredMailing',
    type: GetPreferredMailing
  },
  {
    name: 'getYesNo',
    type: GetYesNo
  },
  {
    name: 'cancelBeneficiaryDialog',
    type: CancelBeneficiaryDialog
  },
  {
    name: 'checkWarning',
    type: CheckWarning
  },
  {
    name: 'addBeneficialOwner',
    type: AddBeneficialOwner
  },
  {
    name: 'removeBeneficialOwner',
    type: RemoveBeneficialOwner
  },
  {
    name: 'addOtherAgreementInsurace',
    type: AddOtherAgreementInsurace
  },
  {
    name: 'removeAgreementInsurace',
    type: RemoveAgreementInsurace
  },
  {
    name: 'saveBeneficiaryPerson',
    type: SaveBeneficiaryPerson
  },
  {
    name: 'loadAgreementsDialog',
    type: LoadAgreementsDialog
  },
  {
    name: 'answerAgreementQuestion',
    type: AnswerAgreementQuestion
  },
  {
    name: 'getBeneficialOwner',
    type: GetBeneficialOwner
  },
  {
    name: 'answerBeneficialOwnerQuestion',
    type: AnswerBeneficialOwnerQuestion
  },
  {
    name: 'answerFatcaQuestion',
    type: AnswerFatcaQuestion
  },
  {
    name: 'loadAnswerFatcaQuestion',
    type: LoadAnswerFatcaQuestion
  },
  {
    name: 'loadAnswerBeneficialOwnerQuestion',
    type: LoadAnswerBeneficialOwnerQuestion
  },
  {
    name: 'getPercentageBeneficialOwner',
    type: GetPercentageBeneficialOwner
  },
  {
    name: 'loadAnswerAgreementQuestion',
    type: LoadAnswerAgreementQuestion
  },
  {
    name: 'checkAvailable',
    type: CheckAvailable
  },
  {
    name: 'loadAgreementReplacement',
    type: LoadAgreementReplacement
  },
  {
    name: 'loadBeneficiary',
    type: LoadBeneficiary
  },
  {
    name: 'loadDisclosureDialog',
    type: LoadDisclosureDialog
  },
  {
    name: 'getIdentitiesPH',
    type: GetIdentitiesPH
  },
  {
    name: 'addSecondaryOccupation',
    type: AddSecondaryOccupation
  },
  {
    name: 'hiddenSecondaryOccupation',
    type: HiddenSecondaryOccupation
  },
  {
    name: 'removeSecondaryOccupation',
    type: RemoveSecondaryOccupation
  },
  {
    name: 'showSourceOfFunds',
    type: ShowSourceOfFunds
  },
  {
    name: 'getReportList',
    type: GetReportList
  },
  {
    name: 'getSignPersons',
    type: GetSignPersons
  },
  {
    name: 'checkBeneficialOwner',
    type: CheckBeneficialOwner
  },
  {
    name: 'navigateAgentQuestion',
    type: NavigateAgentQuestion
  },
  {
    name: 'showAreatext',
    type: ShowAreatext
  },
  {
    name: 'navigateApplicationResult',
    type: NavigateApplicationResult
  },
  {
    name: 'navigatePaymentGateway',
    type: NavigatePaymentGateway
  },
  {
    name: 'getAgentQuestion',
    type: GetAgentQuestion
  },
  {
    name: 'checkStatus',
    type: CheckStatus
  },
  {
    name: 'checkData',
    type: CheckData
  },
  {
    name: 'getPaymentFrequency',
    type: GetPaymentFrequency
  },
  {
    name: 'getSubsequentPaymentMethod',
    type: GetSubsequentPaymentMethod
  },
  {
    name: 'getInitialPayment',
    type: GetInitialPayment
  },
  {
    name: 'saveApplicationAndContinue',
    type: SaveApplicationAndContinue
  },
  {
    name: 'getDialogTitle',
    type: GetDialogTitle
  },
  {
    name: 'renderContentResult',
    type: RenderContentResult
  },
  {
    name: 'saveDisclosureDataAndContinue',
    type: SaveDisclosureDataAndContinue
  },
  {
    name: 'closeDisclosureDialog',
    type: CloseDisclosureDialog
  },
  {
    name: 'checkApplicationStatus',
    type: CheckApplicationStatus
  },
  {
    name: 'checkDeleteApplication',
    type: CheckDeleteApplication
  },
  {
    name: 'deleteApplication',
    type: DeleteApplication
  },
  {
    name: 'deleteApplicationMultiple',
    type: DeleteApplicationMultiple
  },
  {
    name: 'showDeleteApplicationMultiple',
    type: ShowDeleteApplicationMultiple
  },
  {
    name: 'checkApplicationChanges',
    type: CheckApplicationChanges
  },
  {
    name: 'getOwner',
    type: GetOwner
  },
  {
    name: 'getAddNewBeneficiaryDataSource',
    type: GetAddNewBeneficiaryDataSource
  },
  {
    name: 'editBeneficaryOwnerDialog',
    type: EditBeneficaryOwnerDialog
  },
  {
    name: 'checkInsuredType',
    type: CheckInsuredType
  },
  {
    name: 'getCivilStatus',
    type: GetCivilStatus
  },
  {
    name: 'saveBasicInfo',
    type: SaveBasicInfo
  },
  {
    name: 'cancelDeleteApplicationMultiple',
    type: CancelDeleteApplicationMultiple
  },
  {
    name: 'checkOwnerBeneficiary',
    type: CheckOwnerBeneficiary
  },
  {
    name: 'checkDefaultId',
    type: CheckDefaultId
  },
  {
    name: 'getCreditCards',
    type: GetCreditCards
  },
  {
    name: 'selectCreditCard',
    type: SelectCreditCard
  },
  {
    name: 'loadSupportingDocsDialog',
    type: LoadSupportingDocsDialog
  },
  {
    name: 'checkDocumentVisibility',
    type: CheckDocumentVisibility
  },
  {
    name: 'checkReviewButtonStatus',
    type: CheckReviewButtonStatus
  },
  {
    name: 'exitReviewMode',
    type: ExitReviewMode
  },
  {
    name: 'goToReviewMode',
    type: GoToReviewMode
  },
  {
    name: 'changePaymentMethod',
    type: ChangePaymentMethod
  },
  {
    name: 'submitAis',
    type: SubmitAis
  },
  {
    name: 'submitCas',
    type: SubmitCas
  },
  {
    name: 'resubmitApplication',
    type: ResubmitApplication
  },
  {
    name: 'checkPaymentVisibility',
    type: CheckPaymentVisibility
  },
  {
    name: 'checkRemoveAgreementInsuraceVisibility',
    type: CheckRemoveAgreementInsuraceVisibility
  },
  {
    name: 'getAgentApplications',
    type: GetAgentApplications
  },
  {
    name: 'selectAgentApplication',
    type: SelectAgentApplication
  },
  {
    name: 'checkHideReadonly',
    type: CheckHideReadonly
  },
  {
    name: 'checkShowHideWeightAtBirth',
    type: CheckShowHideWeightAtBirth
  },
  {
    name: 'copyResidentialAddress',
    type: CopyResidentialAddress
  },
  {
    name: 'getInitialPaymentMode',
    type: GetInitialPaymentMode
  },
  {
    name: 'checkHideSignature',
    type: CheckHideSignature
  },
  {
    name: 'checkApplicationViewMode',
    type: CheckApplicationViewMode
  },
  {
    name: 'selectPaymentMethod',
    type: SelectPaymentMethod
  },
  {
    name: 'checkPaymentOnlineVisibility',
    type: CheckPaymentOnlineVisibility
  },
  {
    name: 'checkOwnerType',
    type: CheckOwnerType
  },
  {
    name: 'getSupportingDocsSteps',
    type: GetSupportingDocsSteps
  },
  {
    name: 'getIdentificationUploadMetadata',
    type: GetIdentificationUploadMetadata
  },
  {
    name: 'showDialogSignature',
    type: ShowDialogSignature
  },
  {
    name: 'getSignature',
    type: GetSignature
  },
  {
    name: 'reSignature',
    type: ReSignature
  },
  {
    name: 'getCurrentSignature',
    type: GetCurrentSignature
  },
  {
    name: 'proceedToSubmissionDialog',
    type: ProceedToSubmissionDialog
  },
  {
    name: 'checkProceedButton',
    type: CheckProceedButton
  },
  {
    name: 'getCurrentReport',
    type: GetCurrentReport
  },
  {
    name: 'getUrlReport',
    type: GetUrlReport
  },
  {
    name: 'reviewReportSignature',
    type: ReviewReportSignature
  },
  {
    name: 'getUrlSignature',
    type: GetUrlSignature
  },
  {
    name: 'getPhoneDataByType',
    type: GetPhoneDataByType
  },
  {
    name: 'getPaymentMethod',
    type: GetPaymentMethod
  },
  {
    name: 'getAddressDataByType',
    type: GetAddressDataByType
  },
  {
    name: 'checkDisclosure',
    type: CheckDisclosure
  },
  {
    name: 'checkSameAsResidentialAddressVisibility',
    type: CheckSameAsResidentialAddressVisibility
  },
  {
    name: 'getBeneficiaryTitle',
    type: GetBeneficiaryTitle
  },
  {
    name: 'getApplicationTypeParamValue',
    type: GetApplicationTypeParamValue
  },
  {
    name: 'getPaperApplicationFlagParamValue',
    type: GetPaperApplicationFlagParamValue
  },
  {
    name: 'getAgeParamValue',
    type: GetAgeParamValue
  },
  {
    name: 'getAgeBandParamValue',
    type: GetAgeBandParamValue
  },
  {
    name: 'getGenderParamValue',
    type: GetGenderParamValue
  },
  {
    name: 'getBmiParamValue',
    type: GetBmiParamValue
  },
  {
    name: 'getSmokerStatusParamValue',
    type: GetSmokerStatusParamValue
  },
  {
    name: 'getMyEducationUnbornApplyFlagParamValue',
    type: GetMyEducationUnbornApplyFlagParamValue
  }
];

export * from './signature/get-url-signature';
export * from './get-payment-method';
