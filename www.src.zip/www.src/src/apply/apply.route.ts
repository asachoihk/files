import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplicationListComponent } from './pages/application-list/application-list.component';
import { BasicInfoComponent } from './pages/application-details/basic-info/basic-info.component';
import { CposShellComponent } from '@shared/shells';
import { AgreementsComponent } from './pages/application-details/agreements/agreements.component';
import { DisclosureComponent } from './pages/application-details/disclosure/disclosure.component';
import { LandingComponent } from './pages/application-details/submission/landing/landing.component';
import { AgentQuestionComponent } from './pages/application-details/submission/agent-question/agent-question.component';
import { ApplicationResultComponent } from './pages/application-details/submission/application-result/application-result.component';
import { PaymentComponent } from './pages/application-details/payment/payment.component';
import { SignatureComponent } from './pages/application-details/signature/signature.component';
import { PaymentOnlineComponent } from './pages/application-details/submission/payment-online/payment-online.component';
import { SupportingDocsComponent } from './pages/application-details/supporting-docs/supporting-docs.component';
import { RetryComponent } from './pages/application-details/submission/retry/retry.component';

export const routes: Routes = [
  {
    path: 'apply/applications',
    component: CposShellComponent,
    data: {
      isFullCotent: true
    },
    children: [
      {
        path: '',
        component: ApplicationListComponent
      }
    ]
  },
  {
    path: 'apply/application-details/basic-info',
    component: CposShellComponent,
    children: [
      {
        path: '',
        component: BasicInfoComponent
      }
    ]
  },
  {
    path: 'apply/application-details/agreements',
    component: CposShellComponent,
    children: [
      {
        path: '',
        component: AgreementsComponent
      }
    ]
  },
  {
    path: 'apply/application-details/disclosure',
    component: CposShellComponent,
    children: [
      {
        path: '',
        component: DisclosureComponent
      }
    ]
  },
  {
    path: 'apply/application-details/supporting-docs',
    component: CposShellComponent,
    children: [
      {
        path: '',
        component: SupportingDocsComponent
      }
    ]
  },
  {
    path: 'apply/application-details/signature',
    component: CposShellComponent,
    children: [
      {
        path: '',
        component: SignatureComponent
      }
    ]
  },
  {
    path: 'apply/application-details/submission',
    component: CposShellComponent,
    children: [
      {
        path: '',
        component: LandingComponent
      }
    ]
  },
  {
    path: 'apply/application-details/submission/agent-question',
    component: CposShellComponent,
    children: [
      {
        path: '',
        component: AgentQuestionComponent
      }
    ]
  },
  {
    path: 'apply/application-details/submission/retry',
    component: CposShellComponent,
    children: [
      {
        path: '',
        component: RetryComponent
      }
    ]
  },
  {
    path: 'apply/application-details/submission/application-result',
    component: CposShellComponent,
    children: [
      {
        path: '',
        component: ApplicationResultComponent
      }
    ]
  },
  {
    path: 'apply/application-details/submission/payment-online',
    component: CposShellComponent,
    children: [
      {
        path: '',
        component: PaymentOnlineComponent
      }
    ]
  },
  {
    path: 'apply/application-details/payment',
    component: CposShellComponent,
    children: [
      {
        path: '',
        component: PaymentComponent
      }
    ]
  }
];

export const ApplyRouteModule: ModuleWithProviders = RouterModule.forChild(routes);

