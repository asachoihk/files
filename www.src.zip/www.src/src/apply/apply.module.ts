import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material';
import { SharedModule } from '../shared/shared.module';
import { UserIdleService } from 'angular-user-idle';
import { TranslationService } from 'angular-l10n';
import { RouterModule } from '@angular/router';
import { ACTION_TYPE_CONFIG_TOKEN, CALCULATOR_TYPE_CONFIG_TOKEN, CONVERTER_TYPE_CONFIG_TOKEN, FIELD_TYPE_CONFIG_TOKEN, VALIDATOR_TYPE_CONFIG_TOKEN, SERVICE_TYPE_CONFIG_TOKEN } from 'providers/consts/injection-tokens';
import * as actions from './actions';
import * as calculators from './calculators';
import * as converters from './converters';
import * as components from './components';
import * as applyServices from './services';
import { allApplyPages } from './pages';
import { allApplyDialogs } from './pages';
import { FrameworkModule } from '@framework/framework.module';
import * as validators from './validators';
import { DisclosureModule } from 'disclosure/disclosure.module';
import { ApplyRouteModule } from './apply.route';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    MatButtonModule,
    SharedModule,
    FrameworkModule,
    DisclosureModule,
    ApplyRouteModule
  ],
  declarations: [
    ...components.allApplyComponents,
    ...allApplyPages,
    ...allApplyDialogs
  ],
  providers: [
    TranslationService,
    UserIdleService,
    {
      provide: ACTION_TYPE_CONFIG_TOKEN,
      multi: true,
      useValue: actions.allApplyActionTypeConfigs
    },
    {
      provide: CALCULATOR_TYPE_CONFIG_TOKEN,
      multi: true,
      useValue: calculators.allApplyCalculatorTypeConfigs
    },
    {
      provide: CONVERTER_TYPE_CONFIG_TOKEN,
      multi: true,
      useValue: converters.allApplyConverterTypeConfigs
    },
    {
      provide: FIELD_TYPE_CONFIG_TOKEN,
      multi: true,
      useValue: components.allApplyComponentTypeConfigs
    },
    {
      provide: VALIDATOR_TYPE_CONFIG_TOKEN,
      multi: true,
      useValue: validators.allApplyValidatorTypeConfigs
    },
    {
      provide: SERVICE_TYPE_CONFIG_TOKEN,
      multi: true,
      useValue: applyServices.allApplyServiceTypeConfigs
    },
    ...applyServices.allApplyServices
  ],
  entryComponents: [
    ...components.allApplyComponents,
    ...allApplyDialogs
  ]
})
export class ApplyModule { }
