import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { InsuredModel } from '@apply/models';
import { FormBuilderService } from '@providers';
import { FullName } from './full-name';

class Calculate extends FullName {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

}

class MockFormBuilderService {
  getDisplayValueByFormFieldConfigId() { }

  setFormFieldValue() { }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      default:
        break;
    }
  }
}



describe('FullName', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      calculate.viewModel = new InsuredModel();
      calculate.fieldCalculator = { name: 'fullName', dependentOnFields: ['firstName', 'lastName'], params: '' };
      expect(calculate.calculate()).toBeUndefined();
    });
  });
});
