import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { InsuredModel, BankInfoModel } from '@apply/models';
import { FormBuilderService, ValidatorService } from '@providers';
import { IsBankBranchOrBankSelected } from './is-bank-branch-or-bank-selected';
import { FormControl } from '@angular/forms';

class Calculate extends IsBankBranchOrBankSelected {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

}

class MockFormBuilderService {
  getComponentByFormFieldConfig() {
    return { formControl: new FormControl() };
  }

  setFormFieldValue() { }
}

class MockValidatorService {
  clearValidators() { }

  attachDynamicValidators() { }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'validatorService':
        return new MockValidatorService();
      default:
        break;
    }
  }
}

describe('IsBankBranchOrBankSelected', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService },
        { provide: ValidatorService, useClass: MockValidatorService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run when bankCode is empty', () => {
      calculate.viewModel = new InsuredModel();
      const params = '';
      calculate.formFieldConfig = {
        id: 'accountNo', type: 'textbox'
      };
      expect(calculate.calculate(params)).toBeUndefined();
    });

    it('should be run when bankCode has value', () => {
      const viewModel = new InsuredModel();
      viewModel.person.bankInfo = new BankInfoModel();
      viewModel.person.bankInfo.bankCode = '002';
      calculate.viewModel = viewModel;
      const params = '';
      calculate.formFieldConfig = {
        id: 'accountNo', type: 'textbox'
      };
      expect(calculate.calculate(params)).toBeUndefined();
    });
  });
});
