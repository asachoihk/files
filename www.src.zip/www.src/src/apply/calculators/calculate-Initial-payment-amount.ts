import { BaseCalculator, CurrencyType, LocatorService, FormatterService, FormBuilderService } from '@providers';
import { PaymentService } from '@apply/services';
import { ApplyModel } from '@apply/models';

export class CalculateInitialPaymentAmount extends BaseCalculator {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  calculate(params: any): void {
    const vm = this.viewModel as ApplyModel;
    const initialPayment = this.ls.getService<PaymentService>('paymentService').calculateInitialPayment(vm.totalPayment, params.value);
    const strInitialPayment = this.ls.getService<FormatterService>('formatterService').formatCurrency(initialPayment);
    const formatCurrency = vm && vm.currency === CurrencyType.VND ? '.000 ' + vm.currency : ' ' + vm.currency;
    this.ls.getService<FormBuilderService>('formBuilderService').setFormFieldValue(this.viewModel, this.formFieldConfig, strInitialPayment + formatCurrency);
  }
}
