import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { FormBuilderService } from 'providers/services/form-builder/form-builder.service';
import { of } from 'rxjs/internal/observable/of';
import { SystemEventService } from '@providers';
import { TextboxComponent } from '@shared/ui-elements';
import { CalculateWeight } from './calculate-weight';

class Calculate extends CalculateWeight {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

}

class MockFormBuilderService {
  setFormFieldValue() {

  }
}

class MockSystemEventService {
  publish() {
    return of({});
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'systemEventService':
        return new MockSystemEventService();
      default:
        break;
    }
  }
}



describe('CalculateWeight', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService },
        { provide: SystemEventService, useClass: MockSystemEventService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run when formControl is empty', () => {
      const params = { value: '123' };
      calculate.component = { formControl: '' };
      expect(calculate.calculate(params)).toBeUndefined();
    });

    it('should be run when params = NaN', () => {
      const params = { value: 'NaN' };
      calculate.component = {};
      expect(calculate.calculate(params)).toBeUndefined();
    });

    it('should be run when params = kg2lbs', () => {
      const params = { value: '123' };
      calculate.fieldCalculator = { name: 'calculateHeight', params: 'kg2lbs', dependentOnFields: ['cm'] };
      calculate.component = new TextboxComponent(ls);
      calculate.component.formControl = {
        setValue() {

        }
      };
      expect(calculate.calculate(params)).toBeUndefined();
    });

    it('should be run when params = lbs2kg', () => {
      const params = { value: '123' };
      calculate.fieldCalculator = { name: 'calculateHeight', params: 'lbs2kg', dependentOnFields: ['cm'] };
      calculate.component = new TextboxComponent(ls);
      calculate.component.formControl = {
        setValue() {

        }
      };
      expect(calculate.calculate(params)).toBeUndefined();
    });

    it('should be run when params = lbskg', () => {
      const params = { value: '123' };
      calculate.fieldCalculator = { name: 'calculateHeight', params: 'lbskg', dependentOnFields: ['cm'] };
      calculate.component = new TextboxComponent(ls);
      calculate.component.formControl = {
        setValue() {

        }
      };
      expect(calculate.calculate(params)).toBeUndefined();
    });
  });
});
