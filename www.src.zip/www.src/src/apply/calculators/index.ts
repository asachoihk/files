import { TypeConfig } from 'providers/models/config/type-config';
import { FullName } from './full-name';
import { CalculateHeight } from './calculate-height';
import { ChangeIdNo } from './change-id-no';
import { PopulateBankBranch } from './populate-bank-branch';
import { CalculateWeight } from './calculate-weight';
import { IsBankBranchOrBankSelected } from './is-bank-branch-or-bank-selected';
import { IsAccountNumber } from './is-account-number';
import { IsAccountNumberOrBankSelected } from './is-account-number-or-bank-selected';
import { CalculateStatus } from './calculate-status';
import { CalculateInitialPaymentMode } from './calculate-Initial-payment-mode';
import { CalculateInitialPaymentAmount } from './calculate-Initial-payment-amount';
import { CalculateW8Form } from '@apply/calculators/calculate-w8-form';
import { CalculateRequiredMonthlyIncome } from './calculate-required-monthly-income';
import { ChoosePaymentMethod } from './choose-payment-method';
import { CalculateSameAsResidentialAddressVisibility } from './calculate-same-as-residential-address-visibility';

export const allApplyCalculatorTypeConfigs: TypeConfig[] = [
  {
    name: 'fullName',
    type: FullName
  },
  {
    name: 'calculateHeight',
    type: CalculateHeight
  },
  {
    name: 'calculateWeight',
    type: CalculateWeight
  },
  {
    name: 'changeIdNo',
    type: ChangeIdNo
  },
  {
    name: 'populateBankBranch',
    type: PopulateBankBranch
  },
  {
    name: 'isBankBranchOrBankSelected',
    type: IsBankBranchOrBankSelected
  },
  {
    name: 'isAccountNumber',
    type: IsAccountNumber
  },
  {
    name: 'isAccountNumberOrBankSelected',
    type: IsAccountNumberOrBankSelected
  },
  {
    name: 'calculateStatus',
    type: CalculateStatus
  },
  {
    name: 'calculateInitialPaymentMode',
    type: CalculateInitialPaymentMode
  },
  {
    name: 'calculateInitialPaymentAmount',
    type: CalculateInitialPaymentAmount
  },
  {
    name: 'calculateW8Form',
    type: CalculateW8Form
  },
  {
    name: 'calculateRequiredMonthlyIncome',
    type: CalculateRequiredMonthlyIncome
  },
  {
    name: 'choosePaymentMethod',
    type: ChoosePaymentMethod
  },
  {
    name: 'calculateSameAsResidentialAddressVisibility',
    type: CalculateSameAsResidentialAddressVisibility
  }
];
