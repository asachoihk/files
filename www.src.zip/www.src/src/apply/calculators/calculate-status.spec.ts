import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { CalculateStatus } from './calculate-status';

class Calculate extends CalculateStatus {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      default:
        break;
    }
  }
}



describe('CalculateStatus', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      expect(calculate.calculate()).toBeUndefined();
    });
  });
});
