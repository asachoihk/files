import { BaseCalculator, Visibility, FormBuilderService, LocatorService, SystemEventService } from '@providers';
import { InsuredModel, AgreementModel } from '@apply/models';
import { DocumentDeleted } from 'providers/models/system-event/document-deleted';

export class CalculateW8Form extends BaseCalculator {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  calculate() {
    const fatcaW8Doc = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig);
    const question = this.ls.getService<FormBuilderService>('formBuilderService').getDisplayValueByFormFieldConfigId(this.viewModel, this.fieldCalculator.dependentOnFields[0]);
    const vm = this.viewModel as InsuredModel;
    vm.agreement.requireFatca = false;
    const agreement = vm.agreement as AgreementModel;
    let checkCountry = false;

    // check country
    const country = vm.person.basicInfo.birthPlace.country;
    if (country && country === 'US' || country === 'AS' || country === 'GU' || country === 'MP' || country === 'PR' || country === 'VI') {
      checkCountry = true;
    }
    // check address
    const address = vm.person.contactInfo.address.filter(item => {
      if (item.addressType === 'P') {
        return item;
      }
    });
    if (address[0] && address[0].country === 'US' || address[0].country === 'AS' || address[0].country === 'GU' || address[0].country === 'MP' || address[0].country === 'PR' || address[0].country === 'VI') {
      checkCountry = true;
    }
    // check country code
    const phone = vm.person.contactInfo.phone.filter(item => {
      if (item.phoneType === 'home') {
        return item;
      }
    });
    if (phone[0] && (phone[0].countryCode === '1' || phone[0].countryCode === '+1')) {
      checkCountry = true;
    }
    const citizenship = vm.person.basicInfo.citizenship ? vm.person.basicInfo.citizenship === 'US' : false;
    if (citizenship && fatcaW8Doc) {
      fatcaW8Doc.visibility = Visibility.hidden;
      return;
    }
    if (fatcaW8Doc && (question === this.fieldCalculator.params || checkCountry)) {
      fatcaW8Doc.visibility = Visibility.visible;
      vm.agreement.requireFatca = true;
    } else {
      agreement.fatcaW8Document = [];
      if (fatcaW8Doc) {
        fatcaW8Doc.files = [];
        fatcaW8Doc.visibility = Visibility.hidden;
      }
    }
    this.ls.getService<SystemEventService>('systemEventService').publish(new DocumentDeleted(vm));
  }
}
