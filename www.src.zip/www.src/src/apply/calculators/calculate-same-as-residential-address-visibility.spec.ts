import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { InsuredModel } from '@apply/models';
import { CalculateSameAsResidentialAddressVisibility } from './calculate-same-as-residential-address-visibility';
import { InsuredType, Visibility } from '@providers';

class Calculate extends CalculateSameAsResidentialAddressVisibility {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      default:
        break;
    }
  }
}



describe('CalculateSameAsResidentialAddressVisibility', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      const params = { value: '002' };
      const viewModel = new InsuredModel();
      viewModel.type = InsuredType.o;
      calculate.viewModel = viewModel;
      const component = { visibility: Visibility.hidden };
      calculate.component = component;
      expect(calculate.calculate(params)).toBeUndefined();
    });
  });
});
