import { DynamicValidator, BaseCalculator, Visibility, LocatorService, FormBuilderService, ValidatorService } from '@providers';
import { IncomeSourceModel } from '@apply/models';

export class CalculateRequiredMonthlyIncome extends BaseCalculator {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  calculate() {
    if (this.fieldCalculator && this.fieldCalculator.params) {
      const incomeSourceFieldId = this.fieldCalculator.dependentOnFields[0];
      const incomeSourceComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfigId(incomeSourceFieldId);
      if (incomeSourceComponent) {
        const fieldCalculatorParams = this.fieldCalculator.params;
        const incomeSourceBindingDataPath = fieldCalculatorParams.incomeSourceBindingDataPath;
        const changeRequiredList = fieldCalculatorParams.changeRequiredList;
        const incomeSource = this.ls.getService<FormBuilderService>('formBuilderService').getBindingData(this.viewModel, incomeSourceBindingDataPath) as IncomeSourceModel;
        this.ls.getService<ValidatorService>('validatorService').clearValidators(this.formFieldConfig);

        const control = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig);
        const hasTouched = control.formControl.touched;
        const validators: Array<DynamicValidator> = [];
        if (!incomeSource || !changeRequiredList || !Array.isArray(changeRequiredList) || changeRequiredList.indexOf(incomeSource.occupationId) === -1) {
          control.visibility = Visibility.required;
          validators.push({ name: 'requiredNumber' });
        } else {
          control.visibility = Visibility.visible;
          control.formFieldConfig.visibility = Visibility.visible;
        }
        validators.push({ name: 'maxLengthAmount', params: 9 });
        this.ls.getService<ValidatorService>('validatorService').attachDynamicValidators(validators, control);
        if (!hasTouched) {
          control.formControl.markAsUntouched();
        }
        incomeSource.monthlyIncome ? control.formControl.setValue(incomeSource.monthlyIncome) : control.formControl.setValue('');
      }
    }
  }
}
