import { Injectable } from '@angular/core';
import { LocatorService, BaseCalculator } from '@providers';
import { SubmissionService } from '@apply/services';
import { ApplyModel } from '@apply/models';

@Injectable()
export class ChoosePaymentMethod extends BaseCalculator {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  calculate(params: any): void {
    const value = params && params.value ? params.value : null;
    const viewModel = this.viewModel as ApplyModel;
    this.ls.getService<SubmissionService>('submissionService').choosePaymentmethod(viewModel, value);
  }
}
