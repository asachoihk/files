import { TextboxComponent } from '@shared/ui-elements';
import { ControlValueChanged, BaseCalculator, LocatorService, FormBuilderService, SystemEventService } from '@providers';

export class CalculateHeight extends BaseCalculator {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  calculate(params: any): void {
    const valueChanged = params.value;
    if (isNaN(valueChanged)) {
      return;
    }

    let valueConverted = 0;
    const formControl = (this.component as TextboxComponent).formControl;
    if (!formControl) { return; }

    if (this.fieldCalculator.params === 'cm2m') {
      valueConverted = Math.round(valueChanged / 100 * 100) / 100;
    } else if (this.fieldCalculator.params === 'm2cm') {
      valueConverted = Math.round(valueChanged * 100 * 100) / 100;
    } else {
      return;
    }

    formControl.setValue(valueConverted, { emitEvent: false });
    this.ls.getService<FormBuilderService>('formBuilderService').setFormFieldValue(this.viewModel, this.formFieldConfig, valueConverted);
  }

  protected notifyValueChanges() {
    this.ls.getService<SystemEventService>('systemEventService').publish(new ControlValueChanged(this.component.formControl));
  }
}
