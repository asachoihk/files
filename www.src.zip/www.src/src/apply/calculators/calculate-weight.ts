import { LocatorService, FormBuilderService, SystemEventService, ControlValueChanged, BaseCalculator } from '@providers';
import { TextboxComponent } from '@shared/ui-elements';

export class CalculateWeight extends BaseCalculator {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  calculate(params: any): void {
    const valueChanged = params.value;
    if (isNaN(valueChanged)) {
      return;
    }

    let valueConverted = 0;
    const formControl = (this.component as TextboxComponent).formControl;
    if (!formControl) { return; }

    if (this.fieldCalculator.params === 'kg2lbs') {
      valueConverted = Math.round(valueChanged * 2.20462 * 100) / 100;
    } else if (this.fieldCalculator.params === 'lbs2kg') {
      valueConverted = Math.round(valueChanged / 2.20462 * 100) / 100;
    } else {
      return;
    }

    formControl.setValue(valueConverted, { emitEvent: false });
    this.ls.getService<FormBuilderService>('formBuilderService').setFormFieldValue(this.viewModel, this.formFieldConfig, valueConverted);
  }

  protected notifyValueChanges() {
    this.ls.getService<SystemEventService>('systemEventService').publish(new ControlValueChanged(this.component.formControl));
  }
}
