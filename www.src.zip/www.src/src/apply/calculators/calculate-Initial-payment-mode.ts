import { DataSourceComponent } from '@shared/ui-elements';
import { BaseCalculator, LocatorService, JsonConfigService, FormBuilderService } from '@providers';
import { PaymentService } from '@apply/services';
import { ApplyModel } from '@apply/models';

export class CalculateInitialPaymentMode extends BaseCalculator {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  calculate(params: any): void {
    const vm = this.viewModel as ApplyModel;
    const initialPayment = this.ls.getService<PaymentService>('paymentService').calculateInitialPayment(vm.totalPayment, params.value);
    const paymentMethods = this.ls.getService<JsonConfigService>('jsonConfigService').getInitialPaymentMethod();
    const dataSourceComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as DataSourceComponent;
    if (initialPayment < this.fieldCalculator.params['cashPaymentLimit']) {
      dataSourceComponent.dataSource = paymentMethods;
    } else {
      dataSourceComponent.dataSource = paymentMethods.filter((a) => a.value !== 'CASH');
      if (vm.payment.method === 'CASH') {
        dataSourceComponent.writeValue(null);
      }
    }
  }
}
