import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { ApplyModel, PaymentModel } from '@apply/models';
import { FormBuilderService, ValidatorService, Visibility } from '@providers';
import { PremiumModel } from 'providers/models/premium.model';
import { PaymentMethod } from '@apply/enums';
import { CalculateRequiredMonthlyIncome } from './calculate-required-monthly-income';

class Calculate extends CalculateRequiredMonthlyIncome {
  constructor(public ls: LocatorService) {
    super(ls);
  }

}

class MockFormBuilderService {
  getComponentByFormFieldConfigId() {
    return {
      id: ''
    };
  }

  getComponentByFormFieldConfig() {
    return {
      formControl: {
        touched: true,
        setValue() { }
      },
      visibility: Visibility.required

    };
  }

  getBindingData() {
    return {
      monthlyIncome: 0,
      occupationId: '1'
    };
  }
}

class MockValidatorService {
  clearValidators() {

  }

  attachDynamicValidators() { }
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'validatorService':
        return new MockValidatorService();
      default:
        break;
    }
  }
}

describe('CalculateRequiredMonthlyIncome', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService },
        { provide: ValidatorService, useClass: MockValidatorService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run when occupationId is not in changeRequiredList', () => {

      const viewModel = new ApplyModel();
      viewModel.totalPayment = new PremiumModel();
      viewModel.payment = new PaymentModel();
      viewModel.payment.method = PaymentMethod.CASH;
      calculate.viewModel = viewModel;
      calculate.fieldCalculator = {
        name: '', params: {
          incomeSourceBindingDataPath: 'person.incomeSource',
          changeRequiredList: ['559', '560', '501', '548']
        }, dependentOnFields: []
      };
      expect(calculate.calculate()).toBeUndefined();
    });

    it('should be run when occupationId is in changeRequiredList', () => {

      spyOn(calculate.ls, 'getService').and.returnValue({

        getComponentByFormFieldConfigId() {
          return {
            id: ''
          };
        },

        getComponentByFormFieldConfig() {
          return {
            formControl: {
              touched: false,
              setValue() { },
              markAsUntouched() { }
            },
            formFieldConfig: {
              visibility: Visibility.visible
            },
            visibility: Visibility.required

          };
        },

        getBindingData() {
          return {
            monthlyIncome: 0,
            occupationId: '501'
          };
        },
        clearValidators() {

        },

        attachDynamicValidators() { }
      });
      const viewModel = new ApplyModel();
      viewModel.totalPayment = new PremiumModel();
      viewModel.payment = new PaymentModel();
      viewModel.payment.method = PaymentMethod.CASH;
      calculate.viewModel = viewModel;
      calculate.fieldCalculator = {
        name: '', params: {
          incomeSourceBindingDataPath: 'person.incomeSource',
          changeRequiredList: ['559', '560', '501', '548']
        }, dependentOnFields: []
      };
      expect(calculate.calculate()).toBeUndefined();
    });
  });
});
