import { LocatorService } from 'providers/services';
import { BaseCalculator } from 'providers/calculators/base-calculator';

export class CalculateStatus extends BaseCalculator {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  calculate() {
    // const btnSubmit = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as ButtonComponent;
    // const applyData = this.viewModel as ApplyModel;
    // if (!applyData.declaration_answer) {
    //   btnSubmit.visibility = Visibility.visible;
    // }
    // else {
    //   if (applyData.declaration_answer.agent_question === 'Y') {
    //     applyData.declaration_answer.agent_answer.trim() !== '' ? (btnSubmit.visibility = Visibility.visible) : (btnSubmit.visibility = Visibility.disabled);
    //   } else if (applyData.declaration_answer.agent_question === 'N') {
    //     btnSubmit.visibility = Visibility.visible;
    //   }
    // }
  }
}
