
import { LocatorService, FormBuilderService, JsonConfigService, ChipListMetadata, BaseCalculator } from '@providers';
import { AddressChipListComponent } from '@shared/components';
import { InsuredModel } from '@apply/models';

export class ChangeIdNo extends BaseCalculator {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    calculate(_params: any): void {
        const key = this.formFieldConfig;
        const target = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(key) as AddressChipListComponent;
        if (!target) {
            return;
        }
        const vm = this.viewModel as InsuredModel;
        const metadata = target.formFieldConfig.metadata as ChipListMetadata;

        if (_params && _params.value && _params.value.length === 12 && vm.person.registration.idType === 1) {
            target.dataSource = [];
            const item = {
                display: 'Cục CS ĐKQL Cư Trú Và DLQG Về Dân Cư',
                value: 'Cục CS ĐKQL Cư Trú Và DLQG Về Dân Cư',
                selected: true
            };
            target.dataSource.push(item);
            metadata.allowAdd = false;
            target.onDataSourceLoaded();
            target.toggleValue(item);
        } else if (_params && _params.value && _params.value.length === 9 && vm.person.registration.idType === 1 && vm.person.registration.issuePlace) {
            const displayValue = vm.person.registration.issuePlace.replace('CA.', '').trim();
            const provinces = this.ls.getService<JsonConfigService>('jsonConfigService').getProvinces(displayValue);
            if (provinces && provinces.length > 0) {
                vm.person.registration.issuePlace = provinces[0].value;
            }
            target.loadDataSource();
            metadata.allowAdd = true;
        } else {
            target.loadDataSource();
            metadata.allowAdd = true;
        }
    }
}
