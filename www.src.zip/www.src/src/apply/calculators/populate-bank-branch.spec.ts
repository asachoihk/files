import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { FormBuilderService } from 'providers/services/form-builder/form-builder.service';
import { JsonConfigService } from '@providers';
import { PopulateBankBranch } from './populate-bank-branch';

class Calculate extends PopulateBankBranch {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

}

class MockFormBuilderService {
  getComponentByFormFieldConfig() {
    return {
      dataSource: [
        {
          BANK_CD: '92304001',
          BANK_NM: 'DONG A - CN CAN THO',
          REC_STATUS: 'A',
          BANK_ID: '002',
          REFER_CODE: '79304001'
        }
      ]
    };
  }
}

class MockJsonConfigService {
  getBankBranchesByBankCode() {
    return {
      BANK_CD: '92304001',
      BANK_NM: 'DONG A - CN CAN THO',
      REC_STATUS: 'A',
      BANK_ID: '002',
      REFER_CODE: '79304001'
    };
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'jsonConfigService':
        return new MockJsonConfigService();
      default:
        break;
    }
  }
}



describe('PopulateBankBranch', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService },
        { provide: JsonConfigService, useClass: MockJsonConfigService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      const params = { value: '002' };
      calculate.formFieldConfig = {
        id: 'bankBranch',
        label: 'CPOS0091',
        type: 'dropdown'
      };

      expect(calculate.calculate(params)).toBeUndefined();
    });
  });
});
