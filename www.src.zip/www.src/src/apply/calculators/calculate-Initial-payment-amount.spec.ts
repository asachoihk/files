import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { ApplyModel } from '@apply/models';
import { FormBuilderService, FormatterService } from '@providers';
import { PaymentService } from '@apply/services';
import { PremiumModel } from 'providers/models/premium.model';
import { CalculateInitialPaymentAmount } from './calculate-Initial-payment-amount';

class Calculate extends CalculateInitialPaymentAmount {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

}

class MockFormBuilderService {
  setFormFieldValue() { }
}

class MockPaymentService {
  constructor() { }
  calculateInitialPayment(premium, paymentMethod) {
    return 28836;
  }
}

class MockFormatterService {
  constructor() { }

  formatCurrency() {
    return '28,836';
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'formatterService':
        return new MockFormatterService();
      default:
        break;
    }
  }

  get() {
    return new MockPaymentService();
  }
}

describe('CalculateInitialPaymentAmount', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService },
        { provide: PaymentService, useClass: MockPaymentService },
        { provide: FormatterService, useClass: MockFormatterService },
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run when bankCode is empty', () => {
      const viewModel = new ApplyModel();
      viewModel.totalPayment = new PremiumModel();
      calculate.viewModel = viewModel;
      const params = { value: '' };
      calculate.formFieldConfig = {
        id: 'accountNo', type: 'textbox'
      };
      expect(calculate.calculate(params)).toBeUndefined();
    });
  });
});
