import { BaseAction, LocatorService, Visibility, InsuredType } from '@providers';
import { InsuredModel } from '@apply/models';
import { CalculateCheckboxToVisibility } from '@shared/calculators/calculate-checkbox-to-visibility';

export class CalculateSameAsResidentialAddressVisibility extends CalculateCheckboxToVisibility {
  constructor(protected ls: LocatorService) {
    super(ls);
  }
  
  calculate(params: any): void {
    const insuredPerson = this.viewModel as InsuredModel;
    if (insuredPerson.type !== InsuredType.i && insuredPerson.type !== InsuredType.r) {
      super.calculate(params);
    }
  }
}