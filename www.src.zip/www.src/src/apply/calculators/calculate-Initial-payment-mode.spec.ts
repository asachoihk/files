import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { ApplyModel, PaymentModel } from '@apply/models';
import { FormBuilderService, JsonConfigService } from '@providers';
import { PaymentService } from '@apply/services';
import { PremiumModel } from 'providers/models/premium.model';
import { CalculateInitialPaymentMode } from './calculate-Initial-payment-mode';
import { PaymentMethod } from '@apply/enums';

class Calculate extends CalculateInitialPaymentMode {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

}

class MockFormBuilderService {
  getComponentByFormFieldConfig() {
    return {
      writeValue() {

      }
    };
  }
}

class MockPaymentService {
  calculateInitialPayment(premium, paymentMethod) {
    return 28836;
  }
}


class MockJsonConfigService {
  getInitialPaymentMethod() {
    return [
      {
        label: 'Bank Transfer',
        value: 'BT'
      },
      {
        label: 'POS Payment',
        value: 'POS'
      }
    ];
  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'jsonConfigService':
        return new MockJsonConfigService();
      default:
        break;
    }
  }

  get() {
    return new MockPaymentService();
  }
}

describe('CalculateInitialPaymentMode', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService },
        { provide: PaymentService, useClass: MockPaymentService },
        { provide: JsonConfigService, useClass: MockJsonConfigService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run when cashPaymentLimit is smaller than initialPayment', () => {

      const viewModel = new ApplyModel();
      viewModel.totalPayment = new PremiumModel();
      viewModel.payment = new PaymentModel();
      viewModel.payment.method = PaymentMethod.CASH;
      calculate.viewModel = viewModel;
      const params = { value: 123 };
      calculate.fieldCalculator = { name: '', params: { cashPaymentLimit: '123' }, dependentOnFields: [] };
      expect(calculate.calculate(params)).toBeUndefined();
    });

    it('should be run when initialPayment is smaller than cashPaymentLimit', () => {

      const viewModel = new ApplyModel();
      viewModel.totalPayment = new PremiumModel();
      viewModel.payment = new PaymentModel();
      viewModel.payment.method = PaymentMethod.CASH;
      calculate.viewModel = viewModel;
      const params = { value: 29836 };
      calculate.fieldCalculator = { name: '', params: { cashPaymentLimit: '29836' }, dependentOnFields: [] };
      expect(calculate.calculate(params)).toBeUndefined();
    });
  });
});
