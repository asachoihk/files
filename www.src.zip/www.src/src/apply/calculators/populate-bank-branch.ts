import { LocatorService, FormBuilderService, JsonConfigService, BaseCalculator } from '@providers';
import { DataSourceComponent } from '@shared/ui-elements';

export class PopulateBankBranch extends BaseCalculator {
    constructor(protected ls: LocatorService) {
        super(ls);
    }

    calculate(params: any) {
        const bankCode = params.value;
        const dataSourceComponent = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as DataSourceComponent;
        dataSourceComponent.dataSource = this.ls.getService<JsonConfigService>('jsonConfigService').getBankBranchesByBankCode(bankCode);
    }
}
