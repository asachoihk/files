import { LocatorService, ValidatorService, DynamicValidator, FormBuilderService, BaseCalculator } from '@providers';
import { BaseControlComponent } from '@shared/ui-elements';
import { InsuredModel } from '@apply/models';


export class IsAccountNumberOrBankSelected extends BaseCalculator {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  calculate(_params: any) {
    this.ls.getService<ValidatorService>('validatorService').clearValidators(this.formFieldConfig);
    const control = this.ls.getService<FormBuilderService>('formBuilderService').getComponentByFormFieldConfig(this.formFieldConfig) as BaseControlComponent;
    const hasTouched = control.formControl.touched;
    const bankModel = this.viewModel as InsuredModel;
    const validators: Array<DynamicValidator> = [];
    if (bankModel.person.bankInfo && (bankModel.person.bankInfo.accountNo || bankModel.person.bankInfo.bankCode)) {
      validators.push({ name: 'requiredApply' });
    }
    this.ls.getService<ValidatorService>('validatorService').attachDynamicValidators(validators, this);
    if (!hasTouched) {
      control.formControl.markAsUntouched();
    }
  }
}
