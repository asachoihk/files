import { LocatorService, FormBuilderService, BaseCalculator } from '@providers';
import { Injectable } from '@angular/core';

@Injectable()
export class FullName extends BaseCalculator {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  calculate(): void {
    const firstName = this.ls.getService<FormBuilderService>('formBuilderService').getDisplayValueByFormFieldConfigId(this.viewModel, this.fieldCalculator.dependentOnFields[0]);
    const lastName = this.ls.getService<FormBuilderService>('formBuilderService').getDisplayValueByFormFieldConfigId(this.viewModel, this.fieldCalculator.dependentOnFields[1]);
    const fullName = firstName + ' ' + lastName;

    this.ls.getService<FormBuilderService>('formBuilderService').setFormFieldValue(this.viewModel, this.formFieldConfig, fullName);
  }
}
