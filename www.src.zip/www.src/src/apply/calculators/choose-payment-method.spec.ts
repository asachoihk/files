import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { ChoosePaymentMethod } from './choose-payment-method';
import { SubmissionService } from '@apply/services';
import { ApplyModel } from '@apply/models';

class Calculate extends ChoosePaymentMethod {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

}

class MockSubmissionService {
  choosePaymentmethod() {

  }
}

class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'submissionService':
        return new MockSubmissionService();
      default:
        break;
    }
  }
}



describe('ChoosePaymentMethod', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: SubmissionService, useClass: MockSubmissionService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run', () => {
      const params = { value: '002' };
      calculate.viewModel = new ApplyModel();
      expect(calculate.calculate(params)).toBeUndefined();
    });
  });
});
