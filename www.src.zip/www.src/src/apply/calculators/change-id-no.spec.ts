import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { InsuredModel, RegistrationModel } from '@apply/models';
import { FormBuilderService, JsonConfigService } from '@providers';
import { ChangeIdNo } from './change-id-no';

class Calculate extends ChangeIdNo {
  constructor(public ls: LocatorService) {
    super(ls);
  }

}

class MockFormBuilderService {

  getComponentByFormFieldConfig() {
    return {
      onDataSourceLoaded() { },
      toggleValue() { },
      loadDataSource() { },
      formFieldConfig: {
        metadata: {
          allowAdd: true
        }
      }
    };
  }
}

class MockJsonConfigService {
  getProvinces() {
    return [{
      value: '29',
      display: 'Thành phố Hồ Chí Minh'
    }];
  }
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'jsonConfigService':
        return new MockJsonConfigService();
      default:
        break;
    }
  }
}

describe('ChangeIdNo', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService },
        { provide: JsonConfigService, useClass: MockJsonConfigService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run when length of params = 12', () => {
      const params = { value: '123456789012' };
      const insuredModel = new InsuredModel();
      insuredModel.person.registrations = [new RegistrationModel()];
      insuredModel.person.registrations[0].idType = 1;
      calculate.viewModel = insuredModel;
      expect(calculate.calculate(params)).toBeUndefined();
    });

    it('should be run when length of params = 9', () => {
      const params = { value: '123456789' };
      const insuredModel = new InsuredModel();
      insuredModel.person.registrations = [new RegistrationModel()];
      insuredModel.person.registrations[0].idType = 1;
      insuredModel.person.registrations[0].issuePlace = 'CA.Thành phố Hồ Chí Minh';
      calculate.viewModel = insuredModel;
      expect(calculate.calculate(params)).toBeUndefined();
    });

    it('should be run when length of params = 8', () => {
      const params = { value: '12345678' };
      const insuredModel = new InsuredModel();
      insuredModel.person.registrations = [new RegistrationModel()];
      insuredModel.person.registrations[0].idType = 1;
      insuredModel.person.registrations[0].issuePlace = 'CA.Thành phố Hồ Chí Minh';
      calculate.viewModel = insuredModel;
      expect(calculate.calculate(params)).toBeUndefined();
    });

    it('should be run when target is null', () => {
      const params = { value: '12345678' };
      const insuredModel = new InsuredModel();
      insuredModel.person.registrations = [new RegistrationModel()];
      insuredModel.person.registrations[0].idType = 1;
      insuredModel.person.registrations[0].issuePlace = 'CA.Thành phố Hồ Chí Minh';
      calculate.viewModel = insuredModel;

      spyOn(calculate.ls, 'getService').and.returnValue({

        getProvinces() {
        },
        getComponentByFormFieldConfig() {
        }
      });

      expect(calculate.calculate(params)).toBeUndefined();
    });
  });
});
