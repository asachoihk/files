import { TestBed } from '@angular/core/testing';
import { LocatorService } from 'providers/services/locator/locator.service';
import { InsuredModel, AgreementModel, PersonBasicInfo, ContactInfoModel, PhoneNumberModel } from '@apply/models';
import { FormBuilderService, Visibility, SystemEventService, PersonAddressModel } from '@providers';
import { CalculateW8Form } from './calculate-w8-form';

class Calculate extends CalculateW8Form {
  constructor(public ls: LocatorService) {
    super(ls);
  }

}

class MockFormBuilderService {
  getDisplayValueByFormFieldConfigId() {
    return 'Y';
  }

  getComponentByFormFieldConfig() {
    return {
      id: '',
      visibility: Visibility.hidden
    };
  }
}

class MockSystemEventService {
  publish() { }
}


class MockLocatorService {
  getService(serviceName: string) {
    switch (serviceName) {
      case 'formBuilderService':
        return new MockFormBuilderService();
      case 'systemEventService':
        return new MockSystemEventService();
      default:
        break;
    }
  }
}

describe('CalculateW8Form', () => {
  let calculate: Calculate;
  let ls: LocatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService },
        { provide: SystemEventService, useClass: MockSystemEventService }
      ],
    });
    ls = TestBed.get(LocatorService);
  });
  beforeEach(() => {
    calculate = new Calculate(ls);
  });


  it('should be created', () => {
    expect(calculate).toBeTruthy();
  });

  describe('Function - Excute', () => {
    it('should be run when phoneType = home', () => {
      const insuredModel = new InsuredModel();
      insuredModel.agreement = new AgreementModel();
      insuredModel.person.basicInfo = new PersonBasicInfo();
      insuredModel.person.basicInfo.birthPlace.country = 'US';
      insuredModel.person.basicInfo.citizenship = 'US';
      insuredModel.person.contactInfo = new ContactInfoModel();
      insuredModel.person.contactInfo.address = [new PersonAddressModel()];
      insuredModel.person.contactInfo.phone = [new PhoneNumberModel()];
      insuredModel.person.contactInfo.phone[0].phoneType = 'home' ;
      calculate.viewModel = insuredModel;
      calculate.fieldCalculator = {
        name: 'calculateW8Form',
        dependentOnFields: ['question'],
        params: 'Y'
      };
      expect(calculate.calculate()).toBeUndefined();
    });

    it('should be run when countryCode = 1', () => {
      const insuredModel = new InsuredModel();
      insuredModel.agreement = new AgreementModel();
      insuredModel.person.basicInfo = new PersonBasicInfo();
      insuredModel.person.basicInfo.birthPlace.country = 'VN';
      insuredModel.person.basicInfo.citizenship = 'VN';
      insuredModel.person.contactInfo = new ContactInfoModel();
      insuredModel.person.contactInfo.address = [new PersonAddressModel()];
      insuredModel.person.contactInfo.address[0].country = 'US';
      insuredModel.person.contactInfo.phone = [new PhoneNumberModel()];
      insuredModel.person.contactInfo.phone[0].countryCode = '1' ;
      insuredModel.person.contactInfo.phone[0].phoneType = 'home' ;
      calculate.viewModel = insuredModel;
      calculate.fieldCalculator = {
        name: 'calculateW8Form',
        dependentOnFields: ['question'],
        params: 'Y'
      };
      expect(calculate.calculate()).toBeUndefined();
    });

    it('should be run when question is N', () => {

      spyOn(calculate.ls, 'getService').and.returnValue({

        getComponentByFormFieldConfig() {
          return {
            id: '',
            visibility: Visibility.hidden
          };
        },
        getDisplayValueByFormFieldConfigId() {
          return 'N';
        },
        publish() {
          return;
        }
      });

      const insuredModel = new InsuredModel();
      insuredModel.agreement = new AgreementModel();
      insuredModel.person.basicInfo = new PersonBasicInfo();
      insuredModel.person.basicInfo.birthPlace.country = 'VN';
      insuredModel.person.basicInfo.citizenship = 'VN';
      insuredModel.person.contactInfo = new ContactInfoModel();
      insuredModel.person.contactInfo.address = [new PersonAddressModel()];
      insuredModel.person.contactInfo.phone = [new PhoneNumberModel()];
      calculate.viewModel = insuredModel;
      calculate.fieldCalculator = {
        name: 'calculateW8Form',
        dependentOnFields: ['question'],
        params: 'Y'
      };
      expect(calculate.calculate()).toBeUndefined();
    });
  });
});
