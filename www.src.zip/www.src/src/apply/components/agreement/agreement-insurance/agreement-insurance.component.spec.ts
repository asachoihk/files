import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgreementInsuranceComponent } from './agreement-insurance.component';
import { InsuredModel } from '@apply/models';
import { Component, Input } from '@angular/core';
import { BaseModel, FormField, LocatorService } from '@providers';

class MockActionService {
  executeFieldAction() { }
  retreiveActionResult() { }
}

class MockLocatorService {
  getService(name) {
    switch (name) {
      case 'actionService':
        return new MockActionService();
      default:
    }
  }
}

@Component({
  selector: 'cpos-form-builder',
  template: '<p>Mock CPOS Form Component</p>'
})

class MockFormBuilderComponent {
  @Input() viewModel: BaseModel;
  @Input() jsonName: string;
  @Input() parentViewModel: BaseModel;
  @Input() parentFormFieldConfig: FormField;

}

describe('AgreementInsuranceComponent', () => {
  let component: AgreementInsuranceComponent;
  let fixture: ComponentFixture<AgreementInsuranceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
      declarations: [AgreementInsuranceComponent, MockFormBuilderComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgreementInsuranceComponent);
    component = fixture.componentInstance;

    component.formFieldConfig = { id: 'specField', type: 'specType' };
    component.parentFormFieldConfig = { id: 'specField', type: 'specType' };
    component.viewModel = new InsuredModel();

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
