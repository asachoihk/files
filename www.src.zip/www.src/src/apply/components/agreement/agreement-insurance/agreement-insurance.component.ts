import { Component, Input } from '@angular/core';
import { LocatorService } from '@providers';
import { BaseComponent } from '@shared/ui-elements';
import { InsuranceModel } from '@apply/models';

@Component({
  selector: 'cpos-agreement-insurance',
  templateUrl: './agreement-insurance.component.html',
  styleUrls: ['./agreement-insurance.component.scss']
})
export class AgreementInsuranceComponent extends BaseComponent {

  @Input() insurance: InsuranceModel;
  @Input() parentFormFieldConfig: any;
  @Input() parentViewModel: any;
  constructor(protected ls: LocatorService) {
    super(ls);
  }
}

