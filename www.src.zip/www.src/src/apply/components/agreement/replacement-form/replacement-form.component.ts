import { Component } from '@angular/core';
import { LocatorService } from '@providers';
import { BaseComponent } from '@shared/ui-elements';
@Component({
  selector: 'cpos-replacement-form',
  templateUrl: './replacement-form.component.html',
  styleUrls: ['./replacement-form.component.scss']
})
export class ReplacementFormComponent extends BaseComponent {
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit() {
    super.ngAfterViewInit();
    // FieldActionType
  }
}
