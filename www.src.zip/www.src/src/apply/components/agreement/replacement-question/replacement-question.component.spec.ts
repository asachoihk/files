import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplacementQuestionComponent } from './replacement-question.component';
import { LocatorService, BaseModel, FormField } from '@providers';
import { Component, Input, PipeTransform, Pipe } from '@angular/core';

//////////////////////////////////////////
///////////// Mocking Area ///////////////
//////////////////////////////////////////
class MockActionService {
  executeFieldAction() { }
  retreiveActionResult() { }
}

class MockLocatorService {
  getService(name) {
    switch (name) {
      case 'actionService':
        return new MockActionService();
      default:
    }
  }
}

@Component({
  selector: 'cpos-form-builder',
  template: '<p>Mock CPOS Form Component</p>'
})
class MockFormBuilderComponent {
  @Input() viewModel: BaseModel;
  @Input() jsonName: string;
  @Input() parentViewModel: BaseModel;
  @Input() parentFormFieldConfig: FormField;

  @Input() fxFlex: any;
}

@Pipe({name: 'flexColumn'})
class MockFlexColumnPipe implements PipeTransform {
  transform(): any {
    return '';
  }
}

//////////////////////////////////////////
//////////// End Mocking Area ////////////
//////////////////////////////////////////

describe('ReplacementQuestionComponent', () => {
  let component: ReplacementQuestionComponent;
  let fixture: ComponentFixture<ReplacementQuestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
      declarations: [
        ReplacementQuestionComponent,
        MockFormBuilderComponent,
        MockFlexColumnPipe,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplacementQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
