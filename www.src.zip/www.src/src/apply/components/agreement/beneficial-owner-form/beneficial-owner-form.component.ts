import { Component } from '@angular/core';
import { LocatorService } from '@providers';
import { BaseComponent } from '@shared/ui-elements';
@Component({
  selector: 'cpos-beneficial-owner-form',
  templateUrl: './beneficial-owner-form.component.html',
  styleUrls: ['./beneficial-owner-form.component.scss']
})
export class BeneficialOwnerFormComponent extends BaseComponent {
  constructor(protected ls: LocatorService) {
    super(ls);
  }
}
