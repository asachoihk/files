import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BeneficialOwnerFormComponent } from './beneficial-owner-form.component';
import { LocatorService, FormField, BaseModel } from '@providers';
import { InsuredModel } from '@apply/models';
import { PipeTransform, Pipe, Input, Directive, Component } from '@angular/core';

@Component({
  selector: 'cpos-form-builder',
  template: '<p>Mock CPOS Form Component</p>'
})
class MockFormBuilderComponent {
  @Input() viewModel: BaseModel;
  @Input() jsonName: string;
  @Input() parentViewModel: BaseModel;
  @Input() parentFormFieldConfig: FormField;

  @Input() fxFlex: any;
}

@Pipe({name: 'flexColumn'})
class MockFlexColumnPipe implements PipeTransform {
  transform(): any {
    return '';
  }
}


class MockActionService {
  executeFieldAction() { }
  retreiveActionResult() { }
}

class MockLocatorService {
  getService(name) {
    switch (name) {
      case 'actionService':
        return new MockActionService();
      default:
    }
  }
}

describe('BeneficialOwnerFormComponent', () => {
  let component: BeneficialOwnerFormComponent;
  let fixture: ComponentFixture<BeneficialOwnerFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
      declarations: [ BeneficialOwnerFormComponent, MockFormBuilderComponent,
        MockFlexColumnPipe ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BeneficialOwnerFormComponent);
    component = fixture.componentInstance;
    component.formFieldConfig = { id: 'specField', type: 'specType'};
    component.parentFormFieldConfig = { id: 'specField', type: 'specType'};
    component.viewModel = new InsuredModel();

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
