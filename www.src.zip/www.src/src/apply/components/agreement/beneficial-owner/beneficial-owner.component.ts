import { Component, Input } from '@angular/core';
import { LocatorService } from '@providers';
import { BaseComponent } from '@shared/ui-elements';
import { BeneficialOwnerModel } from '@apply/models';

@Component({
  selector: 'cpos-beneficial-owner',
  templateUrl: './beneficial-owner.component.html',
  styleUrls: ['./beneficial-owner.component.scss']
})
export class BeneficialOwnerComponent extends BaseComponent {
  @Input() beneficialOwner: BeneficialOwnerModel;
  @Input() parentFormFieldConfig: any;
  @Input() parentViewModel: any;
  constructor(protected ls: LocatorService) {
    super(ls);
  }


}
