import { Component } from '@angular/core';
import { LocatorService, FormBuilderService } from '@providers';
import { BaseComponent } from '@shared/ui-elements';
import { BeneficialOwnerModel } from '@apply/models';

@Component({
  selector: 'cpos-beneficial-owner-list',
  templateUrl: './beneficial-owner-list.component.html',
  styleUrls: ['./beneficial-owner-list.component.scss']
})
export class BeneficialOwnerListComponent extends BaseComponent {

  constructor(protected ls: LocatorService) {
    super(ls);
  }

  dataSource: BeneficialOwnerModel[];


  onFormFieldConfigLoaded() {
    this.loadDataSource();
  }

  loadDataSource() {
    this.dataSource = this.ls.getService<FormBuilderService>('formBuilderService').getBindingData(this.viewModel, this.formFieldConfig.dataBinding.path);
  }

}
