import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BeneficialOwnerListComponent } from './beneficial-owner-list.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { LocatorService, FormBuilderService, BaseModel, FormField } from '@providers';
import { Input, Component, Pipe, PipeTransform } from '@angular/core';
import { InsuredModel } from '@apply/models';

class MockActionService {
  executeFieldAction() { }
  retreiveActionResult() { }
}

@Component({
  selector: 'cpos-beneficial-owner',
  template: '<p>Mock CPOS Form Component</p>'
})
class MockBeneficialOwnerComponent {
  @Input() beneficialOwner: any;
  @Input() parentViewModel: BaseModel;
  @Input() parentFormFieldConfig: FormField;
}

@Pipe({ name: 'flexColumn' })
class MockFlexColumnPipe implements PipeTransform {
  transform(): any {
    return '';
  }
}

class MockFormBuilderService {
  getBindingData() {
    return [{
      firstName: 'first name',
      lastName: 'last name',
      _guid: '71b99694-451e-42ec-a787-f16d2a86a20f'
    }];
  }
}

class MockLocatorService {
  getService(name) {
    switch (name) {
      case 'actionService':
        return new MockActionService();
      case 'formBuilderService':
        return new MockFormBuilderService();
      default:
    }
  }
}

describe('BeneficialOwnerListComponent', () => {
  let component: BeneficialOwnerListComponent;
  let fixture: ComponentFixture<BeneficialOwnerListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FlexLayoutModule,
      ],
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService }
      ],
      declarations: [BeneficialOwnerListComponent, MockBeneficialOwnerComponent, MockFlexColumnPipe]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BeneficialOwnerListComponent);
    component = fixture.componentInstance;

    component.formFieldConfig = { id: 'specField', type: 'specField', dataBinding: { path: 'agreement.beneficialOwners' } };
    component.parentFormFieldConfig = { id: 'specField', type: 'specType' };
    component.viewModel = new InsuredModel();

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Function - onFormFieldConfigLoaded', () => {

    it('should be run', () => {
      component.onFormFieldConfigLoaded();

      expect(JSON.stringify(component.dataSource)).toEqual(JSON.stringify([{
        firstName: 'first name',
        lastName: 'last name',
        _guid: '71b99694-451e-42ec-a787-f16d2a86a20f'
      }]));
    });
  });
});
