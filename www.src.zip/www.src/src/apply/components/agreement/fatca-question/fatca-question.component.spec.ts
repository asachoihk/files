import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FatcaQuestionComponent } from './fatca-question.component';
import { Component, Input, Directive, PipeTransform, Pipe } from '@angular/core';
import { BaseModel, FormField, LocatorService } from '@providers';
import { ApplyModel } from '@apply/models';

//////////////////////////////////////////
///////////// Mocking Area ///////////////
//////////////////////////////////////////
@Component({
  selector: 'cpos-form-builder',
  template: '<p>Mock CPOS Form Component</p>'
})
class MockFormBuilderComponent {
  @Input() viewModel: BaseModel;
  @Input() jsonName: string;
  @Input() parentViewModel: BaseModel;
  @Input() parentFormFieldConfig: FormField;

  @Input() fxFlex: any;
}

@Directive({
  selector: '[cpos-events-handler]'
})
class EventsHandlerDirective {
  @Input('cpos-events-handler') hostsParams: any;
}

@Pipe({name: 'flexColumn'})
class MockFlexColumnPipe implements PipeTransform {
  transform(): any {
    return '';
  }
}


class MockActionService {
  executeFieldAction() { }
  retreiveActionResult() { }
}

class MockLocatorService {
  getService(name) {
    switch (name) {
      case 'actionService':
        return new MockActionService();
      default:
    }
  }
}

//////////////////////////////////////////
//////////// End Mocking Area ////////////
//////////////////////////////////////////

describe('FatcaQuestionComponent', () => {
  let component: FatcaQuestionComponent;
  let fixture: ComponentFixture<FatcaQuestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
      declarations: [
        FatcaQuestionComponent,
        MockFormBuilderComponent,
        EventsHandlerDirective,
        MockFlexColumnPipe,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FatcaQuestionComponent);
    component = fixture.componentInstance;
    component.formFieldConfig = { id: 'specField', type: 'specType'};
    component.parentFormFieldConfig = { id: 'specField', type: 'specType'};
    component.viewModel = new ApplyModel();

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
