import { Component } from '@angular/core';
import { LocatorService } from '@providers';
import { BaseComponent } from '@shared/ui-elements';

@Component({
  selector: 'cpos-fatca-question',
  templateUrl: './fatca-question.component.html',
  styleUrls: ['./fatca-question.component.scss']
})
export class FatcaQuestionComponent extends BaseComponent {
  constructor(protected ls: LocatorService) {
    super(ls);
  }
}
