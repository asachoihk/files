import { Component } from '@angular/core';
import { LocatorService } from '@providers';
import { BaseComponent } from '@shared/ui-elements';

@Component({
  selector: 'cpos-fatca-w9-form',
  templateUrl: './fatca-w9-form.component.html',
  styleUrls: ['./fatca-w9-form.component.scss']
})
export class FatcaW9FormComponent extends BaseComponent {

  constructor(protected ls: LocatorService) {
    super(ls);
  }

}
