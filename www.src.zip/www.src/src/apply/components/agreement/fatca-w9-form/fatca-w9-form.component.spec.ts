import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FatcaW9FormComponent } from './fatca-w9-form.component';
import { Pipe, PipeTransform, Input, Component } from '@angular/core';
import { BaseModel, FormField, LocatorService } from '@providers';

//////////////////////////////////////////
///////////// Mocking Area ///////////////
//////////////////////////////////////////
class MockActionService {
  executeFieldAction() { }
  retreiveActionResult() { }
}

class MockLocatorService {
  getService(name) {
    switch (name) {
      case 'actionService':
        return new MockActionService();
      default:
    }
  }
}

@Component({
  selector: 'cpos-form-builder',
  template: '<p>Mock CPOS Form Component</p>'
})
class MockFormBuilderComponent {
  @Input() viewModel: BaseModel;
  @Input() jsonName: string;
  @Input() parentViewModel: BaseModel;
  @Input() parentFormFieldConfig: FormField;

  @Input() fxFlex: any;
}

@Pipe({name: 'flexColumn'})
class MockFlexColumnPipe implements PipeTransform {
  transform(): any {
    return '';
  }
}

//////////////////////////////////////////
//////////// End Mocking Area ////////////
//////////////////////////////////////////

describe('FatcaW9FormComponent', () => {
  let component: FatcaW9FormComponent;
  let fixture: ComponentFixture<FatcaW9FormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
      ],
      declarations: [
        FatcaW9FormComponent,
        MockFormBuilderComponent,
        MockFlexColumnPipe,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FatcaW9FormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
