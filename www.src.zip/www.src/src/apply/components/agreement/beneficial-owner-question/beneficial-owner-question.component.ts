import { Component } from '@angular/core';
import { LocatorService } from '@providers';
import { BaseComponent } from '@shared/ui-elements';

@Component({
  selector: 'cpos-beneficial-owner-question',
  templateUrl: './beneficial-owner-question.component.html',
  styleUrls: ['./beneficial-owner-question.component.scss']
})
export class BeneficialOwnerQuestionComponent extends BaseComponent {
  constructor(protected ls: LocatorService) {
    super(ls);
  }
}
