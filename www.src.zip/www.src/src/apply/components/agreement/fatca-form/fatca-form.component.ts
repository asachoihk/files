import { Component } from '@angular/core';
import { LocatorService } from '@providers';
import { BaseComponent } from '@shared/ui-elements';

@Component({
  selector: 'cpos-fatca-form',
  templateUrl: './fatca-form.component.html',
  styleUrls: ['./fatca-form.component.scss']
})
export class FatcaFormComponent extends BaseComponent {
  constructor(protected ls: LocatorService) {
    super(ls);
  }
}
