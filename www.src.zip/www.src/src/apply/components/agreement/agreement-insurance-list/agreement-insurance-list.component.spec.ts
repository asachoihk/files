import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AgreementInsuranceListComponent } from './agreement-insurance-list.component';
import { InsuredModel } from '@apply/models';
import { PipeTransform, Pipe, Input, Component } from '@angular/core';
import { FormField, BaseModel, LocatorService, FormBuilderService } from '@providers';
import { FlexLayoutModule } from '@angular/flex-layout';

class MockActionService {
  executeFieldAction() { }
  retreiveActionResult() { }
}

@Component({
  selector: 'cpos-agreement-insurance',
  template: '<p>Mock CPOS Form Component</p>'
})
class MockAgreementInsuranceComponent {
  @Input() insurance: any;
  @Input() parentViewModel: BaseModel;
  @Input() parentFormFieldConfig: FormField;
}

@Pipe({ name: 'flexColumn' })
class MockFlexColumnPipe implements PipeTransform {
  transform(): any {
    return '';
  }
}

class MockFormBuilderService {
  getBindingData() {
    return [{
      companyName: 'company',
      sumInsured: '23231',
      _guid: '71b99694-451e-42ec-a787-f16d2a86a20f'
    }];
  }
}

class MockLocatorService {
  getService(name) {
    switch (name) {
      case 'actionService':
        return new MockActionService();
      case 'formBuilderService':
        return new MockFormBuilderService();
      default:
    }
  }
}

describe('AgreementInsuranceListComponent', () => {
  let component: AgreementInsuranceListComponent;
  let fixture: ComponentFixture<AgreementInsuranceListComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FlexLayoutModule,
      ],
      providers: [
        { provide: LocatorService, useClass: MockLocatorService },
        { provide: FormBuilderService, useClass: MockFormBuilderService }
      ],
      declarations: [AgreementInsuranceListComponent, MockAgreementInsuranceComponent, MockFlexColumnPipe]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgreementInsuranceListComponent);
    component = fixture.componentInstance;
    component.formFieldConfig = { id: 'specField', type: 'specField', dataBinding: { path: 'agreement.insurance' } };
    component.parentFormFieldConfig = { id: 'specField', type: 'specType' };
    component.viewModel = new InsuredModel();

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Function - onFormFieldConfigLoaded', () => {

    it('should be run', () => {
      component.onFormFieldConfigLoaded();

      expect(JSON.stringify(component.dataSource)).toEqual(JSON.stringify([{
        companyName: 'company',
        sumInsured: '23231',
        _guid: '71b99694-451e-42ec-a787-f16d2a86a20f'
      }]));
    });
  });
});
