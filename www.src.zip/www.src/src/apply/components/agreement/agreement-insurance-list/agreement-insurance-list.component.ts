import { Component } from '@angular/core';
import { LocatorService, FormBuilderService } from '@providers';
import { BaseComponent } from '@shared/ui-elements';
import { InsuranceModel } from '@apply/models';

@Component({
  selector: 'cpos-agreement-insurance-list',
  templateUrl: './agreement-insurance-list.component.html',
  styleUrls: ['./agreement-insurance-list.component.scss']
})
export class AgreementInsuranceListComponent extends BaseComponent {
  dataSource: InsuranceModel[];
  constructor(protected ls: LocatorService) {
    super(ls);
  }

  onFormFieldConfigLoaded() {
    this.loadDataSource();
  }

  loadDataSource() {
    this.dataSource = this.ls.getService<FormBuilderService>('formBuilderService').getBindingData(this.viewModel, this.formFieldConfig.dataBinding.path);
  }
}

