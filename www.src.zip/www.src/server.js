const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const request = require('request');
const moment = require('moment');
const fs = require('fs');
const path = require('path');

const SERVER_COMMON = 'server_common/dummy';
const SERVER_PROPOSAL = 'server_proposal/dummy';
const SERVER_PROPOSAL_SAMPLES = 'server_proposal/samples';
const PROPOSALS_FILE = 'proposals.json';
const AGENT_PROPOSAL_FILE = 'agent-proposals.json';
const CUSTOMERS_FILE = 'customers.json';
const AGENT_REFERRALS_FILE = 'agent-referrals.json';
const REFERRALS_FILE = 'referrals.json';
const CONTENT_FILE = 'content.json';
const SYSTEM_DOCUMENT_FILE = 'systemDocument.json';
const USE_DUMMY = false;

const app = express();
app.use(
  bodyParser.json({
    limit: '10mb'
  })
);
app.use(
  bodyParser.urlencoded({
    extended: true
  })
);
app.use(cors());

const webApi = 'https://product-engine-nodejs-core.apps.sea.preview.pcf.manulife.com/api/v1/product/';
// const webApi = 'https://pos-web-bff-core-service-dev.apps.eas.pcf.manulife.com/v1/core/product/';
const webVersion = true;
const baseOptions = {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  }
};

var applyRouter = require('./server_apply/applications');
app.use('/services/entity/application', applyRouter);
// function read content json file
function readJsonFileSync(filepath, encoding) {
  if (typeof encoding == 'undefined') {
    encoding = 'utf8';
  }
  var file = fs.readFileSync(filepath, encoding);
  return JSON.parse(file);
}

// function get path local and return content json file
function getConfig(file) {
  var filepath = __dirname + '/' + file;
  return readJsonFileSync(filepath);
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

function getFolderPath(entity) {
  return `${__dirname}/${entity}/`;
}

function writeJsonFileSync(fileName, folderPath, body, callback) {
  const path = folderPath + fileName;
  fs.writeFile(path, body, callback)
}

////////////////////////////////
// API FOR CUSTOMER DASHBOARD //
///////////////////////////////
// get list customer
app.route('/services/entity/customer').get((_req, res) => {
  const content = getConfig(`${SERVER_COMMON}/${CUSTOMERS_FILE}`);
  res.send(content);
});

// get list agent referrals
app.route('/services/entity/agent/leads').get((_req, res) => {
  const content = getConfig(`${SERVER_COMMON}/${AGENT_REFERRALS_FILE}`);
  res.send(content);
});

// get list customer referrals
app.route('/pages/action/customers/:id/leads').get((_req, res) => {
  const content = getConfig(`${SERVER_COMMON}/${REFERRALS_FILE}`);
  res.send(content);
});

// update referrals
app.route('/pages/action/leads/:id').put((_req, res) => {
  let body = _req.body;
  let content = getConfig(`${SERVER_COMMON}/${REFERRALS_FILE}`);
  const index = content.referrals.findIndex(c => c.referralId === body.referralId);
  content.referrals[index] = body;

  writeJsonFileSync(`${REFERRALS_FILE}`, getFolderPath(SERVER_COMMON), JSON.stringify(content), function (error) {
    if (error) {
      res.status(404).send('Data not saved');
      return;
    }
    res.status(200).json(_req.body);
  });
});

// create referrals
app.route('/pages/action/leads').post((_req, res) => {
  let body = _req.body[0];
  let content = getConfig(`${SERVER_COMMON}/${REFERRALS_FILE}`);
  content.referrals.push(body);

  writeJsonFileSync(`${REFERRALS_FILE}`, getFolderPath(SERVER_COMMON), JSON.stringify(content), function (error) {
    if (error) {
      res.status(404).send('Data not saved');
      return;
    }
    res.status(200).json(_req.body);
  });
});

// get list customer with new api
app.route('/pages/action/customers').get((_req, res) => {
  const content = getConfig(`${SERVER_COMMON}/${CUSTOMERS_FILE}`);
  result = [];
  content.forEach(customer => {
    result.push({
      customerId: customer.customerId,
      isDeleted: customer.isDeleted,
      age: customer.customerData.age,
      lastAccessedDate: customer.lastAccessedDate,
      lastModifiedDate: customer.lastModifiedDate,
      agentId: customer.agentId,
      photo: customer.photo,
      soupEntryId: customer.soupEntryId,
      firstName: customer.customerData.firstName,
      middleName: customer.customerData.middleName,
      lastName: customer.customerData.lastName,
      email: customer.customerData.email,
      phoneNumber: customer.customerData.phoneNumber,
      customerJourneyStatus: customer.customerData.customerJourneyStatus,
      gender: customer.customerData.gender,
    });
  });
  setTimeout(function () {
    res.send(result);
  }, 1000);
});

// get customer by id
app.route('/pages/action/customers/:id').get((_req, res) => {
  // console.log(_req.params.id);
  const content = getConfig(`${SERVER_COMMON}/${CUSTOMERS_FILE}`);
  result = [];
  const index = content.findIndex(c => c.customerId === _req.params.id);
  if (index === -1) {
    res.status(404).send('Data not found');
  } else {
    result.push(content[index])
    res.send(result);
  }
});

// update customer
app.route('/services/entity/customer').put((_req, res) => {
  let body = _req.body;
  let content = getConfig(`${SERVER_COMMON}/${CUSTOMERS_FILE}`);
  const index = content.findIndex(c => c.customerId === body.customerId);
  content[index] = body;

  writeJsonFileSync(`${CUSTOMERS_FILE}`, getFolderPath(SERVER_COMMON), JSON.stringify(content), function (error) {
    if (error) {
      res.status(404).send('Data not saved');
      return;
    }
    res.status(200).json(_req.body);
  });
});

// create customer
app.route('/pages/action/customers').post((_req, res) => {
  let body = _req.body;
  let content = getConfig(`${SERVER_COMMON}/${CUSTOMERS_FILE}`);
  content.push(body);

  writeJsonFileSync(`${CUSTOMERS_FILE}`, getFolderPath(SERVER_COMMON), JSON.stringify(content), function (error) {
    if (error) {
      res.status(404).send('Data not saved');
      return;
    }
    res.status(200).json(body);
  });
});

// delete / restore customer
app.route('/pages/action/customers').put((_req, res) => {
  let body = _req.body;
  let isDelete = (_req.query.isDeleted == 'true');

  let content = getConfig(`${SERVER_COMMON}/${CUSTOMERS_FILE}`);
  let index = [];
  body.forEach((value) => {
    index.push(content.findIndex(c => c.customerId === value));
  });

  index.forEach((idx) => {
    content[idx].isDeleted = isDelete;
  });


  writeJsonFileSync(`${CUSTOMERS_FILE}`, getFolderPath(SERVER_COMMON), JSON.stringify(content), function (error) {
    if (error) {
      res.status(404).send('Cannot delete customer');
      return;
    }
    res.status(200).json(_req.body);
  });
});

// get click count
app.route('/agent/documents/trackings/viewcount').get((_req, res) => {
  const content = getConfig(`${SERVER_COMMON}/mostClickDocument.json`);
  res.send(content);
});

//////////////////////////////
// API FOR RESOURCE LIBRARY///
/////////////////////////////
// Update most click document
// app.route('/agent/1/documents/trackings/viewcount').put((_req, res) => {
//   let body = _req.body;
//   let content = getConfig(`${SERVER_COMMON}/mostClickDocument.json`);
//   if (content && content.length > 0) {
//     const index = content.findIndex(c => c.key === body.key);
//     if (index === -1) {
//       content.push(body);
//     } else {
//       content[index].value = (parseInt(content[index].value) + 1).toString();
//     }
//   } else {
//     content.push(body);
//   }

//   writeJsonFileSync(`mostClickDocument.json`, getFolderPath(SERVER_COMMON), JSON.stringify(content), function (error) {
//     if (error) {
//       res.status(404).send('Data not saved');
//       return;
//     }
//     res.sendStatus(200);
//   });
// });
// get video url
app.route('/video').get((_req, res) => {
  const content = "https://cdn.vidyard.com/videos/f5Jb-QS09b_LR0SS2d_A5g/hd.mp4?gEiMgqvNybLgQnNSSaLXNWyMri-cV_Ud8e4Qusw0eAweoMFU2sDAoQ65pJMj62Dx-4HGx7zfIbqszuwSdIAAWnF2Zy2qmK_qwM30Kl5n";
  // const content = '../../assets/video.mp4';
  res.send(content);
});
/////////////////
// API FOR M&R //
/////////////////
// get system configuation
app.route('/services/entity/systemDocument').get((_req, res) => {
  const content = getConfig(`${SERVER_COMMON}/${SYSTEM_DOCUMENT_FILE}`);
  res.send(content);
});

// get agent infomation
app.route('/services/entity/agent').get((_req, res) => {
  // const content = getConfig('src/assets/dummy/agent.json');
  const content = getConfig(`${SERVER_COMMON}/agent.json`);
  res.send(content);
});

// update agent infomation
app.route('/services/entity/agent').put((req, res) => {
  res.status(200).json(req.body);
});

// check turn on passcode
app.route('/pages/action/CheckAuthentication').get((req, res) => {
  res.send({
    status: 'success'
  }).sendStatus(200);
});

// get content json
app.route('/services/content/').get((_req, res) => {
  const content = getConfig(`${SERVER_PROPOSAL}/${CONTENT_FILE}`);
  res.send(content);
});

// get latest FAN Report
app.route('/pages/action/GetLatestFNAReport').get((_req, res) => {
  res.send({
    syncStatus: '',
    customerId: 'ab807138-c375-9ec6-d86d-b5ba92108479',
    uri: 'assets/pdfs/Financial Needs Analysis.pdf',
    isDraft: 0
  });
});

// print FNA Report
app.route('/pages/action/PrintFNAReport').get((_req, res) => {
  res.send({
    uri: 'assets/pdfs/Financial Needs Analysis.pdf',
    customerId: 'ab807138-c375-9ec6-d86d-b5ba92108479'
  });
});

// get FNA history
app.route('/pages/action/GetFNAHistory').get((_req, res) => {
  const content = getConfig('src/assets/dummy/historicalFNAs.json');
  res.send(content);
});

// get FNA history pdf
app.route('/pages/action/GetFNAHistoryPdf').get((_req, res) => {
  res.send({
    uri: 'assets/pdfs/Financial Needs Analysis.pdf',
    syncStatus: 'Success',
    fnaHistoryId: 'F7DBD53F-7785-45F7-9991-5B75E4A4B220'
  });
});

// get rpq report list
app.route('/services/entity/rpq').get((_req, res) => {
  const content = getConfig('src/assets/dummy/rpq.json');
  res.send(content);
});
app.route('/pages/action/customers/d3162f16-66bc-1b8c-0cc6-3c0cb54cdeab/documents').get((_req, res) => {
  const content = getConfig(`${SERVER_COMMON}/reportList.json`);
  res.send(content);
});

// get rpq report pdf
app.route('/pages/action/GetRPQReportPDF').get((_req, res) => {
  res.send({
    rpqId: 'DD40F09C-FB3F-40A1-BBA8-4888E2EC4335',
    uri: 'assets/pdfs/RPQ.pdf'
  });
});

/////////////////////
// API FOR PROPOSE //
/////////////////////
// get summary proposal
app.route('/services/entity/summaryProposal').get((_req, res) => {
  const content = getConfig('src/assets/dummy/summaryProposals.json');
  res.send(content);
});

// get proposal pdf
app.route('/pages/action/GetProposalPdf').get((_req, res) => {
  res.send({
    summaryProposalId: 'E805C857-B279-4578-9296-63CD7C6E90A9',
    uriFullPath: '/Users/lhuynh24/Library/Developer/CoreSimulator/Devices/375B2DD6-B23F-4D72-9180-FCEFD5233D84/data/Containers/Data/Application/4D89F29B-BEC0-4038-9B5E-47CB444CED15/Documents/pdfs/Summary Proposal.pdf',
    proposalName: 'Manulife - Cuộc Sống Tươi Đẹp_ENF20-Bản sao',
    syncStatus: '',
    uri: 'assets/pdfs/Summary Proposal.pdf'
  });
});

// get proposal list
app.route('/services/entity/proposals').get((_req, res) => {
  const content = getConfig(`${SERVER_PROPOSAL}/${PROPOSALS_FILE}`);
  res.send(content);
});

// get agent proposal list
app.route('/services/entity/agent/proposals').get((_req, res) => {
  const content = getConfig(`${SERVER_PROPOSAL}/${PROPOSALS_FILE}`);
  res.send(content);
});

// get agent proposal list
app.route('/services/entity/agent/proposals/headers').get((_req, res) => {
  const content = getConfig(`${SERVER_PROPOSAL}/${AGENT_PROPOSAL_FILE}`);
  res.send(content);
});

app.route('/services/entity/proposal').post((req, res) => {
  const url = path.join(__dirname, `src/assets/dummy/${PROPOSALS_FILE}`);
  const rawData = fs.readFileSync(url);
  let jsonData = JSON.parse(rawData);

  if (!jsonData) {
    jsonData = [];
  }

  jsonData.push(req.body);

  // Update file json
  fs.writeFileSync(url, JSON.stringify(jsonData));

  res.status(200).json(jsonData);
});

app.route('/services/entity/proposal').put((req, res) => {
  const url = path.join(__dirname, `src/assets/dummy/${PROPOSALS_FILE}`);
  const rawData = fs.readFileSync(url);
  let jsonData = JSON.parse(rawData);

  const index = jsonData.findIndex(p => p.proposalId === req.body.proposalId);

  jsonData[index] = req.body;
  fs.writeFileSync(url, JSON.stringify(jsonData));
  res.status(200).json(jsonData);
});

app.route('/services/entity/customers/:customerId/proposals/:proposalId').get((_req, res) => {
  const content = getConfig(`${SERVER_PROPOSAL}/${PROPOSALS_FILE}`);
  const index = content.findIndex(p => p.proposalId === _req.params.proposalId);
  res.status(200).json(content[index]);
});

// new get proposal
app.route('/pages/action/customers/:id/proposals').get((_req, res) => {
  // console.log(_req.params.id);

  const content = getConfig(`${SERVER_PROPOSAL}/${PROPOSALS_FILE}`);
  res.send(content);
});

// new create/update proposal
app.route('/pages/action/customers/:id/proposals').post((_req, res) => {
  // console.log(_req.params.id);

  let body = _req.body;
  let content = getConfig(`${SERVER_PROPOSAL}/${PROPOSALS_FILE}`);
  const index = content.findIndex(c => c.proposalId === body[0].proposalId);
  if (index === -1) {
    content.push(body[0]);
  } else {
    content[index] = body[0];
  }

  writeJsonFileSync(`${PROPOSALS_FILE}`, getFolderPath(SERVER_PROPOSAL), JSON.stringify(content), function (error) {
    if (error) {
      res.status(404).send('Data not saved');
      return;
    }
    // Dummy response from PCF
    const dummyResponse = {
      "proposalError": [],
      "jsonResult": {
        "totalSuccess": 1,
        "totalProposalJson": 1,
        "totalFailed": 0,
        "proposalIdSuccess": ["c8518a86-9910-93cb-fa10-6748a912abc9"],
        "proposalIdError": []
      }
    };
    dummyResponse.jsonResult.proposalIdSuccess[0] = body[0].proposalId;
    res.status(200).send(dummyResponse);
  });
});

// new delete proposal
app.route('/pages/action/customers/:id/proposals').put((_req, res) => {
  let body = _req.body;
  let content = getConfig(`${SERVER_PROPOSAL}/${PROPOSALS_FILE}`);

  const index = content.findIndex(c => c.proposalId === body[0]);
  if (index > -1)
    content.splice(index, 1);

  writeJsonFileSync(`${PROPOSALS_FILE}`, getFolderPath(SERVER_PROPOSAL), JSON.stringify(content), function (error) {
    if (error) {
      res.status(404).send('Data not updated');
      return;
    }
    // Dummy response from PCF
    const dummyResponse = {
      "proposalError": [],
      "jsonResult": {
        "totalSuccess": 1,
        "totalProposalJson": 1,
        "totalFailed": 0,
        "proposalIdSuccess": ["c8518a86-9910-93cb-fa10-6748a912abc9"],
        "proposalIdError": []
      }
    };
    dummyResponse.jsonResult.proposalIdSuccess[0] = body[0].proposalId;
    res.status(200).send(dummyResponse);
  });
});

app.route('/pages/action/GenerateProposalNumber').get((_req, res) => {
  res.send({
    proposalNumber: '12CX' + getRandomInt(100000, 999999)
  });
});

app.route('/pages/action/GenerateProposalPdf').post((_req, res) => {
  const content = {
    id: 'Proposal ID',
    serverId: 'db4fd4b8-e554-4277-b899-ae5af423e6d4'
  };
  res.send(content);
});

// get application list json
app.route('/services/entity/application').get((_req, res) => {
  const content = getConfig('src/assets/dummy/applicationList.json');
  res.send(content);
});

app.route('/services/apexrest/ProductEngine/functions/GetProductSchema').post((_req, res) => {
  const content = getConfig('src/assets/dummy/schemaCIE.json');
  res.send(content);
});

app.route('/services/apexrest/ProductEngine/project').post((req, res) => {
  req.on('data', function (data) {
    runProjection(res, data);
  });
});

app.route('/services/apexrest/ProductEngine/functions/GetSchemaIds').post((req, res) => {
  if (USE_DUMMY) {
    const data = req.body;
    const content = getConfig(`${SERVER_PROPOSAL}/getSchemaIds.json`);
    const riderSchemaIds = content.riderSchemaIds;
    riderSchemaIds[0].riderId = data.riders[0].riderId;
    riderSchemaIds[0].productId = data.basePlan.productId;
    const jsonStringSample = JSON.stringify(riderSchemaIds[0]);

    // Duplicate rider schema in sample data
    for (let i = 1, l = data.riders.length; i < l; i++) {
      const riderSchemaId = JSON.parse(jsonStringSample);
      riderSchemaId.riderId = data.riders[i].riderId;
      riderSchemaId.productId = data.basePlan.productId;
      riderSchemaIds.push(riderSchemaId);
    }
    res.send(content).status(200);
  } else {
    callServerFunction(
      webApi + 'functions/GetSchemaIds',
      JSON.stringify(req.body),
      res
    );
  }
});

app.route('/services/apexrest/ProductEngine/functions/GetAgeChangeDates').post((req, res) => {
  if (USE_DUMMY) {
    const data = req.body;
    const content = getConfig(`${SERVER_PROPOSAL}/getAgeChangeDates.json`);
    if (data.DOBs.length > 0) {
      content[0].coverageID = data.DOBs[0].coverageID;
      const jsonStringSample = JSON.stringify(content[0]);

      // Duplicate rider schema in sample data
      for (let i = 1, l = data.DOBs.length; i < l; i++) {
        const ageChangeDate = JSON.parse(jsonStringSample);
        ageChangeDate.coverageID = data.DOBs[i].coverageID;
        content.push(ageChangeDate);
      }
    }
    res.send(content).status(200);
  } else {
    callServerFunction(
      webApi + 'functions/GetAgeChangeDates',
      JSON.stringify(req.body),
      res
    );
  }
});

app.route('/services/apexrest/ProductEngine/functions/CalculatePolicyTerm').post((req, res) => {
  if (USE_DUMMY) {
    const data = req.body;
    const content = getConfig(`${SERVER_PROPOSAL}/calculatePolicyTerm.json`);
    if (data.riders.length > 0) {
      const policyTermRiders = content.policyTermRiders;
      policyTermRiders[0].riderId = data.riders[0].riderId;
      policyTermRiders[0].productId = data.basePlan.productId;
      const jsonStringSample = JSON.stringify(policyTermRiders[0]);

      // Duplicate rider schema in sample data
      for (let i = 1, l = data.riders.length; i < l; i++) {
        const policyTerm = JSON.parse(jsonStringSample);
        policyTerm.riderId = data.riders[i].riderId;
        policyTerm.productId = data.basePlan.productId;
        policyTermRiders.push(policyTerm);
      }
    }
    res.send(content).status(200);
  } else {
    callServerFunction(
      webApi + 'functions/CalculatePolicyTerm',
      JSON.stringify(req.body),
      res,
      true
    );
  }
});

app.route('/services/apexrest/ProductEngine/functions/CustomAgeCalculator').post((req, res) => {
  if (USE_DUMMY) {
    const data = req.body;
    const content = getConfig(`${SERVER_PROPOSAL}/customAgeCalculator.json`);

    // Simple age calculation
    const dobYear = moment(data.dateOfBirth, 'YYYYMMDDHHmmss').year();
    const policyDateYear = moment(data.policyYearDate, 'YYYYMMDDHHmmss').year();
    content.age = policyDateYear - dobYear;

    res.send(content).status(200);
  } else {
    callServerFunction(
      webApi + 'functions/CustomAgeCalculator',
      JSON.stringify(req.body),
      res
    );
  }
});

app.route('/services/apexrest/ProductEngine/functions/GetProductExpiryDate').post((req, res) => {
  callServerFunction(
    webApi + 'functions/GetProductExpiryDate',
    JSON.stringify(req.body),
    res
  );
});

// calculate, validate, custom function of Product Engine
app.route('/services/apexrest/ProductEngine').post((req, res) => {

  const headerFunction = req.headers.function;
  if (headerFunction === 'CalculateInsuredAgeEx') {
    let data = req.body;
    calculateInsuredAge(res, data);
  }
  req.on('data', function (data) {
    data = JSON.parse(data);
    switch (headerFunction) {
      case 'RunProjection':
        runProjection(res, data);
        break;
      case 'CustomFunction':
        customFunction(res, data);
        break;
      case 'CalculateModalPremiums':
        calculateModalPremiums(res, data);
        break;
      case 'PerformValidation':
        // validation
        performValidation(res, data);
        break;
      case 'GetSchema':
        getSchema(res, data);
        break;
      case 'GetCatalog':
        getCatalog(res, data);
        break;
    }
  });
  // res.status(200).json(req.body);
});

app.route('/pages/action/BackupDbFile').get((_req, res) => {
  res.send(['20180814']);
});

app.route('/pages/action/RestoreDataBase').get((_req, res) => {
  res.status(200).json({ msg: '' });
});

app.route('/product/functions/getTimezoneOffset').post((_req, res) => {
  res.send({
    "timezoneOffset": 0
  });
});

app.listen(3000, () => {
  console.log('Server started/restarted!');
});

function hasErrors(data) {
  if (data && data.stack && data.message) {
    return true;
  }
  return false;
}

function getSchema(res, data) {
  let content = getConfig(`${SERVER_PROPOSAL}/schemaCIE.json`);
  content['ProductSchema']['ProductSchemaPK']['ProductPK']['ProductId']['text'] = data.productCode;
  res.send(content).status(200);
}

function getCatalog(res, data) {
  const ciProduct = ['ENC12', 'ENC15', 'ENC20', 'ENM12', 'ENM15', 'ENM20', 'ENF12', 'ENF15', 'ENF20'];
  const newcieProduct = ['EIC12', 'EIC15', 'EIC20', 'EIM12', 'EIM15', 'EIM20', 'EIF12', 'EIF15', 'EIF20'];
  const ruvProduct = ['RUV02', 'RUV03'];
  const educationProduct = [
    'EDF23',
    'EDF24',
    'EDF25',
    'EDF26',
    'EDF27',
    'EDB10',
    'EDB11',
    'EDB12',
    'EDB13',
    'EDB14',
    'EDB15',
    'EDB16',
    'EDB17',
    'EDB18',
    'EDB19',
    'EDB20',
    'EDB21',
    'EDB22',
    'EDB23',
    'EDB24',
    'EDB25',
    'EDB26',
    'EDB27'
  ];
  const horionProduct = ['UH105', 'UI299'];
  const investReadyWealthProduct = ['RME03', 'RME05', 'RME10', 'RMF03', 'RMF10', 'RMF20', 'RMG03'];
  const readyProtectProduct = ['AHP01', 'AHP02', 'AHP03', 'AHP04', 'AHP05'];
  const manuProtectTermRCProduct = ['TRC05', 'TRC06', 'TRC07', 'TRC08', 'TRC09', 'TRC10'];
  const manuProtectTermLCProduct = ['TLC11', 'TLC12', 'TLC13', 'TLC14', 'TLC15', 'TLC16', 'TLC17', 'TLC18', 'TLC19', 'TLC20',
    'TLC21', 'TLC22', 'TLC23', 'TLC24', 'TLC25', 'TLC26', 'TLC27', 'TLC28', 'TLC29', 'TLC30',
    'TLC31', 'TLC32', 'TLC33', 'TLC34', 'TLC35', 'TLC36', 'TLC37', 'TLC38', 'TLC39', 'TLC40',
  ];
  const manuProtectTermSPProduct = ['SLC05', 'SLC06', 'SLC07', 'SLC08', 'SLC09', 'SLC10',
    'SLC11', 'SLC12', 'SLC13', 'SLC14', 'SLC15', 'SLC16', 'SLC17', 'SLC18', 'SLC19', 'SLC20',
    'SLC21', 'SLC22', 'SLC23', 'SLC24', 'SLC25', 'SLC26', 'SLC27', 'SLC28', 'SLC29', 'SLC30',
    'SLC31', 'SLC32', 'SLC33', 'SLC34', 'SLC35', 'SLC36', 'SLC37', 'SLC38', 'SLC39', 'SLC40',
  ];
  if (data.productId === 'UL007') {
    const content = getConfig(`${SERVER_PROPOSAL}/product-catalog-ul.json`);
    res.send(content).status(200);
  } else if (ciProduct.indexOf(data.productId) !== -1) {
    const paymentYear = data.productId.slice(3, 5);
    const content = getConfig(`${SERVER_PROPOSAL}/product-catalog-ci.json`);
    const plan = 'ENx' + paymentYear;
    res.send(content[plan]).status(200);
  } else if (ruvProduct.indexOf(data.productId) !== -1) {
    const content = getConfig(`${SERVER_PROPOSAL}/product-catalog-ruv.json`);
    const plan = data.productId;
    res.send(content[plan]).status(200);
  } else if (educationProduct.indexOf(data.productId) !== -1) {
    const content = getConfig(`${SERVER_PROPOSAL}/product-catalog-edu.json`);
    const plan = data.productId;
    res.send(content[plan]).status(200);
  } else if (horionProduct.indexOf(data.productId) !== -1) {
    const content = getConfig(`${SERVER_PROPOSAL}/product-catalog-horizon.json`);
    const plan = data.productId;
    res.send(content[plan]).status(200);
  } else if (newcieProduct.indexOf(data.productId) !== -1) {
    const paymentYear = data.productId.slice(3, 5);
    const content = getConfig(`${SERVER_PROPOSAL}/product-catalog-ci.json`);
    const plan = 'ENx' + paymentYear;
    res.send(content[plan]).status(200);
  } else if (investReadyWealthProduct.indexOf(data.productId) !== -1) {
    const content = getConfig(`${SERVER_PROPOSAL}/product-catalog-irw.json`);
    const plan = data.productId;
    res.send(content[plan]).status(200);
  } else if (readyProtectProduct.indexOf(data.productId) !== -1) {
    const content = getConfig(`${SERVER_PROPOSAL}/product-catalog-rp.json`);
    const plan = data.productId;
    res.send(content[plan]).status(200);
  } else if (manuProtectTermRCProduct.indexOf(data.productId.slice(0, 3)) !== -1) {
    const content = getConfig(`${SERVER_PROPOSAL}/product-catalog-mpt-rc.json`);
    const plan = data.productId;
    res.send(content[plan]).status(200);
  } else if (manuProtectTermLCProduct.indexOf(data.productId) !== -1) {
    const content = getConfig(`${SERVER_PROPOSAL}/product-catalog-mpt-lc.json`);
    const plan = data.productId;
    res.send(content[plan]).status(200);
  } else if (manuProtectTermSPProduct.indexOf(data.productId.slice(0, 3)) !== -1) {
    const content = getConfig(`${SERVER_PROPOSAL}/product-catalog-mpt-sp.json`);
    const plan = data.productId;
    res.send(content[plan]).status(200);
  }
}

function performValidation(res, data) {
  if (USE_DUMMY) {
    const productId = getProductCodeById(data.validationRequest.coverageInfo.product.productKey.primaryProduct.productPK.productId);
    let content = getConfig(`${SERVER_PROPOSAL_SAMPLES}/outputRunProjection.json`);
    content.product.code = productId;
    res.send(content).status(200);
  } else {
    callServerFunction(
      webApi + 'validate',
      JSON.stringify(data.validationRequest),
      res
    );
  }
}

function callServerFunction(url, body, res, wrapWithResult = false) {
  const postOptions = Object.assign({
      uri: url,
      body: body
    },
    baseOptions
  );
  request(postOptions, function (_error, _res, resBody) {
    const result = hasErrors(resBody) ? null : JSON.parse(resBody);
    res.send(wrapWithResult ? {
        result: result
      } :
      result
    );
  });
}

function customFunction(res, data) {
  if (USE_DUMMY) {
    if (data.functionName === 'CalculateFaceAmountRange') {
      const content = getConfig(`${SERVER_PROPOSAL}/outputMinMaxBaseProtection.json`);
      res.send(content).status(200);
    } else if (data.functionName === 'CalculatePlannedPremiumRangeUL007') {
      const content = getConfig(`${SERVER_PROPOSAL}/outputMinMaxBasePremiumUL.json`);
      res.send(content).status(200);
      // } else if (data.functionName === 'CalculateAgeEnoughOneMonth') {
      //   const content = getConfig(`${SERVER_PROPOSAL}/calculateAgeEnoughOneMonth.json`);
      //   res.send(content).status(200);
    } else if (data.functionName === 'CalculateFaceAmountRange_UHXXX_UIXXX') {
      const content = getConfig(`${SERVER_PROPOSAL}/calculateFaceAmountRange_UHXXX_UIXXX.json`);
      res.send(content).status(200);
    }
  } else {
    callServerFunction(
      webApi + 'functions/' + data.functionName,
      JSON.stringify(data.params),
      res,
      true
    );
  }
}

function calculateModalPremiums(res, data) {
  if (USE_DUMMY) {
    let content = getConfig(`${SERVER_PROPOSAL_SAMPLES}/outputCalBasePremium.json`);
    if (data.calculateRequest.riders.coverageInfo.length === 0) {
      content.basePlanCode = data.calculateRequest.coverageInfo.product.productKey.primaryProduct.productPK.productId;
      content.riders = [];
      res.send(content).status(200);
    } else {
      const riderCoverage = data.calculateRequest.riders.coverageInfo;
      const riderCode = riderCoverage[0].product.productKey.primaryProduct.productPK.productId;
      // const planCode = riderCoverage[0].product.productKey.basicProduct.productPK.productId;
      content.basePlanCode = data.calculateRequest.coverageInfo.product.productKey.primaryProduct.productPK.productId;
      content.riders[0].riderCode = riderCode;

      // Duplicate rider premium
      let duplicateRiderPremium = JSON.stringify(content.riders[0]);
      for (let i = 1, l = riderCoverage.length; i < l; i++) {
        content.riders.push(JSON.parse(duplicateRiderPremium));
        content.riders[i].riderCode = riderCoverage[i].product.productKey.primaryProduct.productPK.productId;
      }
      res.send(content).status(200);
    }
  } else {
    callServerFunction(
      webApi + 'calculatePremiums',
      JSON.stringify(data.calculateRequest),
      res
    );
  }
}

const mappingJson = {
  UH105: {
    AE885: `${SERVER_PROPOSAL}/outputCalBasePremiumAE8RiderUH1.json`,
    WE885: `${SERVER_PROPOSAL}/outputCalBasePremiumWE8RiderUH1.json`,
  },
  RUV02: {
    ADD12: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderRUV.json`,
    ECI09: `${SERVER_PROPOSAL}/outputCalBasePremiumCIRiderRUV.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderRUV.json`,
    MC014: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderRUV.json`,
    TRI10: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderRUV.json`
  },
  UL007: {
    ADD03: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderUL.json`,
    ECI01: `${SERVER_PROPOSAL}/outputCalBasePremiumCIRiderUL.json`,
    RHC2I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderUL.json`,
    MC005: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderUL.json`,
    TRI07: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderUL.json`
  },
  ENF12: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI08: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`
  },
  ENM12: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI08: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`
  },
  ENC12: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI08: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`
  },
  ENF15: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI09: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`
  },
  ENM15: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI09: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`
  },
  ENC15: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI09: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`
  },
  ENF20: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI08: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`
  },
  ENM20: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI08: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`,
  },
  ENC20: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI08: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`
  },
  EIM12: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI08: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`
  },
  EIM15: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI08: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`,
    TRI09: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`,
  },
  EIM20: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI08: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`,
    TRI09: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`,
  },
  TLC11: {
    ADD10: `${SERVER_PROPOSAL}/outputCalBasePremiumADDRiderCIE.json`,
    RHC1I: `${SERVER_PROPOSAL}/outputCalBasePremiumHCRiderCIE.json`,
    MC012: `${SERVER_PROPOSAL}/outputCalBasePremiumMCRiderCIE.json`,
    TRI08: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`,
    TRI09: `${SERVER_PROPOSAL}/outputCalBasePremiumTermRiderCIE.json`,
  }
};

function calculateInsuredAge(res, data) {
  if (USE_DUMMY) {
    const dob = moment(data.dateOfBirth, 'YYYYMMDDHHmmss');
    const policyDate = moment(data.policyYearDate, 'YYYYMMDDHHmmss');
    const age = policyDate.diff(dob, 'years');
    res.send({
      result: {
        age: age,
        error: ''
      }
    });
  } else {
    callServerFunction(
      webApi + 'calculateInsuredAge',
      JSON.stringify(data),
      res,
      true
    );
  }
}

function runProjection(res, data) {
  if (USE_DUMMY) {
    const productId = getProductCodeById(data.calculateRequest.coverageInfo.product.productKey.primaryProduct.productPK.productId);
    const content = getConfig(`${SERVER_PROPOSAL}/outputRunProjection${productId}.json`);
    res.send(content).status(200);
  } else {
    callServerFunction(
      webApi + 'project',
      JSON.stringify(data.calculateRequest),
      res
    );
  }
}

function getProductCodeById(productId) {
  const tempId = productId.match(/[A-Z]/g).join('');
  return tempId.indexOf('EN') > -1 ? 'CIE' : tempId;
}
